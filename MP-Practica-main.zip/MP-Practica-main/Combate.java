package practica;

import java.io.Serializable;


public class Combate implements Serializable{
    private int AtaqueFinalDesafiante;
    private int AtaqueFinalDesafiado;
    private int DefensaFinalDesafiante;
    private int DefensaFinalDesafiado;
    private Desafio desafiante;
    private Desafio desafiado;
    private int VidaDesafiante;
    private int VidaDesafiado;
    
    public Combate(Desafio desafiante, Desafio desafiado){
        this.desafiado = desafiado;
        this.desafiante = desafiante;
        this.VidaDesafiante = desafiante.getSaludTotal();
        this.VidaDesafiado = desafiado.getSaludTotal();
    }
    
    public void crearDesafio(String nickJ2, int oroApostado){
        
    }
    
    private int potencialAtaque(Desafio des){
        int intentos = 0;
        int ataqueFinal = 0;
        for(int i= 0;i<des.getDañoTotal();i++){
            intentos = (int) (Math.random()*6+1);
            if(intentos>=5)
                ataqueFinal += 1;
        }
        
        return ataqueFinal;
        
    }

    private int potencialDefensa(Desafio des){
        int intentos = 0;
        int defensaFinal = 0;
        for(int i= 0;i<des.getDefensaTotal();i++){
            intentos = (int) (Math.random()*6+1);
            if(intentos>=5)
                defensaFinal += 1;
        }
        
        return defensaFinal;
        
    }
    
    private boolean comprobarAtaque(){
        if(AtaqueFinalDesafiante > DefensaFinalDesafiado)
            return true;
        return false;
    }
    
    private int comprobarVictoria(){
        if(VidaDesafiante > 0 && VidaDesafiado > 0)        // sigue combate
            return 1;
        else if(VidaDesafiado == 0 && VidaDesafiante == 0) //empate
            return 2;
        else if(VidaDesafiado > 0 && VidaDesafiante == 0) // gana desafiado
            return 3;
        else                                              // gana desafiante
            return 4;
    } 
}
