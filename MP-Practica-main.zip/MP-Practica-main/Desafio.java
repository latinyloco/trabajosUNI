/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author d.rodriguezgal.2020
 */
public class Desafio implements Serializable{
    private int SaludEsbirros;
    private int SaludPersonaje;
    private int saludTotal;
    private int potencialAtaque;  
    private int potencialDefensa;
    private int dañoTotal = 0;
    private int defensaTotal = 0;
    private Personaje desafiado;
    
    
    public Desafio(Personaje desafiado, int tipo) {   
        this.desafiado=desafiado; 
        
        SaludEsbirros = this.sumaSalud();
        SaludPersonaje = desafiado.getSaludPer();    
        this.inicioCombate(tipo);
    }
    
    private int sumaSalud(){
       int cont = 0;
       Esbirro br = desafiado.getEsbirro();
       do{
           cont += br.getSalud();
           br = br.getEsbirroDe();
       }while(br != null);
       return cont;       
    }
    
    private void inicioCombate(int tipo){
        switch(tipo){
            case 1:
                Vampiro vampiro = (Vampiro) desafiado;
                saludTotal = this.sumaSalud();
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();
                
                
                if (vampiro.getSangre() >= 5)
                    dañoTotal += 2;
                break;
                
            case 2:
                Licantropo licantropo = (Licantropo) desafiado;
                saludTotal = this.sumaSalud();
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();
                
                if (licantropo.getRabia() == 3)
                    dañoTotal += 1;
                break;
        
            case 3:
                Cazador cazador = null;
                saludTotal = this.sumaSalud();
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();
        }
        
        
            /*int attackChance = (int) (Math.random()*6+1);
            int defenseChance = (int) (Math.random()*6+1);
            
            if (attackChance == 6 || attackChance == 5 )
                potencialAtaque = dañoTotal;
            
            if (attackChance == 4 || attackChance == 3 )
                potencialAtaque = dañoTotal/2;      
            
            if (attackChance == 1 || attackChance == 2 )
                potencialAtaque = dañoTotal/4;    
            
            if (defenseChance == 6 || defenseChance == 5 )
                potencialAtaque = dañoTotal;
            
            if (defenseChance == 4 || defenseChance == 3 )
                potencialAtaque = dañoTotal/2;      
            
            if (defenseChance == 1 || defenseChance == 2 )
                potencialAtaque = dañoTotal/4; */
            
        
    }
    private int calculoDaño(){
        int dañoArma2 = 0;
        int dañoArma1 = desafiado.getArma_activa1().getAtaque();
        if (!desafiado.getArma_activa2().equals(null))
            dañoArma2 = desafiado.getArma_activa2().getAtaque();
        
        ArrayList<Fortalezas> fort = desafiado.getFortaleza();
        int daño = 0;
        daño = desafiado.getPoderPer() + dañoArma1 + dañoArma2 + desafiado.getArmadura_activa().getAtaque(); //Falta disciplina
        for (int i = 0; i < fort.size(); i++) {
            if (fort.get(i).isActivo()) {
                daño += fort.get(i).getEficiencia();
            }

        }
        return daño;
       
    }
    private int calculoDefensa(){
        int defensaArma2 = 0;
        
        int defensaArma1 = desafiado.getArma_activa1().getDefensa();
        if (!desafiado.getArma_activa2().equals(null))
            defensaArma2 = desafiado.getArma_activa2().getDefensa();
        
        ArrayList<Debilidades> deb = desafiado.getDebilidad();
        int defensa = 0;
        defensa = defensaArma1 + defensaArma2 + desafiado.getArmadura_activa().getDefensa(); //Falta disciplina
        for (int i = 0; i < deb.size(); i++) {
            if (deb.get(i).isActivo()) {
                defensa -= deb.get(i).getSensibilidad();
            }

        }
        return defensa;
    }

    public int getSaludEsbirros() {
        return SaludEsbirros;
    }

    public int getSaludPersonaje() {
        return SaludPersonaje;
    }

    public int getSaludTotal() {
        return saludTotal;
    }

    public int getDañoTotal() {
        return dañoTotal;
    }

    public int getDefensaTotal() {
        return defensaTotal;
    }

    public Personaje getDesafiado() {
        return desafiado;
    }
    
}
