package practica;

import java.io.Serializable;
import java.util.ArrayList;


public class InfoDesafio implements Serializable{

    ArrayList<InfoDesafio> info;
    private int oroApostado;
    private String nickDesafiante;
    private String nickDesafiado;
    private Jugador ante;
    private Jugador ado;
    private Desafio desafiante;
    private Desafio desafiado;
    private Combate combate;
    private boolean validarOp = false;
    private boolean validarJu = false;

    InfoDesafio(int oroApostado, String nickDesafiante, String nickDesafiado, Jugador desafiante, Jugador desafiado) {   
        this.oroApostado = oroApostado;
        this.nickDesafiante = nickDesafiante;
        this.nickDesafiado = nickDesafiado;
        this.ante = desafiante;
        this.ado = desafiado;
    }
    
    public void cargarJugadores(){
        desafiante = new Desafio(ante.getPersonaje(), ante.getPersonaje().getTipoPersonaje());
        desafiado = new Desafio(ado.getPersonaje(), ado.getPersonaje().getTipoPersonaje());
    }
    
    public void cargarCombate(){
        if (validarOp && validarJu)
            combate = new Combate(desafiante, desafiado);
        //else {
            //RecargarFicheros fich = new RecargarFicheros();
            //fich.eliminarInfoDesafio(); 
        //}
    }
    
    //GETTERS
    public int getOroApostado() {
        return oroApostado;
    }

    public String getDesafiante() {
        return nickDesafiante;
    }

    public String getDesafiado() {
        return nickDesafiado;
    }

    public ArrayList<InfoDesafio> getInfo() {
        return info;
    }   

    public String getNickDesafiante() {
        return nickDesafiante;
    }

    public String getNickDesafiado() {
        return nickDesafiado;
    }  
}
