package practica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Inicio implements Serializable{
    
    FileReader usuarios;
    String[] rutasFicheros;
    
    transient Scanner sn = new Scanner(System.in);
    
    
    //MÉTODO
    public void MenuInicio() throws IOException, ClassNotFoundException{

        RecargarFicheros recarga = new RecargarFicheros();
        rutasFicheros = recarga.RecuperarCrear();
 
        int opc = 0;
        while(opc != 4){
            System.out.println("1. Registrarse    2. Iniciar sesion     3. Salir");
            System.out.print("Elige una opcion: ");
            opc = sn.nextInt();
            sn.nextLine();
            
            switch(opc){
                case 1: this.registrarse(rutasFicheros);
                    System.out.println("");
                    break;
                case 2: this.iniciarSesion(rutasFicheros);
                    System.out.println("");
                    break;
                case 3:
                    System.exit(0);
            }    
        }
    }
    
    //INICIO DE SESIÓN
    public void iniciarSesion(String[] rutasFicheros) throws IOException, ClassNotFoundException{
        
        System.out.print("Introduce usuario: ");
        String usuario = sn.nextLine();
        
        FileReader lector = new FileReader(rutasFicheros[2]);
        BufferedReader buffer = new BufferedReader(lector);
        
        String[] tokens = null;
        String contrasenia = null;
        boolean correct = false;
        
        String strLine = buffer.readLine();
        while (strLine!=null && !correct){
            
            tokens = strLine.split(",");
            
            if(tokens[1].equals(usuario)){
                if(tokens[3].equals("true")){
                    System.out.println("El usuario esta baneado");
                    return;
                }else{
                    int count = 1;
                    System.out.print("Introduce contrasenia: ");
                    contrasenia = sn.nextLine();
                    while(count<3 && !tokens[2].equals(contrasenia)){
                        System.out.print("Te quedan "+(3-count)+" intentos. Introduce contrasenia de nuevo: ");
                        contrasenia = sn.nextLine();
                        count += 1;
                    }
                    
                    if(count == 3){
                        System.out.println("Te quedan 0 intentos. Vuelve a intentarlo");
                        return;
                    }else{
                        System.out.println("Has iniciado sesion.");
                        System.out.println("");
                        
                        if(tokens[0].equals("Operador")){
                            buffer.close();
                            lector.close();
                            MenuOperador iniOp = new MenuOperador(rutasFicheros,usuario);
                            iniOp.menuOp();
                            break;
                        }else{
                            MenuJugador iniJu = new MenuJugador(rutasFicheros,usuario);
                            iniJu.menuJu();
                        }
                        correct = true;
                    }
                }
            }
            strLine = buffer.readLine();
        }  
        
        if(strLine == null){
            System.out.println("Usuario no encontrado.");
        }
        
    }

    //REGISTRO
    public void registrarse(String[] rutasFicheros) throws IOException, ClassNotFoundException{
        System.out.println("Registrarse como:   1. Jugador      2. Operador");
        System.out.print("Elige una opcion: ");
        int opc = sn.nextInt();
            
        switch(opc){
            case 1: this.registrarJugador(rutasFicheros);
                break;
            case 2: this.registrarOperador(rutasFicheros);
                break;
        }  
        
    }
    
    
    public void registrarJugador(String[] rutasFicheros) throws IOException, ClassNotFoundException{
        //Obtener información del jugador nuevo
        Scanner snnn = new Scanner(System.in);
        System.out.print("Nombre jugador: ");
        String nombre = snnn.nextLine();
        System.out.print("Nick jugador: ");
        String nick = snnn.nextLine();
        System.out.print("Contrasenia jugador: ");
        String password = snnn.nextLine();
        boolean baneado = false;
        
        String meterInfo;
        
        
        //Recoger lista de fichero
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
        
        boolean its;
        do{
            its = true;
            for(Jugador i: lista){
                if(i.getNickJu().equals(nick))
                    its = false;  
            } 
            
            if(its == false){
                System.out.println("El nick que ha introducido ya pertenece a otra cuenta.");
                System.out.print("Nuevo Nick: ");
                nick = snnn.nextLine();
            } 
            
        }while(its == false);
        
        //Guardar jugador en la lista
        String n_registro = this.numeroRegistro();

        Jugador jugadorNuevo = new Jugador(nombre,nick,password,n_registro); 
        lista.add(jugadorNuevo);
            
        meterInfo = "Jugador,"+nick+","+password+","+baneado;
        
        
        //Guardar lista en fichero
        ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream(rutasFicheros[0]));
        escibirFichero.reset();
        escibirFichero.writeObject(lista);
        escibirFichero.close();
        
        //Guardar usuario en fichero Usuario
        FileWriter escritor = new FileWriter(rutasFicheros[2],true);
        BufferedWriter out = new BufferedWriter(escritor);
        out.write(meterInfo);
        out.newLine();
        out.close();
        leerFichero.close();
    }
    
    private static String numeroRegistro(){
        String n_registro = null;
        for(int i=0; i<5; i++){
            if(i==0 || i>=3){
                int n = (int) ((int) 65 + Math.random()*90);
                char nv = (char) n;
                String nr = nv+"";
                n_registro += nr;
                
            }else{
                int n = (int) (Math.random() * 9);
                String nr = n+"";
                n_registro += nr;
            } 
        }
        return n_registro;
    }
    
    public void registrarOperador(String[] rutasFicheros) throws IOException, ClassNotFoundException{
        //Obtener información del jugador nuevo
        Scanner snn = new Scanner(System.in);
        System.out.print("Nombre: ");
        String nombre = snn.nextLine();
        System.out.print("Nick: ");
        String nick = snn.nextLine();
        System.out.print("Contrasenia: ");
        String password = snn.nextLine();
        
        String meterInfo;
        
        
        //Recoger lista de fichero y comprobar nick
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[1]));
        ArrayList <Operador> lista = (ArrayList) leerFichero.readObject();

        boolean it;
        do{
            it = true;
            for(Operador i: lista){
                if(i.getNickOp().equals(nick))
                    it = false;  
            } 
            
            if(it == false){
                System.out.println("El nick que ha introducido ya pertenece a otra cuenta.");
                System.out.print("Nuevo Nick: ");
                nick = snn.nextLine();
            } 
            
        }while(it == false);
        
        //Guardar jugador en la lista
        Operador operadorNuevo = new Operador(nombre,nick,password);
        lista.add(operadorNuevo);
            
        meterInfo = "Operador,"+nick+","+password+",false";
        
        
        //Guardar lista en fichero
        ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream(rutasFicheros[1]));
        escibirFichero.reset();
        escibirFichero.writeObject(lista);
        escibirFichero.close();
        
        //Guardar usuario en fichero Usuario
        FileWriter escritor = new FileWriter(rutasFicheros[2],true);
        BufferedWriter out = new BufferedWriter(escritor);
        out.write(meterInfo);
        out.newLine();
        out.close();
        leerFichero.close();
    }
}