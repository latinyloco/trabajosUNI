package practica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class MenuJugador {
    
    private String[] rutasFicheros;
    private String usuario;
    private Jugador jugador;
    
    transient Scanner sn = new Scanner(System.in);
    
    public MenuJugador(String[] rutasFicheros, String usuario){
        this.rutasFicheros = rutasFicheros;
        this.usuario = usuario; 
    }
    

    //GETTERS
    public Jugador getJugador() {
        return jugador;
    }
    
    //MENU DESAFIO
    public void menuDe() throws IOException{
        System.out.println("");
        System.out.println("[TIENES DESAFIOS POR CONFIRMAR:]");
        this.verDesafio();
    }    
    
    //MENÚ JUGADOR
    public void menuJu() throws IOException, FileNotFoundException, ClassNotFoundException{

        //Cargar jugador
        jugador = this.extraerJugador(rutasFicheros,usuario);
        
        //Menú del jugador
        int opc = 0;
        while(opc!=7){
            System.out.println("Que deseas hacer:");
            System.out.println("1.Crear nuevo personaje     2.Crear nuevo esbirro     3.Elegir equipo del alijo      4.Desafios      5.Consultar oro      6.Consultar ranking       7.Salir");
            //System.out.println(jugador.getPersonaje().getArmaActiva1().getNombreAr());
            opc = sn.nextInt(); 
            sn.nextLine();
            
            switch(opc){
                case 1: 
                    System.out.println("");
                    System.out.println("-- Crear nuevo personaje --");
                    this.crearNuevoPer();
                    break;
                    
                case 2: 
                    System.out.println("");
                    System.out.println("-- Crear nuevo esbirro --");
                    this.crearNuevoEsb();
                    break;
                    
                case 3: 
                    System.out.println("");
                    System.out.println("-- Elegir armas y armadura para el combate --");
                    this.elegirArmas();
                    break;
                    
                case 4: 
                    System.out.println("");
                    System.out.println("-- Crear desafios --");
                    this.crearDesafio();
                    break;
                    
                case 5: 
                    System.out.println("");
                    System.out.println("-- Consultar oro --");
                    this.consultarOro();
                    break;
                    
                case 6: 
                    System.out.println("");
                    System.out.println("-- Consultar ranking --");
                    this.consultarRanking();
                    break;
                    
                                   
                case 7:
                    System.out.println("");
                    System.out.println("-- Salir --");
                    break;
            }
            System.out.println("");
            RecargarFicheros recar = new RecargarFicheros();
            recar.guardarJugador(jugador);
        }
    }
    
    private Jugador extraerJugador(String[] rutasFicheros, String usuario) throws FileNotFoundException, IOException, ClassNotFoundException{
        
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
        
        Jugador juega = null;
        for(Jugador i: lista){
            if(i.getNickJu().equals(usuario)){
                return i;
            }
        }
        return null;
    }
    
    
//OPCIONES DEL MENÚ
    
    //CONSULTAR RANKING
    public void consultarRanking() throws IOException, FileNotFoundException, ClassNotFoundException{
        
        Ranking ranking = new Ranking();
        ranking.CargarRanking();
    }
            
    //CONSULTAR ORO
    public void consultarOro(){

        
        if (jugador.getArrayOro() == null){
            System.out.println(" No hay partidas guardadas.");
        }else{
            ArrayList <Integer> orito = jugador.getArrayOro();
            int cont = 0;    
               
            for (Integer i: orito){
                System.out.println(" Partida "+(cont+1)+": "+i);
                cont += 1;
            }
        }
    }
    
    
    //CREAR NUEVO PERSONAJE
    public void crearNuevoPer() throws IOException{
        Personaje newJu = jugador.elegirPersonaje();
        jugador.setPersonaje(newJu);
    }
    
    
    //CREAR NUEVO ESBIRRO
    public void crearNuevoEsb() throws IOException{
        Esbirro newEs = jugador.getPersonaje().elegirEsbirro();
        jugador.getPersonaje().setEsbirro(newEs);
    }
    
    
    //ELEGIR ARMAS
    public void elegirArmas() throws ClassNotFoundException{
        ArrayList <Arma> arma = jugador.getPersonaje().getArma();
        ArrayList <Armadura> armadura = jugador.getPersonaje().getArmadura();
        
        for(int i = 0; i<arma.size(); i++){
            System.out.println(i + ".- " + "Nombre: "+arma.get(i).getNombre_arma()+"  Ataque: "+arma.get(i).getAtaque()+"  Defensa: "+arma.get(i).getDefensa()+"    Dos Manos: "+arma.get(i).getdosManos() );
        }
        System.out.println("Escoge un numero");
        int opcion = sn.nextInt();
        sn.nextLine();
        jugador.getPersonaje().setArma_activa1(arma.get(opcion));
        if (arma.get(opcion).getdosManos() == false){
            System.out.println("Quieres usar otra arma en tu segunda mano?");
            System.out.println("1.Si        2.No");
            opcion = sn.nextInt();
            sn.nextLine();
            switch(opcion){
                case 1:
                    System.out.println("Escoge el arma:");
                    for(int i = 0; i<arma.size(); i++){
                        System.out.println((i+1) + ".- " + "Nombre: "+arma.get(i).getNombre_arma()+"  Ataque: "+arma.get(i).getAtaque()+"  Defensa: "+arma.get(i).getDefensa()+"    Dos Manos: "+arma.get(i).getdosManos());
                    }
                    System.out.println("Escoge un numero");
                    opcion = sn.nextInt();
                    sn.nextLine();
                    if(!jugador.getPersonaje().getArma_activa1().equals(arma.get(opcion-1))){
                        if(arma.get(opcion-1).getdosManos() == true){
                            System.out.println("No puedes escoger un arma de dos manos");
                        }else{
                            jugador.getPersonaje().setArma_activa2(arma.get(opcion-1));
                        }
                    }
                    break;
                case 2:break;
            }
        }
        for(int i = 0; i<armadura.size(); i++){
            System.out.println((i+1) + ".- " + armadura.get(i).getNombre_armadura());
        }
        System.out.println("Escoge un numero");
        opcion = sn.nextInt();
        sn.nextLine();
        jugador.getPersonaje().setArmadura_activa(armadura.get(opcion-1));
        
        RecargarFicheros recarga = new RecargarFicheros();
        recarga.guardarJugador(jugador);
    }
    
    //ACCEDER A COMBATE
    /*public void combatirUsuario() {
        Desafio combate = new Desafio(jugador.getPersonaje(), jugador.getTipo());
        Combate combate = new Combate(jugador.getPersonaje(), jugador.getTipo());
    }*/

    //CREAR DESAFIO
    public void crearDesafio() throws IOException, ClassNotFoundException {
        int oroApostado = 0;
        int oroDisponible = jugador.getPersonaje().getOroPer();
             
        boolean encontrado = false;        
        String nickJ2;
        String direccion = "C:\\FicherosMP\\Jugadores.txt";
        FileReader jugadores = new FileReader(direccion);
        RecargarFicheros recarga = new RecargarFicheros();          
        
        System.out.println("---------Jugadores disponibles-----------");            
        recarga.muestraJugadores(direccion);
        System.out.println("");
        
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream("C:\\FicherosMP\\Jugadores.txt"));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();   
        
        Jugador juega = null;
        
        do {
            System.out.println("Escribe el nick del jugador a desafiar");
            nickJ2 = sn.nextLine();
            sn.nextLine();

            for(Jugador i: lista){
                if(i.getNickJu().equals(usuario)){
                    juega = i;
                }
            }
        } while (juega == null); 
        
        while (oroApostado > oroDisponible || oroApostado < 0) {
            System.out.println("Escribe el oro a apostar en el desafío (debe ser menor que el que posea...)");
            oroApostado = sn.nextInt();
            sn.nextLine();
        }   
        
        InfoDesafio desafio = new InfoDesafio(oroApostado, jugador.getNickJu(), juega.getNickJu(), jugador, juega);
        //Hacer "RecargarFicheros -> InfoDesafio"
    }

    private void verDesafio() {
        //desafios().
    }
}
