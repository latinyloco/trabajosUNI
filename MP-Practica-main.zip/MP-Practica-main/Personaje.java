package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Personaje implements Serializable{
    
    private String nombre_per;
    private int oro_per;
    private int salud_per;
    private int poder_per;
    private Esbirro esbirro;
    private int tipoPersonaje;
    private ArrayList <Fortalezas> fortaleza;
    private ArrayList <Debilidades> debilidad;
    
    private ArrayList <Arma> arma;
    private ArrayList <Armadura> armadura;
    private Arma arma_activa1;
    private Arma arma_activa2;
    private Armadura armadura_activa;
    
    
    

    public Personaje(String nombre_per, int oro_per, int salud_per, int poder_per, ArrayList <Fortalezas> fortaleza, ArrayList <Debilidades> debilidad, ArrayList <Armadura> armadura, ArrayList <Arma> arma,int tipoPersonaje) throws IOException{
        this.nombre_per = nombre_per;
        this.oro_per = oro_per;
        this.salud_per = salud_per;
        this.poder_per = poder_per;
        this.fortaleza = fortaleza;
        this.debilidad = debilidad;
        this.arma = arma;
        this.armadura = armadura;
        this.arma_activa1 = null;
        this.arma_activa2 = null;
        this.armadura_activa = null;
        this.tipoPersonaje = tipoPersonaje;
        esbirro = this.elegirEsbirro();
    }
    
    
    //GETTERS
    public int getOroPer(){
        return oro_per;
    }
    
    public int getSaludPer(){
        return salud_per;
    }
    
    public int getPoderPer(){
        return poder_per;
    }
    
    public Esbirro getEsbirro(){
        return esbirro;
    }

    public ArrayList<Fortalezas> getFortaleza() {
        return fortaleza;
    }

    public ArrayList<Debilidades> getDebilidad() {
        return debilidad;
    }

    public ArrayList<Arma> getArma() {
        return arma;
    }

    public ArrayList<Armadura> getArmadura() {
        return armadura;
    }

    public Arma getArma_activa1() {
        return arma_activa1;
    }

    public Arma getArma_activa2() {
        return arma_activa2;
    }

    public Armadura getArmadura_activa() {
        return armadura_activa;
    }
    
    public String getNombre_per(){
        return nombre_per;
    }

    public int getTipoPersonaje() {
        return tipoPersonaje;
    }
    
    
    
    //SETTERS
    public void setNombrePer(String nombre_per){
        this.nombre_per = nombre_per; 
    }
    
    public void setOroPer(int oro_per){
        this.oro_per = oro_per;  
    }
    
    public void setSaludPer(int salud_per){
        this.salud_per = salud_per; 
    }
    
    public void setPoderPer(int poder_per){
        this.poder_per = poder_per;
    }
    
    public void setFortaleza(ArrayList<Fortalezas> fortaleza) {
        this.fortaleza = fortaleza;
    }

    public void setDebilidad(ArrayList<Debilidades> debilidad) {
        this.debilidad = debilidad;
    }

    public void setArma(ArrayList<Arma> arma) {
        this.arma = arma;
    }

    public void setArmadura(ArrayList<Armadura> armadura) {
        this.armadura = armadura;
    }

    public void setArma_activa1(Arma arma_activa1) {
        this.arma_activa1 = arma_activa1;
    }

    public void setArma_activa2(Arma arma_activa2) {
        this.arma_activa2 = arma_activa2;
    }

    public void setArmadura_activa(Armadura armadura_activa) {
        this.armadura_activa = armadura_activa;
    }

    
    public void setEsbirro(Esbirro esbirro){
        this.esbirro = esbirro;
    }

    public void setTipoPersonaje(int tipoPersonaje) {
        this.tipoPersonaje = tipoPersonaje;
    }
    
    
    

    
    //CREACIÓN ESBIRROS
    public Esbirro elegirEsbirro() throws IOException {
        Scanner sn1 = new Scanner(System.in);
        int tipo;
        if (tipoPersonaje == 1) {
            do {
                System.out.println("Tipo esbirro: ");
                System.out.println("1. Ghoul");
                System.out.println("2.Demonio");
                String typo = sn1.nextLine();
                tipo = pruebaMe(typo, 1, 2);
            } while (tipo == -1);

            esbirro = this.dameTipo(tipo);
            return esbirro;
        } else {
            do {
                System.out.println("Tipo esbirro: ");
                System.out.println("1. Ghoul");
                System.out.println("2.Demonio");
                System.out.println("3.Humano");
                String typo = sn1.nextLine();
                tipo = pruebaMe(typo, 1, 3);
            } while (tipo == -1);

            esbirro = this.dameTipo(tipo);
            return esbirro;
        }
    }
    
    public Esbirro dameTipo(int tipo) throws IOException{
        Scanner sn = new Scanner(System.in);
        System.out.print("Nombre esbirro: ");
        String nombre = sn.nextLine();
        
        int salud;
        do{
            System.out.print("Salud esbirro: ");
            String salu = sn.nextLine();
            salud = pruebaMe(salu,1,3);
        }while(salud == -1);
        
        switch (tipo) {
            case 1:
                
                int dep;
                do{
                    System.out.print("Dependencia Ghoul: ");
                    String de = sn.nextLine();
                    dep = pruebaMe(de,1,3);
                }while(dep == -1);
                return new Ghoul(nombre,salud,dep);    
                
            case 2:
                
                int pac;
                do{
                    System.out.println("Hacer pacto con demonio: ");
                    System.out.println("1. Si     2. Nop: ");
                    String pa = sn.nextLine();
                    pac = pruebaMe(pa,1,2);
                }while(pac == -1);

                boolean pacto;
                String descripPacto;
                if(pac == 2){
                    System.out.println("No has aceptado el pacto... Escoge otro esbirro");
                    esbirro = this.elegirEsbirro(); 
                }
                else{
                    pacto = true;
                    System.out.print("Escribe el pacto: ");
                    descripPacto = sn.nextLine();
                    return new Demonio(nombre,salud,pacto,descripPacto);
                }
                break;
                
            case 3:
                System.out.print("Lealtad con humano: ");
                String lealtad = sn.nextLine();
                return new Humano(nombre,salud,lealtad);
            
            default: return null;
        }
        return null;
    }  
    
    
    //devuelve un -1 si no es un número y no está en el rango, devuelve el número si cumple las dos cosas
    protected int pruebaMe(String num,int i, int f){
        boolean bol = false;
        int numero = dameInt(num);
        if(numero != -1){
            if(esRango(numero,i,f) == true)
                return numero;
            else
                System.out.println("  El rago de valores se comprende entre "+i+" y "+f+".");
        }
        return -1;
    }
    
    //devuelve un int de un string
    private int dameInt(String a){
        try{
            int b = Integer.parseInt(a);
            return b;
        }catch(Exception  e){
            System.out.println("  Introduzca un numero por favor.");
        }
        return -1;
    }
    
    //comprueba si está en el rango señalado
    private boolean esRango(int valor,int i, int f){
        boolean bo = false;
        if (valor>= i && valor<=f)
            bo = true;
        
        return bo;
    }
}