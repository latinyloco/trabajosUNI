package practica;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class RecargarFicheros {
    
    public String[] RecuperarCrear() throws IOException, FileNotFoundException, ClassNotFoundException{
        //Comprobar si los ficheros existen
            //Si no exiten, se crean nuevos y se rellenan
            //Si existen, comprobar si están vacío, y en el caso que lo estén rellenarlos
        File file = new File("C:\\FicherosMP\\Usuarios.txt");
        String[] rutasFicheros;
        
        if(!file.exists()) {
            rutasFicheros = this.CreateFile();
        } else {
            rutasFicheros = this.RecuperacionFicheros();
        }
        return rutasFicheros;
    }
    
    private String[] CreateFile()throws FileNotFoundException, IOException, ClassNotFoundException{
        
        //Crear ficheros
        File objetos1 = new File("C:\\FicherosMP\\Jugadores.txt");
        objetos1.createNewFile();
        File objetos2 = new File("C:\\FicherosMP\\Operadores.txt");
        objetos2.createNewFile();
        File objetos3 = new File("C:\\FicherosMP\\Usuarios.txt");
        objetos3.createNewFile();
        
        
        //Rellenar ficheros
        ArrayList <Jugador> listaU = new ArrayList();
        ArrayList <Operador> listaO = new ArrayList();
        
        ObjectOutputStream escibirFichero1 = new ObjectOutputStream(new FileOutputStream(objetos1));
        escibirFichero1.writeObject(listaU);
        escibirFichero1.close();
        
        ObjectOutputStream escibirFichero2 = new ObjectOutputStream(new FileOutputStream(objetos2));
        escibirFichero2.writeObject(listaO);
        escibirFichero2.close();
        
        
        //Guardar rutas ficheros
        String[] rutasFicheros = new String[3];
        rutasFicheros[0] = objetos1.getAbsolutePath();
        rutasFicheros[1] = objetos2.getAbsolutePath();
        rutasFicheros[2] = objetos3.getAbsolutePath();
        
        return rutasFicheros;
    }
    
    
    private String[] RecuperacionFicheros() throws FileNotFoundException, IOException, ClassNotFoundException{
        
        //Buscar carpeta y coger rutas y nombres de ficheros
        File ruta = new File("C:\\FicherosMP");
        String [] nombreFicheros = ruta.list();
        String [] rutasFicheros = new String[3];
        
        //Rellenar si están vacíos
        int count = 0;
        for(String i: nombreFicheros){
            rutasFicheros[count] = ruta.getAbsolutePath()+"\\"+i;
            FileReader lector = new FileReader(rutasFicheros[count]);
            if(this.isFileEmpty(lector) && !i.equals("Usuarios.txt")){
                ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream(rutasFicheros[count]));
                
                if(count == 0){
                    ArrayList <Jugador> lista = new ArrayList();
                    escibirFichero.writeObject(lista);
                    escibirFichero.close();
                }
                else if(count == 1){
                    ArrayList <Operador> lista = new ArrayList();
                    escibirFichero.writeObject(lista);
                    escibirFichero.close();
                }
                
                
            }
            
            count += 1;
        }
        
        return rutasFicheros;    
    }
    
    private boolean isFileEmpty(FileReader lector) throws IOException, ClassNotFoundException {   
        //Demostrar si los fichero sestán vacíos o no
        int a = (int) lector.read();
        lector.close();
        if(a == -1)
            return  true;
        else
            return false;
    }
    
    //GUARDAR USUARIO
    public void guardarJugador(Jugador jugador) throws ClassNotFoundException{
        
        try{
            
            //Coger lista de fichero
            ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream("C:\\FicherosMP\\Jugadores.txt"));
            ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
            
            //Buscar jugador y eleminar el jugador buscado
            int count = 0;
            Jugador a = null;
            while(count<lista.size()){
                a = (Jugador) lista.get(count);
                if(a.getN_registroJu().equals(jugador.getN_registroJu())){
                    lista.remove(count);
                    lista.add(jugador);
                }
                count += 1;
            }

            leerFichero.close();
                     
            //Guardar jugador nuevo en la lista
            ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream("C:\\FicherosMP\\Jugadores.txt"));
            escibirFichero.reset();
            escibirFichero.writeObject(lista);
            escibirFichero.close();
                       
        }catch(IOException e){
            System.out.println("No se ha encontrado el archivo.");
        }
    }
    public void muestraJugadores(String archivo) throws FileNotFoundException, IOException { 
	String cadena; 
	FileReader f = new FileReader(archivo); 
	BufferedReader b = new BufferedReader(f); 
	while((cadena = b.readLine())!=null) { 
		System.out.println(cadena); 
	} 
	b.close(); 
    }
    
    public void GuardarDesafio(InfoDesafio data) throws IOException, FileNotFoundException, ClassNotFoundException{
        File file = new File("C:\\FicherosMP\\ZDesafio.txt");
        
        if(!file.exists()) 
            this.CreateFileCombate(file, data);
        else 
            this.RecuperacionFicherosCombate(file, data);
    }

    private void CreateFileCombate(File file, InfoDesafio data) throws IOException {
        file.createNewFile();
        ObjectOutputStream info = new ObjectOutputStream(new FileOutputStream(file));  
        ArrayList<InfoDesafio> listaD = new ArrayList<>();
        listaD.add(data);

        ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream(file));
        escibirFichero.writeObject(listaD);
        escibirFichero.close();
    }

    private InfoDesafio RecuperarDesafio(File file, InfoDesafio data, String nick) throws FileNotFoundException, IOException {
        ObjectOutputStream info1 = new ObjectOutputStream(new FileOutputStream(file));  
        ArrayList<InfoDesafio> listaDE = new ArrayList<>();     
        for(InfoDesafio i: listaDE){
            if(i.getNickDesafiado().equals(nick)){
                return i;
            }
        }
        return null;
    }

    private void RecuperacionFicherosCombate(File file, InfoDesafio data) throws FileNotFoundException, IOException, ClassNotFoundException {  
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(file));
        ArrayList <InfoDesafio> listaDES = (ArrayList) leerFichero.readObject();        
        listaDES.add(data);
        leerFichero.close();
             
        ObjectOutputStream escibirFichero = new ObjectOutputStream(new FileOutputStream(file));
        escibirFichero.reset();
        escibirFichero.writeObject(listaDES);
        escibirFichero.close();
    }
}
