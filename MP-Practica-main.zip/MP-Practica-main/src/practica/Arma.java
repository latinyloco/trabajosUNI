package practica;

import java.io.Serializable;

public class Arma implements Serializable {
    private String nombre_arma;
    private int ataque;             //numero del 1 al 5
    private int defensa;
    private boolean dosManos;
    
    public Arma(String nombre_arma, int ataque, int defensa, boolean dosManos) {
        this.nombre_arma = nombre_arma;
        this.ataque = ataque;
        this.defensa = defensa;
        this.dosManos = dosManos;
    }

    
    //GETTER
    public String getNombre_arma() {
        return nombre_arma;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensa() {
        return defensa;
    }
    
    public boolean getdosManos(){
        return dosManos;
    }

    
    //SETTER
    public void setNombre_arma(String nombre_arma) {
        this.nombre_arma = nombre_arma;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }
    
    public void setdosManos(boolean dosManos){
        this.dosManos = dosManos;
    }
    
    
    
}
