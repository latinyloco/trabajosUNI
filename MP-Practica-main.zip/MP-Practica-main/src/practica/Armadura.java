package practica;

import java.io.Serializable;

public class Armadura implements Serializable {
    private String nombre_armadura;
    private int ataque; //numero del 1 al 5
    private int defensa;
    
    public Armadura (String nombre_armadura, int ataque, int defensa) {
        this.nombre_armadura = nombre_armadura;
        this.ataque = ataque;
        this.defensa = defensa;
    }

    //GETTER
    public String getNombre_armadura() {
        return nombre_armadura;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensa() {
        return defensa;
    }
    
    
    //Setter
    public void setNombre_armadura(String nombre_armadura) {
        this.nombre_armadura = nombre_armadura;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }
    
    
}
