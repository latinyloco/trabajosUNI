package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Cazador extends Personaje implements Serializable{
    // Habilidad: Talentos
    private String habEspecial = "Talentos";
    private int ataque;
    private int defensa;  // Valores entre 1 y 3
    
    private int voluntad = 3;  // Disminuye en relacióin a la salud (-1 salud = -1 voluntad)

    public Cazador(String nombre_per, int oro_per, int salud_per, int poder_per, int ataque, int defensa, ArrayList <Fortalezas> fortalezas, ArrayList <Debilidades> debilidad, ArrayList <Armadura> armadura, ArrayList <Arma> arma, int tipo) throws IOException {
        super(nombre_per,oro_per,salud_per,poder_per,fortalezas,debilidad,armadura,arma,tipo);
        this.ataque = ataque;
        this.defensa = defensa;
    }     
   
    // GETTERS
    public int getVoluntad() {
        return voluntad;
    }
    
    // SETTERS
    public void setVoluntad(int voluntad) {       
        this.voluntad = voluntad;
    }
    
}
