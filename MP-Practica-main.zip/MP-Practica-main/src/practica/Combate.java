package practica;

import java.io.Serializable;
import java.util.Date;

public class Combate implements Serializable{
    private int AtaqueFinalDesafiante;
    private int AtaqueFinalDesafiado;
    private int DefensaFinalDesafiante;
    private int DefensaFinalDesafiado;
    
    private Desafio desafiante;
    private Desafio desafiado;
    
    private int VidaDesafiante;
    private int VidaDesafiado;
    private int VidaEsbirrosDesafiante;
    private int VidaEsbirrosDesafiado;
    
    private Jugador juAnte;
    private Jugador juAdo;
    private int oroApostado;
    private String[] resumenTotal;
    
    public Combate(int oroApostado, Jugador juAnte, Jugador juAdo, Desafio desafiante, Desafio desafiado) throws ClassNotFoundException{
        this.oroApostado = oroApostado;
        this.juAnte = juAnte;
        this.juAdo = juAdo;
        this.desafiado = desafiado;
        this.desafiante = desafiante;
        this.VidaDesafiante = desafiante.getSaludTotal();
        this.VidaDesafiado = desafiado.getSaludTotal();
        this.VidaEsbirrosDesafiante = desafiante.getSaludEsbirros();
        this.VidaEsbirrosDesafiado = desafiado.getSaludEsbirros();
        
        this.crearDesafio(oroApostado);
    }
    
    public void crearDesafio(int oroApostado) throws ClassNotFoundException{
        //inicializar el potencial de ataque de cada uno y defensa
            //Desafiante
        this.AtaqueFinalDesafiante = potencialAtaque(desafiante);
        this.DefensaFinalDesafiante = potencialDefensa(desafiante);
            //Desafiado
        this.AtaqueFinalDesafiado = potencialAtaque(desafiado);
        this.DefensaFinalDesafiado = potencialDefensa(desafiado);
        
        //COMBATE
        int rondas = 0;
        while(comprobarVictoria()==1){
            
            //Si el ataque del desafiante es mayor que la defensa de desafiado, se le resta a la salud total de del desafiado una unidad de vida
            if(this.AtaqueFinalDesafiante > this.DefensaFinalDesafiado)
                VidaDesafiado -= 1;
            //Lo contrario
            if(this.AtaqueFinalDesafiado > this.DefensaFinalDesafiante)
                this.VidaDesafiante -= 1;
            
            //recalculamos los potenciales de la siguinete ronda
            this.AtaqueFinalDesafiante = potencialAtaque(desafiante);
            this.AtaqueFinalDesafiado = potencialAtaque(desafiado);
            this.DefensaFinalDesafiante = potencialDefensa(desafiante);
            this.DefensaFinalDesafiado = potencialDefensa(desafiado);
            
            rondas++;   //aumentamos el numero de rondas
        } 
        
        //Comprobamos que ha sucedido en el combate
        int victoria = comprobarVictoria();
        //Escribir el resumen por pantalla
        this.resumenCombate(victoria,rondas);
        
        
    }
    
    
    private void resumenCombate(int victoria, int rondas) throws ClassNotFoundException{
        
        String EstadoCombate = "";
        switch(victoria){
            case 2:
                EstadoCombate = "empate";  //2 = empate
                break;
            case 3:
                EstadoCombate = juAdo.getNickJu();  //3 = gana desafiado
                break;
            case 4:
                EstadoCombate = juAnte.getNickJu();     //4 = gana desafiante
                break;
        }
        
        Date fecha = new Date();
        
        //Guardamos el array para que se quede guardado en info desafio
        resumenTotal = new String[7];
        resumenTotal[0] = "Nombre del desafiante: "+juAnte.getNickJu()+".";
        resumenTotal[1] = "Nombre del desafiado: "+juAdo.getNickJu()+".";
        resumenTotal[2] = "Numero de rondas: "+rondas+".";
        resumenTotal[3] = "Fecha del combate: "+fecha+".";
        resumenTotal[4] = "Usuario vencedor: "+EstadoCombate+".";
        resumenTotal[5] = "Numero de esbirros vivos: "+esbirroVida(EstadoCombate)+".";
        resumenTotal[6] = "Oro ganado: "+oroApostado+".";
        
        //lo printeamos por pantalla
        System.out.println("");
        for(int i = 0; i<resumenTotal.length; i++)
            System.out.println(resumenTotal[i]);
    }

    
    private int esbirroVida(String EstadoCombate) throws ClassNotFoundException{
        
        //ESBIRRO VIVOS DE DESAFIADO (en el caso de que haya ganado)
        int numEsbirros = 0;
        if(EstadoCombate.equals(juAdo.getNickJu())){
            int vidaQuitada = desafiado.getSaludTotal() - VidaDesafiado ;   //recogemos vida total que le han quitado
            
            if(VidaEsbirrosDesafiado > vidaQuitada){    //si la vida que le han quitado es mayor a la vida de los esbirros significa que no quedan esbirros vivos
                int contadorVida = 0;                   //contador de la vida que llevamos de los esbirros
                int vidaEsbirroRestante = desafiante.getSaludEsbirros() - vidaQuitada;  //vida que queda de lso esbirros después del combate
                Esbirro esbrr = desafiado.getDesafiado().getEsbirro();      //inicializamos nuesro esbirro
                
                while(contadorVida < vidaQuitada || esbrr != null){   //los vamos recorriendo para saber cuantos quedan vivos
                   
                    if(contadorVida < vidaEsbirroRestante){         //si la vida que llevabamos de cada esbirro observado llega a ser mayor de la vida que ha quedado en total de los esbirros depues del combate
                        numEsbirros++;                                  //añadimos un esbirro al número de esbirros que han quedado vivos
                        contadorVida += esbrr.getSalud();               //sumamos la vida que llevamos de cada esbirro
                    }
                    esbrr = esbrr.getEsbirroDe();                  //cogemos el siguinete esbirro en caso de que tenga
                }
            }
            
            //si el oro del perdedor es mayor que el oro apostado se gana y pierde su completitud
            if(juAnte.getPersonaje().getOroPer() >= oroApostado){
                juAdo.getPersonaje().setOroPer((int) (juAdo.getPersonaje().getOroPer() + oroApostado));
                juAnte.getPersonaje().setOroPer((int) (juAnte.getPersonaje().getOroPer() - oroApostado));
            }
            //si el oro del perdedor es menor que el oro apostado y mayor que 0 se gana y pierde su lo que tenga el perdedor
            else if(juAnte.getPersonaje().getOroPer() <= oroApostado && juAnte.getPersonaje().getOroPer() > 0){
                juAdo.getPersonaje().setOroPer((int) (juAdo.getPersonaje().getOroPer() + juAnte.getPersonaje().getOroPer()));
                juAnte.getPersonaje().setOroPer(0);
            }
            //Si no se cumple ninguna de las dos condiciones significa que el perdedor tiene 0 oro y por tanto el ganador no puede ganar nada
            
            juAdo.getArrayOro().add(juAdo.getPersonaje().getOroPer());
            juAnte.getArrayOro().add(juAnte.getPersonaje().getOroPer());
        }
        
        
        //ESBIRRO VIVOS DE DESAFIANTE (en el caso de que haya ganado)
        if(EstadoCombate.equals(juAnte.getNickJu())){
            int vidaQuitada = desafiado.getSaludTotal() - VidaDesafiado ;
            
            if(VidaEsbirrosDesafiante > vidaQuitada){    //si la vida que le han quitado es mayor a la vida de los esbirros significa que no quedan esbirros vivos
                int contadorVida = 0;                   //contador de la vida que llevamos de los esbirros
                int vidaEsbirroRestante = desafiante.getSaludEsbirros() - vidaQuitada;  //vida que queda de lso esbirros después del combate
                Esbirro esbrr = desafiante.getDesafiado().getEsbirro();      //inicializamos nuesro esbirro
                
                while(contadorVida < vidaQuitada || esbrr != null){   //los vamos recorriendo para saber cuantos quedan vivos
                   
                    if(contadorVida < vidaEsbirroRestante){         //si la vida que llevabamos de cada esbirro observado llega a ser mayor de la vida que ha quedado en total de los esbirros depues del combate
                        numEsbirros++;                                  //añadimos un esbirro al número de esbirros que han quedado vivos
                        contadorVida += esbrr.getSalud();               //sumamos la vida que llevamos de cada esbirro
                    }
                    esbrr = esbrr.getEsbirroDe();                  //cogemos el siguinete esbirro en caso de que tenga
                }
            }
            
            //si el oro del perdedor es mayor que el oro apostado se gana y pierde su completitud
            if(juAdo.getPersonaje().getOroPer() >= oroApostado){
                juAnte.getPersonaje().setOroPer((int) (juAnte.getPersonaje().getOroPer() + oroApostado));
                juAdo.getPersonaje().setOroPer((int) (juAdo.getPersonaje().getOroPer() - oroApostado));
            }
            //si el oro del perdedor es menor que el oro apostado y mayor que 0 se gana y pierde su lo que tenga el perdedor
            else if(juAdo.getPersonaje().getOroPer() <= oroApostado && juAdo.getPersonaje().getOroPer() > 0){
                juAnte.getPersonaje().setOroPer((int) (juAnte.getPersonaje().getOroPer() + juAdo.getPersonaje().getOroPer()));
                juAdo.getPersonaje().setOroPer(0);
            }
            //Si no se cumple ninguna de las dos condiciones significa que el perdedor tiene 0 oro y por tanto el ganador no puede ganar nada
            
            juAdo.getArrayOro().add(juAdo.getPersonaje().getOroPer());
            juAnte.getArrayOro().add(juAnte.getPersonaje().getOroPer());
        }
        
        RecargarFicheros reacr = new RecargarFicheros();
        reacr.guardarJugador(juAdo);
        reacr.guardarJugador(juAnte);
        
        return numEsbirros;
    }
    
    
    private int potencialAtaque(Desafio des){
        int intentos = 0;
        int ataqueFinal = 0;
        for(int i= 0;i<des.getDañoTotal();i++){
            intentos = (int) (Math.random()*6+1);
            if(intentos>=5)
                ataqueFinal += 1;
        }
        
        return ataqueFinal;
        
    }

    private int potencialDefensa(Desafio des){
        int intentos = 0;
        int defensaFinal = 0;
        for(int i= 0;i<des.getDefensaTotal();i++){
            intentos = (int) (Math.random()*6+1);
            if(intentos>=5)
                defensaFinal += 1;
        }
        
        return defensaFinal;
        
    }
    

    private int comprobarVictoria(){
        if(VidaDesafiante > 0 && VidaDesafiado > 0)        // sigue combate
            return 1;
        else if(VidaDesafiado == 0 && VidaDesafiante == 0) //empate
            return 2;
        else if(VidaDesafiado > 0 && VidaDesafiante == 0) // gana desafiado
            return 3;
        else                                              // gana desafiante
            return 4;
    } 
}
