package practica;

import java.io.Serializable;

public class Debilidades implements Serializable {
    private String nombre_debilidad;
    private int sensibilidad; //numero del 1 al 5
    private boolean activo;
    
    public Debilidades (String nombre_debilidad, int sensibilidad, boolean activo) {
        this.nombre_debilidad = nombre_debilidad;
        this.sensibilidad = sensibilidad;
        this.activo = activo;
    }

    //GETTER
    public String getNombre_debilidad() {
        return nombre_debilidad;
    }

    public int getSensibilidad() {
        return sensibilidad;
    }

    //SETTER
    public void setNombre_debilidad(String nombre_debilidad) {
        this.nombre_debilidad = nombre_debilidad;
    }

    public void setSensibilidad(int sensibilidad) {
        this.sensibilidad = sensibilidad;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
}
