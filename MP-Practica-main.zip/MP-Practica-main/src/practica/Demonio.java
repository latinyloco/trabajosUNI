package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;

public class Demonio extends Esbirro implements Serializable{
    private boolean pacto;
    private String descripcion_pacto;
    private Esbirro esbirroDe;
    
    transient Scanner sn = new Scanner(System.in);
    
    
    public Demonio (String nombre_esbirro, int salud, boolean pacto, String descripcion_pacto) throws IOException {
        super(nombre_esbirro, salud);
        this.pacto = pacto;
        this.descripcion_pacto = descripcion_pacto;
        esbirroDe = this.dameEsbirro();
    }

    public boolean isPacto() {
        return pacto;
    }

    public String getDescripcion_pacto() {
        return descripcion_pacto;
    }
    
    @Override
    public Esbirro getEsbirroDe() {
        return esbirroDe;
    }
    
    @Override
    public void setEsbirroDe(Esbirro esbirro){
        this.esbirroDe = esbirro;
    }
    
    public Esbirro dameEsbirro() throws IOException{
        
        System.out.println("¿Quiere que su demonio tenga un esbirro?");
        System.out.println("1. Si   2. No");
        System.out.print("    Opcion: ");
        int opc = sn.nextInt();
        sn.nextLine();
        
        if(opc == 1)
            esbirroDe = this.elegirEsbirro();
        else
            esbirroDe = null;
        
        return esbirroDe;
 
    }
    
    private Esbirro elegirEsbirro() throws IOException{
        System.out.println("Tipo esbirro: ");
        System.out.println("1. Ghoul");
        System.out.println("2.Demonio");
        System.out.println("3.Humano");
        int tipo = sn.nextInt();
        sn.nextLine();
        esbirroDe = this.dameTipo(tipo);
        return esbirroDe;
    }
    
    private Esbirro dameTipo(int tipo) throws IOException{
        System.out.print("Nombre esbirro: ");
        String nombre = sn.nextLine();
        System.out.print("Salud esbirro: ");
        int salud = sn.nextInt();
        sn.nextLine();
        
        switch (tipo) {
            case 1:
                System.out.print("Dependencia Ghoul: ");
                int dep = sn.nextInt();
                sn.nextLine();
                return new Ghoul(nombre,salud,dep);
                
            case 2:
                System.out.println("Hacer pacto con demonio: ");
                System.out.println("1. Si     2. Nop: ");
                int pac =sn.nextInt();
                sn.nextLine();
                boolean pacto;
                String descripPacto;
                if(pac == 2){
                    System.out.println("No has aceptado el pacto... Escoge otro esbirro");
                    esbirroDe = this.elegirEsbirro(); 
                    
                }else{
                    pacto = true;
                    System.out.print("Escribe el pacto: ");
                    descripPacto = sn.nextLine();
                    return new Demonio(nombre,salud,pacto,descripPacto);
                    
                }
                break;
                
                
            
            case 3:
                System.out.print("Lealtad con humano: ");
                String lealtad = sn.nextLine();
                return new Humano(nombre,salud,lealtad);
            
            default: return null;
        }
        return null;
    }
}
