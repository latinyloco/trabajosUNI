/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author d.rodriguezgal.2020
 */
public class Desafio implements Serializable{
    private int SaludEsbirros;
    private int SaludPersonaje;
    private int saludTotal;
    private int potencialAtaque;  
    private int potencialDefensa;
    private int dañoTotal = 0;
    private int defensaTotal = 0;
    private Personaje desafiado;
    private Jugador juDe;
    
    
    public Desafio(Jugador juDe, int tipo) {   
        this.juDe = juDe;
        this.desafiado=juDe.getPersonaje();
        this.SaludEsbirros = this.sumaSalud();
        this.SaludPersonaje = desafiado.getSaludPer();
        this.inicioCombate(tipo);
    }
    
    
   //Sumar salud de esbirros 
    private int sumaSalud(){
       int cont = 0;
       Esbirro br = desafiado.getEsbirro();
       do{
           cont += br.getSalud();
           br = br.getEsbirroDe();
       }while(br != null);
       return cont;
    }
    
    
    private void inicioCombate(int tipo){
        switch(tipo){
            case 1:
                Vampiro vampiro = (Vampiro) desafiado;
                saludTotal = SaludEsbirros + SaludPersonaje;
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();

                if (vampiro.getSangre() >= 5)
                    dañoTotal += 2;
                break;
                
            case 2:
                Licantropo licantropo = (Licantropo) desafiado;
                saludTotal = SaludEsbirros + SaludPersonaje;
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();
                
                if (licantropo.getRabia() == 3)
                    dañoTotal += 1;
                break;
        
            case 3:
                Cazador cazador = (Cazador) desafiado;
                saludTotal = SaludEsbirros + SaludPersonaje;
                dañoTotal = this.calculoDaño();
                defensaTotal = this.calculoDefensa();
        }      
    }
    
    private int calculoDaño(){
        int dañoArma2 = 0;
        int dañoArma1 = desafiado.getArma_activa1().getAtaque();
        if (desafiado.getArma_activa2() != null)
            dañoArma2 = desafiado.getArma_activa2().getAtaque();
        
        ArrayList<Fortalezas> fort = desafiado.getFortaleza();
        int daño = 0;
        daño = desafiado.getPoderPer() + dañoArma1 + dañoArma2 + desafiado.getArmadura_activa().getAtaque(); 
        for (int i = 0; i < fort.size(); i++) {
            if (fort.get(i).isActivo()) {
                daño += fort.get(i).getEficiencia();
            }

        }
        return daño;
    }
    
    
    private int calculoDefensa(){
        int defensaArma2 = 0;
        
        int defensaArma1 = desafiado.getArma_activa1().getDefensa();
        if (desafiado.getArma_activa2() != null)
            defensaArma2 = desafiado.getArma_activa2().getDefensa();
        
        ArrayList<Debilidades> deb = desafiado.getDebilidad();
        int defensa = 0;
        defensa = defensaArma1 + defensaArma2 + desafiado.getArmadura_activa().getDefensa(); 
        for (int i = 0; i < deb.size(); i++) {
            if (deb.get(i).isActivo()) {
                defensa -= deb.get(i).getSensibilidad();
            }

        }
        return defensa;
    }

    public int getSaludEsbirros() {
        return SaludEsbirros;
    }

    public int getSaludPersonaje() {
        return SaludPersonaje;
    }

    public int getSaludTotal() {
        return saludTotal;
    }

    public int getDañoTotal() {
        return dañoTotal;
    }

    public int getDefensaTotal() {
        return defensaTotal;
    }

    public Personaje getDesafiado() {
        return desafiado;
    }
    
}
