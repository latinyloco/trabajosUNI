package practica;

import java.io.Serializable;

public class Disciplina extends Habilidades implements Serializable{
    private int costeSangre; // VALOR ENTRE 1 Y 3, SE VA RESTANDO A LA RESERVA DE SANGRE DEL VAMPIRO EN CADA USO
    
    
    public Disciplina (String nombre_habilidad, int ataque_habilidad, int defensa_habilidad, int costeSangre) {
        super(nombre_habilidad, ataque_habilidad, defensa_habilidad);
        this.costeSangre = costeSangre;
    }
    
    public int getCoste_sangre (){
        return costeSangre;
    }
}