package practica;

import java.io.Serializable;

public class Dones extends Habilidades implements Serializable{
    private int minRabia; // VALOR DE RABIA PARA USAR EL DON DEBE SER <= VALOR DE RABIA ACTUAL DEL LICANTROPO
    
    public Dones (String nombre_habilidad, int ataque_habilidad, int defensa_habilidad, int minRabia) {
        super(nombre_habilidad, ataque_habilidad, defensa_habilidad);
        this.minRabia = minRabia;
    }
    
    public int getMin_rabia (){
        return minRabia;
    }
}