package practica;

import java.io.Serializable;

public abstract class Esbirro implements Serializable{
    private String nombre_esbirro;
    private int salud;
    int dañoTotal;
    
    public Esbirro (String nombre_esbirro, int salud) {
        this.nombre_esbirro = nombre_esbirro;
        this.salud = salud;
    }

    //GETTER
    public String getNombre_esbirro() {
        return nombre_esbirro;
    }

    public int getSalud() {
        return salud;
    }

    //SETTER
    public void setNombre_esbirro(String nombre_esbirro) {
        this.nombre_esbirro = nombre_esbirro;
    }

    public void setSalud(int salud) {
        this.salud = salud;
    }

    public abstract Esbirro getEsbirroDe();
   
    public abstract void setEsbirroDe(Esbirro esbirro);
}
