package practica;

import java.io.Serializable;


public class Fortalezas implements Serializable{
    private String nombre_fortaleza;
    private int eficiencia; //numero del 1 al 5
    private boolean activo;
    
    public Fortalezas (String nombre_fortaleza, int eficiencia, boolean activo) {
        this.nombre_fortaleza = nombre_fortaleza;
        this.eficiencia = eficiencia;
        this.activo = activo;
    }
    
    //GETTER
    public String getNombre_fortaleza() {
        return nombre_fortaleza;
    }

    public int getEficiencia() {
        return eficiencia;
    }

    //SETTER
    public void setNombre_fortaleza(String nombre_fortaleza) {
        this.nombre_fortaleza = nombre_fortaleza;
    }

    public void setEficiencia(int eficiencia) {
        this.eficiencia = eficiencia;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    
    
}
