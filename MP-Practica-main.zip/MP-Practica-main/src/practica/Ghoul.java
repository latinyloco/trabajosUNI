package practica;

import java.io.Serializable;

public class Ghoul extends Esbirro implements Serializable{
    private int dependencia;
    
    public Ghoul (String nombre_esbirro, int salud, int dependencia){
        super(nombre_esbirro,salud);
        this.dependencia = dependencia;
    }

    public int getDependencia() {
        return dependencia;
    }

    @Override
    public Esbirro getEsbirroDe() {
        return null;
    }
    
    @Override
    public void setEsbirroDe(Esbirro esbirro){
    }
}
