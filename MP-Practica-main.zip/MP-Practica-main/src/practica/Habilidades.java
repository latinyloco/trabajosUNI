package practica;

import java.io.Serializable;

public class Habilidades implements Serializable {
    private String nombre_habilidad;
    private int ataque_habilidad; // VALOR ENTRE 1 Y 3
    private int defensa_habilidad; // VALOR ENTRE 1 Y 3
    
    //SETTERS
    public Habilidades (String nombre_habilidad, int ataque_habilidad, int defensa_habilidad) {
        this.nombre_habilidad = nombre_habilidad;
        this.ataque_habilidad = ataque_habilidad;
        this.defensa_habilidad = defensa_habilidad;
    }
    
    //GETTERS
    public String getNombre_habilidad() {
        return nombre_habilidad;
    }

    public int getAtaque_habilidad() {
        return ataque_habilidad;
    }   
    
    public int getDefensa_habilidad() {
        return defensa_habilidad;
    }

}