package practica;

import java.io.Serializable;

public class Humano extends Esbirro implements Serializable{
    private String lealtad;
    
    public Humano (String nombre_esbirro, int salud, String lealtad){
        super(nombre_esbirro,salud);
        this.lealtad = lealtad;
    }

    public String getLealtad() {
        return lealtad;
    }    

    @Override
    public Esbirro getEsbirroDe() {
        return null;
    }
    
    public void setEsbirroDe(Esbirro esbirro){
    }
}
