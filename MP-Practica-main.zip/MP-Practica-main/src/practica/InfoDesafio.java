package practica;

import java.io.Serializable;

public class InfoDesafio implements Serializable{

    private int numSerie;
    private int oroApostado;
    private String nickDesafiante;
    private String nickDesafiado;
    private Jugador ante;
    private Jugador ado;
    private Desafio desafiante;
    private Desafio desafiado;
    private Combate combate;
    private boolean eliminado;
    private boolean acabado;
    


    InfoDesafio(int oroApostado, String nickDesafiante, String nickDesafiado, Jugador desafiante, Jugador desafiado) {   
        this.oroApostado = oroApostado;
        this.nickDesafiante = nickDesafiante;
        this.nickDesafiado = nickDesafiado;
        this.ante = desafiante;
        this.ado = desafiado;
        eliminado = false;
        acabado = false;
        numSerie = this.getnumSerie();
    }
    
    
    //Crear Jugadores Y Combate
    public void cargarDesafiante(){
        desafiante = new Desafio(ante, ante.getPersonaje().getTipoPersonaje());
    }
    
    public void cargarDesafiado(){
        desafiado = new Desafio(ado, ado.getPersonaje().getTipoPersonaje());
    }
    
    public void cargarCombate() throws ClassNotFoundException{
        combate = new Combate(oroApostado,ante,ado,desafiante, desafiado);
    }
    
    private static int getnumSerie(){
        int n = (int) (Math.random() * 10000);
        return n;
    }
    
    
    
    //GETTERS
    public int getNumSerie() {
        return numSerie;
    }

    public boolean isAcabado() {
        return acabado;
    }

    public void setAcabado(boolean acabado) {
        this.acabado = acabado;
    }
    
    public Jugador getAnte() {
        return ante;
    }

    public Jugador getAdo() {
        return ado;
    }
    
    public int getOroApostado() {
        return oroApostado;
    }

    public String getDesafiante() {
        return nickDesafiante;
    }

    public String getDesafiado() {
        return nickDesafiado;
    } 

    public String getNickDesafiante() {
        return nickDesafiante;
    }

    public String getNickDesafiado() {
        return nickDesafiado;
    }  
    
    public boolean isEliminado() {
        return eliminado;
    }

    public void setEliminado(boolean eliminado) {
        this.eliminado = eliminado;
    }

    public void setAdo(Jugador ado) {
        this.ado = ado;
    }
    
    
}