package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Jugador implements Serializable{
    
    private Personaje personaje;
    private String nombreJu;
    public String nickJu;
    private String password;
    private String n_registroJu;
    private int tipo;
    
    private boolean baneado;
    private boolean notificacionJu;
    private ArrayList <Integer> arrayOro;
    
    transient Scanner sn1 = new Scanner(System.in);
    
          
    public Jugador(String nombreJu, String nickJu, String password, String n_registroJu) throws IOException{
        this.nombreJu = nombreJu;
        this.nickJu = nickJu;
        this.password = password;
        this.n_registroJu = n_registroJu;
        personaje = this.elegirPersonaje();
        notificacionJu = false;
        baneado = false;
        this.arrayOro = new ArrayList<>();
       
    }

    //GETTERS
    public Personaje getPersonaje() {
        return personaje;
    }
    
    public String getNickJu() {
        return nickJu;
    }
    
    public String getN_registroJu() {
        return n_registroJu;
    }
    
     public String getPassword() {
        return password;
    }

    public boolean isBaneado() {
        return baneado;
    }

    public boolean isNotificacionJu() {
        return notificacionJu;
    }

    public ArrayList getArrayOro() {
        return arrayOro;
    }

    public int getTipo() {
        return tipo;
    } 
    
    //SETTERS
    public void setNombreJu(String nombreJu) {
        this.nombreJu = nombreJu;
    }

    public void setNickJu(String nickJu) {
        this.nickJu = nickJu;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setN_registroJu(String n_registroJu) {
        this.n_registroJu = n_registroJu;
    }

    public void setBaneado(boolean baneado) {
        this.baneado = baneado;
    }

    public void setNotificacionJu(boolean notificacionJu) {
        this.notificacionJu = notificacionJu;
    }

    public void setArrayOro(ArrayList arrayOro) {
        this.arrayOro = arrayOro;
    }
    
    public void setPersonaje(Personaje personaje) {
        this.personaje = personaje;
    }
   


    //AÑADIR ORO
    public void actualizarOro(){
        arrayOro.add(personaje.getOroPer());
    }
    
    
    //ELEGIR PERSONAJE
    public Personaje elegirPersonaje() throws IOException{
        do{
            System.out.println("Tipo personaje: ");
            System.out.println("1. Vampiro");
            System.out.println("2. Licantropo");
            System.out.println("3. Cazador");
            String typo = sn1.nextLine();
            tipo = pruebaMe(typo,1,3);
        }while(tipo == -1);

        personaje = this.elegirPersoanje(tipo);
        return personaje; 
    }

    public Personaje elegirPersoanje(int tipo) throws IOException{
        
        Scanner sn1 = new Scanner(System.in);
        
        System.out.print("Nombre personaje: ");
        String nombre_per = sn1.nextLine();
        
        int oro_per;
        do{
            System.out.print("Oro personaje: ");
            String oro_pe = sn1.nextLine();
            oro_per = pruebaMe(oro_pe, 0, 1_000_000);
        }while(oro_per == -1);
        
        int salud_per;
        do{
            System.out.print("Salud personaje: ");
            String salud_pe = sn1.nextLine();
            salud_per = pruebaMe(salud_pe, 0, 5);
        }while(salud_per == -1);
        
        int poder_per;
        do{
            System.out.print("Poder personaje: ");
            String poder_pe = sn1.nextLine();
            poder_per = pruebaMe(poder_pe, 1, 5);
        }while(poder_per == -1);
        
        int ataque;
        do{
            System.out.print("Ataque personaje: ");
            String ataqu = sn1.nextLine();
            ataque = pruebaMe(ataqu, 1, 3);
        }while(ataque == -1);
        
        int defensa;
        do{
            System.out.print("Defensa personaje: ");
            String defens = sn1.nextLine();
            defensa = pruebaMe(defens, 1, 3);
        }while(defensa == -1);
        
        
        ArrayList <Fortalezas> fortaleza = new ArrayList<Fortalezas>();
        
        ArrayList <Debilidades> debilidad = new ArrayList<Debilidades>();
        
        ArrayList <Armadura> armadura = new ArrayList<Armadura>();
        armadura.add(new Armadura("Pechera",0,2));
        
        ArrayList <Arma> arma = new ArrayList<Arma>();
        arma.add(new Arma("Martillo",1,0,false));
        arma.add(new Arma("Cuchillo",1,0,false));
        arma.add(new Arma("Lanza",2,0,true));
        
        switch (tipo) {
            case 1:
                return new Vampiro(nombre_per,oro_per,salud_per, poder_per,ataque,defensa,fortaleza,debilidad,armadura,arma,tipo);
            case 2:
                return new Licantropo(nombre_per,oro_per,salud_per, poder_per,ataque,defensa,fortaleza,debilidad,armadura,arma,tipo);
            case 3:
                return new Cazador(nombre_per,oro_per,salud_per, poder_per,ataque,defensa,fortaleza,debilidad,armadura,arma,tipo);
            default: return null;
        }
    }
    
    //devuelve un -1 si no es un número y no está en el rango, devuelve el número si cumple las dos cosas
    protected int pruebaMe(String num,int i, int f){
        boolean bol = false;
        int numero = dameInt(num);
        if(numero != -1){
            if(esRango(numero,i,f) == true)
                return numero;
            else
                System.out.println("  El rago de valores se comprende entre "+i+" y "+f+".");
        }
        return -1;
    }
    
    //devuelve un int de un string
    private int dameInt(String a){
        try{
            int b = Integer.parseInt(a);
            return b;
        }catch(Exception  e){
            System.out.println("  Introduzca un numero por favor.");
        }
        return -1;
    }
    
    //comprueba si está en el rango señalado
    private boolean esRango(int valor,int i, int f){
        boolean bo = false;
        if (valor>= i && valor<=f)
            bo = true;
        
        return bo;
    }
    
}
