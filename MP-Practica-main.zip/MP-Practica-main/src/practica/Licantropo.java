package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Licantropo extends Personaje implements Serializable{
    // Habilidad: Dones
    private String nombre = "Dones";
    private int ataque;
    private int defensa;  // Valores entre 1 y 3
    
    private boolean Bestia;
    private int rabia = 0;                // La rabia aumenta con el uso de algunas habilidades y el daño recibido,
                                          // y tendrá un valor entre 0 y 3    
    private boolean usoHabilidad = false; // Para comprobar si se ha usado una habilidad he pensado en usar un booleano, 
                                          // y cada vez que sea "true" sumarle un valr de rabia (poniendolo después de vuelta en "false")
    private int fortaleza;

    public Licantropo(String nombre_per, int oro_per, int salud_per, int poder_per, int ataque, int defensa, ArrayList <Fortalezas> fortalezas, ArrayList <Debilidades> debilidad, ArrayList <Armadura> armadura, ArrayList <Arma> arma, int tipo) throws IOException {
        super(nombre_per,oro_per,salud_per,poder_per,fortalezas,debilidad,armadura,arma,tipo);
        this.ataque = ataque;
        this.defensa = defensa;
        
    }

    
    // GETTERS
    public boolean isBestia() {
        return Bestia;
    }
    
    public int getRabia() {
        return rabia;
    }

    public boolean isUsoHabilidad() {
        return usoHabilidad;
    }    

    //SETTERS
    public void setRabia(int rabia) {
        this.rabia = rabia;
    }

}
