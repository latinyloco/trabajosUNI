package practica;

import java.io.IOException;


public class MAIN{

    public static void main(String[] args) throws IOException, ClassNotFoundException{

        Inicio ini = new Inicio();
        ini.MenuInicio();
    }  
}