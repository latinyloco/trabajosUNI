package practica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuJugador {
    
    private String[] rutasFicheros;     //rutas de los ficheros
    private String usuario;             //nick jugador
    private Jugador jugador;            //clase del jugador
    
    transient Scanner sn = new Scanner(System.in);
    
    //CONSTRUCTOR
    public MenuJugador(String[] rutasFicheros, String usuario){
        this.rutasFicheros = rutasFicheros;
        this.usuario = usuario; 
    }
    

    
    //GETTERS
    public Jugador getJugador() {
        return jugador;
    }
    
    
    
    //MENÚ JUGADOR
    public void menuJu() throws IOException, FileNotFoundException, ClassNotFoundException{

        //Cargar jugador que ha iniciado sesión
        jugador = this.extraerJugador(rutasFicheros,usuario);
        
        //Si el jugador tiene una notificacion meterle al menu de desafios
        if(jugador.isNotificacionJu())
            this.menuDe();
        
        //Menú del jugador en el caso de que no tenga ninguna  noficación
        int opc = 0;
        while(opc!=6){
            System.out.println("Que deseas hacer:");
            System.out.println("1.Crear nuevo personaje     2.Crear nuevo esbirro    3.Desafiar jugador      4.Consultar oro      5.Consultar ranking       6.Salir");
            opc = sn.nextInt(); 
            sn.nextLine();
            
            switch(opc){
                case 1: 
                    System.out.println("");
                    System.out.println("-- Crear nuevo personaje --");
                    this.crearNuevoPer();
                    break;
                    
                case 2: 
                    System.out.println("");
                    System.out.println("-- Crear nuevo esbirro --");
                    this.crearNuevoEsb();
                    break;
                    
                case 3: 
                    System.out.println("");
                    System.out.println("-- Crear desafios --");
                    this.crearDesafio();
                    break;
                    
                case 4: 
                    System.out.println("");
                    System.out.println("-- Consultar oro --");
                    this.consultarOro();
                    break;
                    
                case 5: 
                    System.out.println("");
                    System.out.println("-- Consultar ranking --");
                    this.consultarRanking();
                    break;
                    
                                   
                case 6:
                    System.out.println("");
                    System.out.println("-- Salir --");
                    break;
            }
            System.out.println("");
            RecargarFicheros recar = new RecargarFicheros();
            recar.guardarJugador(jugador);
            //guardamos el jugador con todas las modificaciones que ha recibido, y eleminmos el jugador anticuado cada vez que cierre sesión
        }
    }
    
    private Jugador extraerJugador(String[] rutasFicheros, String usuario) throws FileNotFoundException, IOException, ClassNotFoundException{
        
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));   //recogemos el fichero y abrimos el lector
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();                               //leemos lo que hay en el fichero y lo guardamos en lista
                
        Jugador juega = null;       //inicializamos una variable para buscar nuestro jugador
        for(Jugador i: lista){      //recorremos la lista
            if(i.getNickJu().equals(usuario)){      //en el caso de que encontremos el usuario por medio de su nick, devuelvelo
                return i;                           //si no lo encuentra que devuelva null
            }
        }
        return null;
    }
    
    
 /////OPCIONES DEL MENÚ
    
    //CONSULTAR RANKING
    public void consultarRanking() throws IOException, FileNotFoundException, ClassNotFoundException{
        
        Ranking ranking = new Ranking();    //crea clase ranking
        ranking.CargarRanking();            //devuelve ranking
    }
            
    
    //CONSULTAR ORO
    public void consultarOro(){

        
        if (jugador.getArrayOro().isEmpty()){                         //en el caso de que el array de del oro de las jugadas esté vacio
            System.out.println(" No hay partidas guardadas.");          //escribir que no hay àrtidas guardadas
        }else{                                                      //sino
            ArrayList <Integer> orito = jugador.getArrayOro();          //coger el array del oro
            int cont = 0;                                               //inicializar un contador
               
            for (Integer i: orito){                                     //recorrer el array entero
                System.out.println(" Partida "+(cont+1)+": "+i);        //mostrar el oro de la casilla i que corresponde con el desafio i
                cont += 1;                                              //aumentar el número de partida
            }
        }
    }
    
    
    //CREAR NUEVO PERSONAJE
    public void crearNuevoPer() throws IOException{
        Personaje newJu = jugador.elegirPersonaje();    //creamos un nuevo personaje desde la clase personaje
        jugador.setPersonaje(newJu);                    //usar el setJugador
    }
    
    
    //CREAR NUEVO ESBIRRO
    public void crearNuevoEsb() throws IOException{                     //lo mismo de arriba pero con eSbirro
        Esbirro newEs = jugador.getPersonaje().elegirEsbirro();
        jugador.getPersonaje().setEsbirro(newEs);
    }
    
    
    
    
 /////MENU DESAFIO
    
    //MENU NOTIFICACION  
    private void menuDe() throws IOException, FileNotFoundException, ClassNotFoundException {
        System.out.println("");
        System.out.println("[TIENES DESAFIOS POR CONFIRMAR:]");
        
        RecargarFicheros rec = new RecargarFicheros();
        InfoDesafio infoD = rec.RecuperarDesafio(jugador.getNickJu());      //recuperamos el desafio por el cual le han desafiado
        System.out.println("Deseas aceptar el combate de: "+infoD.getNickDesafiante());
        System.out.println(" 1. Si      2. No");        //se da la elección de aceptar el combate o no
        System.out.print(" Eleccion: ");
        int opcion = sn.nextInt();
        sn.nextLine();

        //SI SE ACEPTA
        if(opcion == 1){                    
            System.out.println("");
            System.out.println("__ Elige armas__");     //elegimos las armas para combatir
            System.out.println();
            infoD.getAdo();
            this.elegirArmas();

            //Recargamos las fortalezas y debilidades elegidas por el operador
                //Fortalezas
            ArrayList <Fortalezas> fortote = jugador.getPersonaje().getFortaleza();
            int cuount = 0;
            for(Fortalezas i: fortote){
                if(infoD.getAdo().getPersonaje().getFortaleza().get(cuount).isActivo())
                    i.setActivo(true);
                cuount++;
            }
            
                //Debilidades
            ArrayList <Debilidades> debilucho = jugador.getPersonaje().getDebilidad();
            cuount = 0;
            for(Debilidades j: debilucho){
                if(infoD.getAdo().getPersonaje().getDebilidad().get(cuount).isActivo())
                    j.setActivo(true);
                cuount++;
            }
            
            //Guardamos el desafioado pra cargar el combate
            infoD.setAdo(jugador);      //incluimos en el desafio nuestro perfil cargado con las armas para el combate y las fortalezas y beilidades
            infoD.cargarDesafiado();    //guardamos el desafiado con las armas
            
            //Empezamos el combate
            System.out.println("");
            System.out.println("----- QUE COMIENCE EL COMBATE -----");
            System.out.println("  Que gane el que tenga mas suerte...");
            System.out.println("");
            infoD.cargarCombate();      //se hace el combate
            System.out.println("");
            infoD.setAcabado(true);     //se indica que el combate se ha realizado y que por tanto no hay que eliminarlo
            
            //Reseteamos fortalezas y debilidades
            for(Fortalezas i: jugador.getPersonaje().getFortaleza()){
                i.setActivo(false);
            }
            for(Debilidades i: jugador.getPersonaje().getDebilidad()){
                i.setActivo(false);
            }
            
            
        //SI NO SE ACEPTA
        }else{                          
            System.out.println("");
            int cantidad10por = (int) (infoD.getOroApostado() * 0.9);
            
            if((jugador.getPersonaje().getOroPer()-cantidad10por)>0)       //si no se va a quedar en numeros rojos
                jugador.getPersonaje().setOroPer((int) (jugador.getPersonaje().getOroPer() + cantidad10por));   //le restamos lo que respecta
            else
                jugador.getPersonaje().setOroPer(0);   //sino le ponemos 0 monedas
            
            jugador.getPersonaje().setOroPer((int) (jugador.getPersonaje().getOroPer()- cantidad10por));  //el jugador que ha rechazdo pierde un 10% del oro apostado
            jugador.getArrayOro().add(jugador.getPersonaje().getOroPer());      //guardamos el dinero en el registro de dinero de combates
            
            Jugador jugadorr = infoD.getAnte(); //Cogemos el jugador que ha desafiado y que por tanto se lleva el dinero
            jugadorr.getPersonaje().setOroPer((int) (jugador.getPersonaje().getOroPer() + cantidad10por));  //le sumamos la cantidad de dinero que debe recibir
            jugadorr.getArrayOro().add(jugadorr.getPersonaje().getOroPer());        //guardamos el dinero en el registro de dinero de combates
            rec.guardarJugador(jugadorr);                                           //guardamos el jugador actualizamos y eleminamos el antiguo
            
            System.out.println("Ha perdido un 10% del su oro apostado = -"+cantidad10por);
            infoD.setEliminado(true);           //se indica que el combate no ha llegado a arealizarse pero sí que lo ha validado un operador
        }
        
        rec.saveDes(infoD);                 //guardamos de nuevo del desafio con sus respectivas notificaciones
        jugador.setNotificacionJu(false);   //hacemos que el jugador ya no tenga notificacaciones
        rec.guardarJugador(jugador);        //guardamos el jugador que ha sido desafiaado
        
    }
    

    //CREAR DESAFIO
    public void crearDesafio() throws IOException, ClassNotFoundException {
        
        //Si el oro del personaje es mayor que puede desafiar
        if (jugador.getPersonaje().getOroPer() > 0) {       
            int oroApostado = 9999999;      //añadimos un tope de dinero que puede desafiar
            int oroDisponible = jugador.getPersonaje().getOroPer();     //cogemos el total del oro del personaje
                     
            //Elegir armas para el combate
            System.out.println("__ Elige armas__");
            System.out.println();
            this.elegirArmas();

            //Mostrar jugadores diponibles
            System.out.println("__ Jugadores disponibles __");
            RecargarFicheros recarga = new RecargarFicheros();
            recarga.muestraJugadores(rutasFicheros[0]);
            System.out.println("");
            System.out.print("Recuerda, si retas a un jugador que no tiene dinero no ganaras nada.");
            System.out.println("");

            //Bucamos el jugador que nos han introducido por consola
             String nickJ2 = "";
            Jugador juega = null;
            do {
                System.out.print("Escribe el nick del jugador a desafiar (no te puedes desafiar a ti mismo): ");
                nickJ2 = sn.nextLine();
                juega = this.extraerJugador(rutasFicheros, nickJ2);
            } while (juega == null || jugador.getNickJu().equals(nickJ2));       //si el jugador que nos han introducido no existe, vuelve a pedir de nuevo otro nick
            
            //Escoger oro para el combate
            while (oroApostado > oroDisponible || oroApostado < 0) {
                System.out.print("Escribe el oro a apostar en el desafio (debe ser menor que el que posea...): ");
                oroApostado = sn.nextInt();
                sn.nextLine();
            }
            
            //Cargamos nuestro jugador con el vamos a desafiar a otra persona con las armas ya cargadas
            InfoDesafio desafio = new InfoDesafio(oroApostado, jugador.getNickJu(), juega.getNickJu(), jugador, juega);
            desafio.cargarDesafiante();

            //guardamos el desafio
            RecargarFicheros rect = new RecargarFicheros();
            rect.GuardarDesafio(desafio);
            
        
        //Si el oro del personaje no es mayor que 0, no puede desafiar
        } else                                          
            System.out.println("No tienes sufiente dinero, dile a un operador que te ayude.");
    }
    
    
    //ELEGIR ARMAS 
    public void elegirArmas() throws ClassNotFoundException{
        ArrayList <Arma> arma = jugador.getPersonaje().getArma();               //cogemos el alijo de armas del personaje
        ArrayList <Armadura> armadura = jugador.getPersonaje().getArmadura();   //cogemos el alijo de armaduras del personaje
        
        
        //ARMAS
        //Mostrar armas
        System.out.println("    __Armas__");
        for(int i = 0; i<arma.size(); i++){
            System.out.println((i+1) + ".- " + "Nombre: "+arma.get(i).getNombre_arma()+"  Ataque: "+arma.get(i).getAtaque()+"  Defensa: "+arma.get(i).getDefensa()+"    Dos Manos: "+arma.get(i).getdosManos() );
        }
        
        //Elegir armas
        int opcion = 0;
        do {
            System.out.print("Escoge un numero: ");
            String opcion0 = sn.nextLine();
            opcion = pruebaMe(opcion0, 1, arma.size());
        } while (opcion == -1);
        
        //Activar armaa activa 1
        jugador.getPersonaje().setArma_activa1(arma.get(opcion-1));
        
        //Si el arma 1 era solo de una mano
        if (arma.get(opcion-1).getdosManos() == false){
            //Elegir si se quiere otra arma
            opcion = 0;
            do {
                System.out.println("Quieres usar otra arma en tu segunda mano?");
                System.out.println("1.Si        2.No");
                System.out.print("  Eleccion: ");
                String opcion0 = sn.nextLine();
                opcion = pruebaMe(opcion0, 1, 2);
            } while (opcion == -1);
            
            //Elegir arma activa 2
            switch(opcion){
                case 1:
                    System.out.println("Escoge el arma: ");
                    for(int i = 0; i<arma.size(); i++){
                        System.out.println((i+1) + ".- " + "Nombre: "+arma.get(i).getNombre_arma()+"  Ataque: "+arma.get(i).getAtaque()+"  Defensa: "+arma.get(i).getDefensa()+"    Dos Manos: "+arma.get(i).getdosManos());
                    }
                    System.out.println("Escoge un numero: ");
                    opcion = sn.nextInt();
                    sn.nextLine();
                    if(!jugador.getPersonaje().getArma_activa1().equals(arma.get(opcion-1))){
                        if(arma.get(opcion-1).getdosManos() == true){
                            System.out.println("No puedes escoger un arma de dos manos");
                        }else{
                            jugador.getPersonaje().setArma_activa2(arma.get(opcion-1));
                        }
                    }
                    break;
                case 2:break;
            }
        }
        
        
        //ARMADURAS
        //Mostrar armaduras
        System.out.println("");
        System.out.println("    __Armaduras__");
        for(int i = 0; i<armadura.size(); i++){
            System.out.println((i+1) + ".- " + armadura.get(i).getNombre_armadura()+"  Ataque: "+armadura.get(i).getAtaque()+"  Defensa: "+armadura.get(i).getDefensa());
        }
        
        //Elegir armaduras
        opcion = 0;
        do {
            System.out.print("Escoge un numero: ");
            String opcion0 = sn.nextLine();
            opcion = pruebaMe(opcion0, 1, armadura.size());
        } while (opcion == -1);
        
        System.out.print("");

        //Guardar armadura activa
        jugador.getPersonaje().setArmadura_activa(armadura.get(opcion-1));
        
        //Guardar juagdor en el fichero
        RecargarFicheros recarga = new RecargarFicheros();
        recarga.guardarJugador(jugador);
    }
    
    
    
 /////COMPROBACIONES
    
    //devuelve un -1 si no es un número y no está en el rango, devuelve el número si cumple las dos cosas
    protected int pruebaMe(String num,int i, int f){
        boolean bol = false;
        int numero = dameInt(num);
        if(numero != -1){
            if(esRango(numero,i,f) == true)
                return numero;
            else
                System.out.println("  El rago de valores se comprende entre "+i+" y "+f+".");
        }
        return -1;
    }
    
    //comprueba si se ha introducido un int correctamente, devuelve un int de un string o -1 si el int era un String
    private int dameInt(String a){
        try{
            int b = Integer.parseInt(a);
            return b;
        }catch(Exception  e){
            System.out.println("  Introduzca un numero por favor.");
        }
        return -1;
    }
    
    //comprueba si está en el rango señalado y devuelve un booleano
    private boolean esRango(int valor,int i, int f){
        boolean bo = false;
        if (valor>= i && valor<=f)
            bo = true;
        
        return bo;
    }
    
}