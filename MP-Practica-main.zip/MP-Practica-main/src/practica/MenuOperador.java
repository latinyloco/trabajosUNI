package practica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuOperador{
    
    transient Scanner sn = new Scanner(System.in);
    Inicio ini = new Inicio();
    private String[] rutasFicheros;
    private String usuario;
    private Jugador jugador;
    RecargarFicheros recarga = new RecargarFicheros();
    private Esbirro esbirro;
    
    public MenuOperador(String[] rutasFicheros, String usuario){
        this.rutasFicheros = rutasFicheros;
        this.usuario = usuario; 
    }
    
    public void menuOp() throws IOException, ClassNotFoundException{
        String opcc = "";
        int opc = 0;
        while(opc!=5){
            System.out.println("");
            System.out.println("Que deseas hacer:");
            System.out.println("1.Editar un personaje     2.Aniadir a un personaje      3. Actualizar desafios     4.Banear/Desbanear      5.Salir");
            System.out.print("  Eleccion: ");
            opcc = sn.nextLine();
            opc = pruebaMe(opcc,1,5);
            switch(opc){
                case 1: 
                    System.out.println("");
                    System.out.println("-- Editar un personaje --");
                    this.editar(rutasFicheros);
                break;
                case 2: 
                    System.out.println("");
                    System.out.println("-- Añadir a un personaje --");
                    this.añadir(rutasFicheros);
                break;
                case 3:
                    System.out.println("");
                    System.out.println("-- Validar/Eliminar desafios --");
                    this.validar();
                break;
                case 4: 
                    System.out.println("");
                    System.out.println("-- Banear/Desbanear --");
                    this.banear(rutasFicheros);
                break;
                case 5: 
                    System.out.println("");
                    System.out.println("-- Salir --");  
                break;
            }
        }
    }
    
    //VALIDAR
    private void validar() throws FileNotFoundException, IOException, ClassNotFoundException{
        
        int opy = 0;
        do{
            System.out.println("Deseas    1. Validar desafios      2. No validar desafios  ");
            System.out.print("  Eleccion: ");
            String opyy = sn.nextLine();
            opy = pruebaMe(opyy,1,2);
        }while(opy == -1);
        System.out.println("");
        System.out.println("__ Desafios __");
        try {
            ObjectInputStream info1 = new ObjectInputStream(new FileInputStream("C:\\FicherosMP\\ZDesafio.txt"));
            ArrayList<InfoDesafio> listaDE = (ArrayList) info1.readObject();
            info1.close();

            if (!listaDE.isEmpty()) {
                int conh = 1;
                for (InfoDesafio k : listaDE) {
                    if (k.isEliminado() == false && k.isAcabado() == false) {
                        System.out.println(conh + ". " + k.getDesafiante() + " vs " + k.getDesafiado());
                    }
                    conh++;
                }

                int opt = 0;
                do {
                    System.out.print("  Eleccion: ");
                    String optt = sn.nextLine();
                    opt = pruebaMe(optt, 1, listaDE.size());
                } while (opt == -1);
                InfoDesafio info3 = listaDE.get(opt - 1);
                System.out.println("");

                RecargarFicheros wer = new RecargarFicheros();
                if (opy == 1) {
                    ObjectInputStream leerFichero0 = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
                    ArrayList<Jugador> lista = (ArrayList) leerFichero0.readObject();
                    leerFichero0.close();

                    Jugador jugadorDesafiado = this.extraerJugador(lista, info3.getDesafiado());
                    jugadorDesafiado.setNotificacionJu(true);

                    this.escogerFortalezas(info3);
                    this.escogerDebilidades(info3);

                    wer.saveDes(info3);
                    wer.guardarJugador(jugadorDesafiado);

                } else {
                    wer.eliminarInfoDesafio(info3);
                }
            } else {
                System.out.println("No hay desafios que validar ni eliminar.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Ha habido un problema en el archivo de Desafios!");
        }
    }
    
    private void escogerFortalezas(InfoDesafio info3){
        //Desafiante
        int cont = 0;
        int opt = 0;
        if (!info3.getAnte().getPersonaje().getFortaleza().isEmpty()) {
            System.out.println("");
            System.out.println("__ Activar Fortalezas del Desafiante __");
            ArrayList<Fortalezas> fort = info3.getAnte().getPersonaje().getFortaleza();
            cont = 1;
            for (Fortalezas i : fort) {
                System.out.println(cont + ". Nombre: " + i.getNombre_fortaleza() + "  Eficiencia: " + i.getEficiencia());
                cont++;
            }

            opt = 0;
            do {
                System.out.print("  Eleccion (presione 0 para salir): ");
                String optt = sn.nextLine();
                opt = pruebaMe(optt, 0, fort.size());
                if (opt != 0) {
                    info3.getAnte().getPersonaje().getFortaleza().get(opt - 1).setActivo(true);
                }

            } while (opt == -1 || opt == 0);
            info3.cargarDesafiante();
        } else
            System.out.println("El desafiante no tiene fortalezas.");
        
        //Desafiado
        if (!info3.getAdo().getPersonaje().getFortaleza().isEmpty()) {
            System.out.println("");
            System.out.println("__ Activar Fortalezas del Desafiado __");
            ArrayList<Fortalezas> fort1 = info3.getAdo().getPersonaje().getFortaleza();
            cont = 1;
            for (Fortalezas j : fort1) {
                System.out.println(cont + ". Nombre: " + j.getNombre_fortaleza() + "  Eficiencia: " + j.getEficiencia());
                cont++;
            }

            opt = 0;
            do {
                System.out.print("  Eleccion (presione 0 para salir): ");
                String optt = sn.nextLine();
                opt = pruebaMe(optt, 0, fort1.size());
                if (opt != 0) {
                    info3.getAdo().getPersonaje().getFortaleza().get(opt - 1).setActivo(true);
                }

            } while (opt == -1 || opt == 0);
            info3.cargarDesafiado();
        } else
            System.out.println("El desafiado no tiene fortalezas.");   
    }
    
    
    private void escogerDebilidades(InfoDesafio info3){
        //Desafiante
        int cont = 0;
        int opt = 0;
        if (!info3.getAnte().getPersonaje().getDebilidad().isEmpty()) {
            System.out.println("");
            System.out.println("__ Activar Debilidades del Desafiante __");
            ArrayList<Debilidades> debi = info3.getAnte().getPersonaje().getDebilidad();
            cont = 1;
            for (Debilidades i : debi) {
                System.out.println(cont + ". Nombre: " + i.getNombre_debilidad() + "  Sensibilidad: " + i.getSensibilidad());
                cont++;
            }

            opt = 0;
            do {
                System.out.print("  Eleccion (presione 0 para salir): ");
                String optt = sn.nextLine();
                opt = pruebaMe(optt, 0, debi.size());
                if (opt != 0) {
                    info3.getAnte().getPersonaje().getDebilidad().get(opt - 1).setActivo(true);
                }

            } while (opt == -1 || opt == 0);
        } else
            System.out.println("El desafiante no tiene debilidades.");
        
        //Desafiado
        if (!info3.getAdo().getPersonaje().getDebilidad().isEmpty()) {
            System.out.println("");
            System.out.println("__ Activar Fortalezas del Desafiado __");
            ArrayList <Debilidades> debi1 = info3.getAdo().getPersonaje().getDebilidad();
            cont = 1;
            for (Debilidades j : debi1) {
                System.out.println(cont + ". Nombre: " + j.getNombre_debilidad() + "  Sensibilidad: " + j.getSensibilidad());
                cont++;
            }

            opt = 0;
            do {
                System.out.print("  Eleccion (presione 0 para salir): ");
                String optt = sn.nextLine();
                opt = pruebaMe(optt, 0, debi1.size());
                if (opt != 0) {
                    info3.getAdo().getPersonaje().getDebilidad().get(opt - 1).setActivo(true);
                }

            } while (opt == -1 || opt == 0);
        } else
            System.out.println("El desafiado no tiene debilidades.");
        
    }
    
    
    //EDITAR
    public void editar(String[] rutasFicheros) throws IOException, ClassNotFoundException{
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
        
        Jugador jugador = null;
        String player = "";
        do{
            System.out.println("Que personaje deseas editar?(Escribe su nombre) : ");
            this.muestraJugadores("C:\\FicherosMP\\Jugadores.txt");
            player = sn.nextLine();
            jugador = this.extraerJugador(lista, player);
        }while(jugador == null);

        
        String nombre = null;
        if ((jugador.getNickJu()).equals(player)) {
            
            int opc = 0;
            do{
                System.out.println("Que deseas modificar?");
                System.out.println("1.Nombre        2.Esbirros      3.Oro      4.Salud       5.Poder        6.Salir");//AÑADIR ARMAS
                System.out.print(" Eleccion: ");
                String opcc = sn.nextLine();;
                opc = pruebaMe(opcc,1,6);
            }while(opc == -1);
            
            switch (opc) {
                case 1:
                    System.out.print("Escoge el nuevo nombre: ");
                    nombre = sn.nextLine();
                    jugador.setNickJu(nombre);

                    //guardar en fichero usuarios.txt
                    FileReader lector = new FileReader(rutasFicheros[2]);
                    BufferedReader buffer = new BufferedReader(lector);

                    String strLine = buffer.readLine();
                    String[] info;

                    while (strLine != null) {
                        info = strLine.split(",");
                        if (info[1].equals(player)) {
                            String meterInfo = info[0] + "," + nombre + "," + info[2] + "," + info[3];
                            lector.close();
                            buffer.close();
                            this.guardarUsuarios(strLine,meterInfo);
                            break;
                        }
                        strLine = buffer.readLine();
                    }
                break;

                case 2:
                    Esbirro esbirrro = null;
                    String nombre1 = null;
                    do{
                        System.out.println("Escribe el nombre del esbirro que deseas modificar: ");
                        esbirrro = jugador.getPersonaje().getEsbirro();
                        while (esbirrro != null) {
                            System.out.println(esbirrro.getNombre_esbirro());
                            esbirrro = esbirrro.getEsbirroDe();
                        }
                        nombre1 = sn.nextLine();
                        
                    }while(nombre1 == null);
                    esbirro = jugador.getPersonaje().getEsbirro();
                    while (esbirro != null) {
                        if (esbirro.getNombre_esbirro().equals(nombre1)) {
                            
                            int opcion = 0;
                            do{
                                System.out.println("Que deseas modificar:");
                                System.out.println("1.Nombre        2.Salud");
                                System.out.print("  Eleccion: ");
                                String opcionn = sn.nextLine();
                                opcion = pruebaMe(opcionn,1,2);
                            }while(opcion == -1);    
                                
                            switch (opcion) {
                                case 1:
                                    System.out.print("Escoge el nuevo nombre: ");
                                    String nuevo = sn.nextLine();
                                    esbirro.setNombre_esbirro(nuevo);
                                    recarga.guardarJugador(jugador);
                                    break;
                                case 2:
                                    int salud = 0;
                                    do{
                                        System.out.print("Escoge la nueva salud: ");
                                        String salud_es = sn.nextLine();
                                        salud = pruebaMe(salud_es, 0, 5);
                                    }while(salud == -1);
                                    break;
                            }
                        } else {
                            esbirro = esbirro.getEsbirroDe();
                        }
                        break;
                    }


                case 3:                                   
                    int oro = 0;
                    do{
                        System.out.println("El oro del jugador es: " + jugador.getPersonaje().getOroPer());
                        System.out.print("Escoge la nueva cantidad de oro: ");
                        String oro_pe = sn.nextLine();
                        oro = pruebaMe(oro_pe, 0, 1_000_000);
                    }while(oro == -1);
                    jugador.getPersonaje().setOroPer(oro);
                    recarga.guardarJugador(jugador);
                    break;

                case 4:
                    int salud = 0;
                    do{
                        System.out.println("La salud del personaje es:" + jugador.getPersonaje().getSaludPer());
                        System.out.print("Escoge la nueva cantidad de poder: ");
                        String salud_pe = sn.nextLine();
                        salud = pruebaMe(salud_pe, 0, 5);
                    }while(salud == -1);
                    jugador.getPersonaje().setPoderPer(salud);
                    recarga.guardarJugador(jugador);
                    break;

                case 5:
                    int poder = 0;
                    do{
                        System.out.println("El poder del personaje es:" + jugador.getPersonaje().getPoderPer());
                        System.out.println("Escoge la nueva cantidad de poder:");
                        String poder_pe = sn.nextLine();
                        poder = pruebaMe(poder_pe, 1, 5);
                    }while(poder == -1);
                    jugador.getPersonaje().setPoderPer(poder);
                    recarga.guardarJugador(jugador);
                    break;

                case 6:
                    break;
            }
        }
    }
        
    //AÑADIR
    public void añadir(String[] rutasFicheros) throws FileNotFoundException, IOException, ClassNotFoundException{
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
        
        do{
            System.out.print("A que jugador se añadiran los cambios?(Escribe su nombre) ");
            this.muestraJugadores("C:\\FicherosMP\\Jugadores.txt");
            String player = sn.nextLine();
            jugador = this.extraerJugador(lista, player);
        }while(jugador == null);
        
        leerFichero.close();
        
        int opc = 0;
        while (opc != 6) {
            do{
                System.out.println("Que deseas añadir:");
                System.out.println("1.Armas     2.Armaduras     3.Fortalezas        4.Debilidades       5.Esbirros      6.Salir");
                System.out.print("  Elección: ");
                String opcc = sn.nextLine();
                opc = pruebaMe(opcc, 1, 6);
            }while(opc == -1);
            
            switch (opc) {
                case 1:
                    System.out.print("Nombre del arma: ");
                    String nombre_arma = sn.nextLine();
                    
                    int ataque = 0;
                    do{
                        System.out.print("Ataque de arma: ");
                        String opcc = sn.nextLine();
                        ataque = pruebaMe(opcc, 1, 3);
                    }while(opc == -1);
                    
                    int defensa = 0;
                    do{
                        System.out.print("Defensa de arma: ");
                        String defensaa = sn.nextLine();
                        defensa = pruebaMe(defensaa, 1, 3);
                    }while(defensa == -1);
                    
                    int opcion5 = 0;
                    do{
                        System.out.println("Es de dos manos?");
                        System.out.println("1.Si        2.No");
                        String opcion55 = sn.nextLine();
                        opcion5 = pruebaMe(opcion55, 1, 2);
                    }while(opcion5 == -1);
                    boolean dosManos = false;
                    if (opcion5 == 1) {
                        dosManos = true;
                    }
                    
                    jugador.getPersonaje().getArma().add(new Arma(nombre_arma, ataque, defensa, dosManos));
                break;

                case 2:
                    System.out.print("Nombre del armadura: ");
                    String nombre_armadura = sn.nextLine();

                    int ataqueDura = 0;
                    do{
                        System.out.print("Ataque del armadura: ");
                        String ataqueDuraa = sn.nextLine();
                        ataqueDura = pruebaMe(ataqueDuraa, 1, 3);
                    }while(ataqueDura == -1);
                    
                    int defensaDura = 0;
                    do{
                        System.out.print("Defensa de armadura: ");
                        String defensaDuraa = sn.nextLine();
                        defensaDura = pruebaMe(defensaDuraa, 1, 3);
                    }while(ataqueDura == -1);

                    jugador.getPersonaje().getArmadura().add(new Armadura(nombre_armadura, ataqueDura, defensaDura));
                break;

                case 3:
                    System.out.print("Escribe el nombre de la fortaleza: ");
                    String nombre_fortaleza = sn.nextLine();
                    
                    int eficacia = 0;
                    do{
                        System.out.print("Cual es su eficiencia: ");
                        String eficaciaa = sn.nextLine();
                        eficacia = pruebaMe(eficaciaa, 1, 5);
                    }while(eficacia == -1);

                    jugador.getPersonaje().getFortaleza().add(new Fortalezas(nombre_fortaleza, eficacia, false));
                    recarga.guardarJugador(jugador);
                break;

                case 4:
                    System.out.print("Escribe el nombre de la debilidad: ");
                    String nombre_debilidad = sn.nextLine();
                    
                    int sensibilidad = 0;
                    do{
                        System.out.print("Cual es su sensibilidad: ");
                        String sensibilidada = sn.nextLine();
                        sensibilidad = pruebaMe(sensibilidada, 1, 5);
                    }while(sensibilidad == -1);
 
                    jugador.getPersonaje().getDebilidad().add(new Debilidades(nombre_debilidad, sensibilidad, false));
                    recarga.guardarJugador(jugador);
                break;

                case 5:
                    Esbirro esbirroJugador = jugador.getPersonaje().getEsbirro();
                    while (esbirroJugador.getEsbirroDe() != null) {
                        esbirroJugador = esbirroJugador.getEsbirroDe();
                    }
                    Esbirro nuevoesbirro = this.elegirEsbirro();
                    if (esbirroJugador.getClass().equals(Demonio.class)) {
                        esbirroJugador.setEsbirroDe(nuevoesbirro);
                    }
                    recarga.guardarJugador(jugador);
                    break;
            }
            recarga.guardarJugador(jugador);
        }
    }
    
    //BANEAR
    void banear(String[] rutasFicheros) throws FileNotFoundException, IOException, ClassNotFoundException{
        boolean encontrado = false;
        do {
            this.muestraJugadores("C:\\FicherosMP\\Jugadores.txt");
            System.out.print("Introduce el nombre del jugador que desea banear o desbanear: ");
            String nombre_baneado = sn.nextLine();
            
            FileReader lector = new FileReader(rutasFicheros[2]);
            BufferedReader buffer = new BufferedReader(lector);

            String strLine = buffer.readLine();
            String[] info;

            //recorremos el fichero
            while (strLine != null) {
                info = strLine.split(",");
                
                //si hemos llegado al jugador
                if (info[1].equals(nombre_baneado)) {
                    encontrado = true;
                    
                    //si es un operador
                    if (info[0].equals("Operador")) 
                        System.out.println("No puedes banear un operador.");
                    
                    //si no es un operador
                    else{
                        //si no está baneado
                        if(info[3].equals("true")){
                            //Guardar usuario en fichero Usuario
                            String meterInfo = info[0] + "," + info[1] + "," + info[2] + "," + "false";
                            lector.close();
                            buffer.close();
                            this.guardarUsuarios(strLine,meterInfo);
                            
                            //guardar usuario en ficheor usuario
                            ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
                            ArrayList<Jugador> lista = (ArrayList) leerFichero.readObject();
                            jugador = this.extraerJugador(lista, nombre_baneado);
                            jugador.setBaneado(false);
                            System.out.println("El jugador ha sido desbaneado");
                        
                        //si está baneado
                        }else {
                            //Guardar usuario en fichero Usuario
                            String meterInfo = info[0] + "," + info[1] + "," + info[2] + "," + "true";
                            lector.close();
                            buffer.close();
                            this.guardarUsuarios(strLine,meterInfo);
                            
                            //guardar usuario en ficheor usuario
                            ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream(rutasFicheros[0]));
                            ArrayList<Jugador> lista = (ArrayList) leerFichero.readObject();
                            jugador = this.extraerJugador(lista, nombre_baneado);
                            jugador.setBaneado(true);
                            System.out.println("El jugador ha sido baneado");

                        }
                        recarga.guardarJugador(jugador);
                    }
                    break;
                }
                strLine = buffer.readLine();
            }
            
            //si no se ha encontrado el jugador en el while
            if (encontrado == false) 
                System.out.println("El jugador no ha sido encontrado, vuelve a intentarlo.");
            System.out.println("");
            
        }while (encontrado == false);
    }
    
    private Jugador extraerJugador(ArrayList <Jugador> lista, String usuario) throws FileNotFoundException, IOException, ClassNotFoundException{ 
        for(Jugador i: lista){
            if(i.getNickJu().equals(usuario)){
                return i;
            }
        }
        return null;
    }
    
    public void guardarUsuarios(String lineToRemove, String meterInfo) throws IOException{                   
        //fichero usuarios
        File usuariosFile = new File(rutasFicheros[2]);
        FileReader leerdor = new FileReader(usuariosFile);
        //fichero nuevo
        File newFile = new File("C:\\FicherosMP\\TempFile.txt");
        FileWriter escritor = new FileWriter(newFile);

        //leer fichero antiguo
        BufferedReader reader = new BufferedReader(leerdor);
        //escribir en fichero nuevo
        BufferedWriter writer = new BufferedWriter(escritor);

        //inicializamos línea por la que vamos
        String currentLine = "";

        //reescribimos todo el ficheor en un nuevo fichero con la  nueva lista
        while ((currentLine = reader.readLine()) != null) {
            if (currentLine.equals(lineToRemove)) {
                writer.write(meterInfo);
                writer.newLine();
            }
            else{ 
                writer.write(currentLine);
                writer.newLine();
            }
        }
        
        writer.close();
        reader.close();
        escritor.close();
        leerdor.close();
                
        try{
            usuariosFile.delete();
            newFile.renameTo(usuariosFile);
            System.out.println("Se han hecho los cambios correctamente!");
        }catch(Exception  e){
            System.out.println("Ha ocurrido un error");
        }


       
    }

    public Esbirro elegirEsbirro() throws IOException{
        Scanner sn1 = new Scanner(System.in);
        
        int tipo = 0;
        do{
            System.out.println("Tipo esbirro: ");
            System.out.println("1. Ghoul");
            System.out.println("2.Demonio");
            System.out.println("3.Humano");
            String typo = sn1.nextLine();
            tipo = pruebaMe(typo,1,3);
        }while(tipo == -1);
     
        esbirro = this.dameTipo(tipo);
        return esbirro;
    }
    
    public Esbirro dameTipo(int tipo) throws IOException{
        Scanner sn = new Scanner(System.in);
        System.out.print("Nombre esbirro: ");
        String nombre = sn.nextLine();
        
        int sal = 0;
        do{
            System.out.print("Salud esbirro: ");
            String sall = sn.nextLine();
            sal = pruebaMe(sall, 1, 5);
        }while(sal == -1);
  
        switch (tipo) {
            case 1:
                int dep;
                do{
                    System.out.print("Dependencia Ghoul: ");
                    String de = sn.nextLine();
                    dep = pruebaMe(de,1,3);
                }while(dep == -1);
                return new Ghoul(nombre,sal,dep);      
            case 2:
                int pac;
                do{
                    System.out.println("Hacer pacto con demonio: ");
                    System.out.println("1. Si     2. Nop: ");
                    String pa = sn.nextLine();
                    pac = pruebaMe(pa,1,2);
                }while(pac == -1);

                boolean pacto;
                String descripPacto;
                if(pac == 2){
                    System.out.println("No has aceptado el pacto... Escoge otro esbirro");
                    esbirro = this.elegirEsbirro(); 
                }
                else{
                    pacto = true;
                    System.out.print("Escribe el pacto: ");
                    descripPacto = sn.nextLine();
                    return new Demonio(nombre,sal,pacto,descripPacto);
                }
            break;
            case 3:
                System.out.print("Lealtad con humano: ");
                String lealtad = sn.nextLine();
                return new Humano(nombre,sal,lealtad);
                
            default: return null;
        }
        return null;
    }
    
    //devuelve un -1 si no es un número y no está en el rango, devuelve el número si cumple las dos cosas
    protected int pruebaMe(String num,int i, int f){
        boolean bol = false;
        int numero = dameInt(num);
        if(numero != -1){
            if(esRango(numero,i,f) == true)
                return numero;
            else
                System.out.println("  El rago de valores se comprende entre "+i+" y "+f+".");
        }
        return -1;
    }
    
    //devuelve un int de un string
    private int dameInt(String a){
        try{
            int b = Integer.parseInt(a);
            return b;
        }catch(Exception  e){
            System.out.println("  Introduzca un numero por favor.");
        }
        return -1;
    }
    
    //comprueba si está en el rango señalado
    private boolean esRango(int valor,int i, int f){
        boolean bo = false;
        if (valor>= i && valor<=f)
            bo = true;
        
        return bo;
    }
    public void muestraJugadores(String archivo) throws FileNotFoundException, IOException, ClassNotFoundException { 
	ObjectInputStream b = new ObjectInputStream(new FileInputStream(archivo));
        ArrayList <Jugador> cadena = (ArrayList) b.readObject();
	
        int count = 0;
        for(Jugador i: cadena){
                System.out.println((count+1)+". "+i.getNickJu());
                count++;
            }
        
        
	b.close();
    }
}