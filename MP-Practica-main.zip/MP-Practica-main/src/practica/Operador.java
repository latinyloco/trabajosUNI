package practica;

import java.io.Serializable;

public class Operador implements Serializable{
    private String nombreOp;
    private String nickOp;
    private String passwordOp;

    public Operador(String nombreOp, String nickOp, String passwordOp) {
        this.nombreOp = nombreOp;
        this.nickOp = nickOp;
        this.passwordOp = passwordOp;
    }

    public String getNombreOp() {
        return nombreOp;
    }

    public String getNickOp() {
        return nickOp;
    }

    public String getPasswordOp() {
        return passwordOp;
    }
}




