package practica;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class Ranking {
    
    
    public void CargarRanking() throws FileNotFoundException, IOException, ClassNotFoundException{
        
        //Buscar carpeta y coger rutas y nombres de ficheros
        ObjectInputStream leerFichero = new ObjectInputStream(new FileInputStream("C:\\FicherosMP\\Jugadores.txt"));
        ArrayList <Jugador> lista = (ArrayList) leerFichero.readObject();
        
        
        //Rellenar con los datos de los jugadores
        int count = 0;
        int oro = 0;
        int[] listaOro = new int[lista.size()];
        String[] listaNomJu = new String[lista.size()];
        for(Jugador i: lista){
            listaOro[count] = i.getPersonaje().getOroPer();
            listaNomJu[count] = i.getNickJu();
            count += 1;
        }
        
        this.bubbleSort(listaOro,listaNomJu);
        
        
        //Meterlo en un fichero
        ArrayList <String> rankingg = new ArrayList();
        for(int i=0; i<listaOro.length; i++){
            rankingg.add("Jugador "+listaNomJu[i]+": "+listaOro[i]+" monedas de oro.");
        }
        
        this.mostrarOro(rankingg);  
    }
    
    private void mostrarOro(ArrayList rankingg) throws FileNotFoundException, IOException{
        Iterator iterator = rankingg.iterator();
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }

    private void bubbleSort(int[] a, String[] b) {
        boolean sorted = false;
        int temp;
        String aux;
        while(!sorted) {
            sorted = true;
            for (int i = 0; i < a.length - 1; i++) {
                if (a[i] < a[i+1]) {
                    aux = b[i];
                    temp = a[i];
                    b[i] = b[i+1];
                    a[i] = a[i+1];
                    b[i+1] = aux;
                    a[i+1] = temp;
                    sorted = false;
                }
            }
        }
    }
}

