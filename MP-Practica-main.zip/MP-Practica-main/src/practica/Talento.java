package practica;

import java.io.Serializable;

public class Talento extends Habilidades implements Serializable{
    
    public Talento (String nombre_habilidad, int ataque_habilidad, int defensa_habilidad) {
        super(nombre_habilidad, ataque_habilidad, defensa_habilidad);
    }

}
