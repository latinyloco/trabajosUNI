package practica;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Vampiro extends Personaje implements Serializable{
    // Habilidad: Disciplinas    
    private String nombre = "Disciplina";
    private int ataque;
    private int defensa;        // Valores entre 1 y 3
    
    private int edad;
    
    int sangre = 1;             // Recurso para activar habilidades. Máximo 10

    public Vampiro(String nombre_per, int oro_per, int salud_per, int poder_per, int ataque, int defensa, ArrayList <Fortalezas> fortalezas, ArrayList <Debilidades> debilidad, ArrayList <Armadura> armadura, ArrayList <Arma> arma, int tipo) throws IOException {
        super(nombre_per,oro_per,salud_per,poder_per,fortalezas,debilidad,armadura,arma,tipo);
        this.ataque = ataque;
        this.defensa = defensa;
        this.edad = (int) (Math.random() * 90);
    }    
    
    // GETTERS
    public int getEdad() {
        return edad;
    }

    public int getSangre() {
        return sangre;
    }

    // SETTERS
    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSangre(int sangre) {
        this.sangre = sangre;
    }

}
