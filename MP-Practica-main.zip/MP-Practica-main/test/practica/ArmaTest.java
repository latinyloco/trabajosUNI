package practica;

import org.junit.Test;
import static org.junit.Assert.*;

public class ArmaTest {
    
    public ArmaTest() { //nombre,ataque,defensa,manos
    }
   
    @Test
    public void testGetNombre_arma() {
        System.out.println("getNombre_arma");
        Arma instance = new Arma("pistola", 3, 2, false);
        String expResult = "pistola";
        String result = instance.getNombre_arma();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testGetAtaque() {
        System.out.println("getAtaque");
        Arma instance = new Arma("pistola", 3, 2, false);
        int expResult = 3;
        int result = instance.getAtaque();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testGetDefensa() {
        System.out.println("getDefensa");
        Arma instance = new Arma("pistola", 3, 2, false);
        int expResult = 2;
        int result = instance.getDefensa();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testGetdosManos() {
        System.out.println("getdosManos");
        Arma instance = new Arma("pistola", 3, 2, false);
        boolean expResult = false;
        boolean result = instance.getdosManos();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testSetNombre_arma() {
        System.out.println("setNombre_arma");
        String result = "hola";
        
        Arma instance = new Arma("pistola", 3, 2, false);
        instance.setNombre_arma(result);
        String expResult = instance.getNombre_arma();
        
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testSetAtaque() {
        System.out.println("setAtaque");
        int result = 1;
        
        Arma instance = new Arma("pistola", 3, 2, false);
        instance.setAtaque(result);
        int expResult = instance.getAtaque();
        
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testSetDefensa() {
        System.out.println("setDefensa");
        int result = 1;
        
        Arma instance = new Arma("pistola", 3, 2, false);
        instance.setDefensa(result);
        int expResult = instance.getDefensa();
        
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testSetdosManos() {
        System.out.println("setDefensa");
        boolean result = false;
        
        Arma instance = new Arma("pistola", 3, 2, false);
        instance.setdosManos(result);
        boolean expResult = instance.getdosManos();
        
        if(expResult != result)
            fail("Fallo del programa.");
    }
    
}
