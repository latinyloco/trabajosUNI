/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zeroc
 */
public class ArmaduraTest {
    
    public ArmaduraTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre_armadura method, of class Armadura.
     */
    @Test
    public void testGetNombre_armadura() {
        System.out.println("getNombre_armadura");
        Armadura instance = new Armadura("nombreArmadura",1,3);
        String expResult = "nombreArmadura";
        String result = instance.getNombre_armadura();
        assertEquals(expResult, result);
        if(!result.equals(expResult))
            fail("The test case is a prototype.");
    }

    /**
     * Test of getAtaque method, of class Armadura.
     */
    @Test
    public void testGetAtaque() {
        System.out.println("getAtaque");
        Armadura instance = new Armadura("nombreArmadura",1,3);
        int expResult = 1;
        int result = instance.getAtaque();
        assertEquals(expResult, result);
        if(result != expResult)
            fail("The test case is a prototype.");
    }

    /**
     * Test of getDefensa method, of class Armadura.
     */
    @Test
    public void testGetDefensa() {
        System.out.println("getDefensa");
        Armadura instance = new Armadura("nombreArmadura",1,3);
        int expResult = 3;
        int result = instance.getDefensa();
        assertEquals(expResult, result);
        if(result != expResult)
            fail("The test case is a prototype.");
    }

    /**
     * Test of setNombre_armadura method, of class Armadura.
     */
    @Test
    public void testSetNombre_armadura() {
        System.out.println("setNombre_armadura");
        String nombre_armadura = "nombreNuevo";
        Armadura instance = new Armadura("nombreArmadura",1,3);
        instance.setNombre_armadura(nombre_armadura);
        String result = instance.getNombre_armadura();
        if(!result.equals(nombre_armadura))
            fail("The test case is a prototype.");
    }

    /**
     * Test of setAtaque method, of class Armadura.
     */
    @Test
    public void testSetAtaque() {
        System.out.println("setAtaque");
        int ataque = 2;
        Armadura instance = new Armadura("nombreArmadura",1,3);
        instance.setAtaque(ataque);
        int result = instance.getAtaque();
        if(result != ataque)
            fail("The test case is a prototype.");
    }

    /**
     * Test of setDefensa method, of class Armadura.
     */
    @Test
    public void testSetDefensa() {
        System.out.println("setDefensa");
        int defensa = 0;
        Armadura instance = new Armadura("nombreArmadura",1,3);
        instance.setDefensa(defensa);
        int result = instance.getDefensa();
        if(result != defensa)
            fail("The test case is a prototype.");
    }
    
}
