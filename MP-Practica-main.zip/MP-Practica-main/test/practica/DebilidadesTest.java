/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class DebilidadesTest {
    
    public DebilidadesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre_debilidad method, of class Debilidades.
     */
    @Test
    public void testGetNombre_debilidad() {
        System.out.println("getNombre_debilidad");
        Debilidades instance = new Debilidades("NomDeb",1,true);
        String expResult = instance.getNombre_debilidad();
        assertEquals(expResult, "NomDeb");
        if (expResult != "NomDeb")
            fail("No se ha obtenido correctamente el nombre de la debilidad");
    }

    /**
     * Test of getSensibilidad method, of class Debilidades.
     */
    @Test
    public void testGetSensibilidad() {
        System.out.println("getSensibilidad");
        Debilidades instance = new Debilidades("NomDeb",1,true);
        int Result = instance.getSensibilidad();
        int expResult = 1;
        assertEquals(expResult, Result);
        if (expResult != Result)
            fail("No se ha obtenido correctamente la sensibilidad de la debilidad");
    }

    /**
     * Test of setNombre_debilidad method, of class Debilidades.
     */
    @Test
    public void testSetNombre_debilidad() {
        System.out.println("setNombre_debilidad");
        String result = "NuevoNombre";
        Debilidades instance = new Debilidades("NomDeb",1,true);
        instance.setNombre_debilidad(result);
        String expResult = instance.getNombre_debilidad();
        assertEquals(expResult,result);
        if (expResult != result)
            fail("No se ha puesto correctamente el nuevo nombre de la debilidad");
        
    }

    /**
     * Test of setSensibilidad method, of class Debilidades.
     */
    @Test
    public void testSetSensibilidad() {
        System.out.println("setSensibilidad_debilidad");
        int result = 2;
        Debilidades instance = new Debilidades("NomDeb",1,true);
        instance.setSensibilidad(result);
        int expResult = instance.getSensibilidad();
        assertEquals(expResult,result);
        if (expResult != result)
            fail("No se ha puesto correctamente el nuevo valor de sensibilidad de la debilidad");
    }

    /**
     * Test of isActivo method, of class Debilidades.
     */
    @Test
    public void testIsActivo() {
        System.out.println("test_IsActivo");
        Debilidades instance = new Debilidades("NomDeb",1,true);
        boolean expResult = instance.isActivo();
        assertEquals(expResult, true);
        if (!expResult)
            fail("No se ha obtenido correctamente si esta activa la debilidad");
    }

    /**
     * Test of setActivo method, of class Debilidades.
     */
    @Test
    public void testSetActivo() {
        System.out.println("setIsActivo_debilidad");
        boolean result = false;
        Debilidades instance = new Debilidades("NomDeb",1,true);
        instance.setActivo(result);
        boolean expResult = instance.isActivo();
        assertEquals(expResult,result);
        if (expResult != result)
            fail("No se ha puesto correctamente el nuevo valor de si esta activo de la debilidad");
    }
    
}
