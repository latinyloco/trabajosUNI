/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class DisciplinaTest {
    
    public DisciplinaTest() {
    }
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getCoste_sangre method, of class Disciplina.
     */
    @Test
    public void testGetCoste_sangre() {
        System.out.println("getCoste_sangre");
        Disciplina instance = new Disciplina("NomDisciplina",1,1,1);
        int expResult = 1;
        int result = instance.getCoste_sangre();
        assertEquals(expResult, result);
        if (expResult != result)
            fail("No se ha conseguido correctamente el coste de la sangre");
    }
    
}
