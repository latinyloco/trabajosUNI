package practica;


import org.junit.Test;
import static org.junit.Assert.*;

public class DonesTest {
    
    public DonesTest() {
    }


    @Test
    public void testGetMin_rabia() {
        System.out.println("getMin_rabia");
        Dones instance = new Dones("churrasco", 3, 3, 4);
        int expResult = 4;
        int result = instance.getMin_rabia();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }
    
}
