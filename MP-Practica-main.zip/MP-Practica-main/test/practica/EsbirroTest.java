/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zeroc
 */
public class EsbirroTest {
    
    public EsbirroTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre_esbirro method, of class Esbirro.
     */
    @Test
    public void testGetNombre_esbirro() {
        System.out.println("getNombre_esbirro");
        Esbirro instance = new Esbirro("NombreEsbirro",3) {
            @Override
            public Esbirro getEsbirroDe() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public void setEsbirroDe(Esbirro esbirro) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
        String expResult = "NombreEsbirro";
        String result = instance.getNombre_esbirro();
        assertEquals(expResult, result);
        if(!result.equals(expResult))
            fail("The test case is a prototype.");
    }

    /**
     * Test of getSalud method, of class Esbirro.
     */
    @Test
    public void testGetSalud() {
        System.out.println("getSalud");
        Esbirro instance = new Esbirro("NombreEsbirro",3) {
            @Override
            public Esbirro getEsbirroDe() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public void setEsbirroDe(Esbirro esbirro) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
        int expResult = 3;
        int result = instance.getSalud();
        assertEquals(expResult, result);
        if(result != result)
            fail("The test case is a prototype.");
    }

    /**
     * Test of setNombre_esbirro method, of class Esbirro.
     */
    @Test
    public void testSetNombre_esbirro() {
        System.out.println("setNombre_esbirro");
        String nombre_esbirro = "nuevoNombre";
        Esbirro instance = new Esbirro("NombreEsbirro",1) {
            @Override
            public Esbirro getEsbirroDe() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public void setEsbirroDe(Esbirro esbirro) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
        instance.setNombre_esbirro(nombre_esbirro);
        String result = instance.getNombre_esbirro();
        if(!result.equals(nombre_esbirro))
            fail("The test case is a prototype.");
    }

    /**
     * Test of setSalud method, of class Esbirro.
     */
    @Test
    public void testSetSalud() {
        System.out.println("setSalud");
        int salud = 1;
        Esbirro instance = new Esbirro("nombreEsbirro",3) {
            @Override
            public Esbirro getEsbirroDe() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            @Override
            public void setEsbirroDe(Esbirro esbirro) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
        instance.setSalud(salud);
        int result = instance.getSalud();
        if(result != salud)
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEsbirroDe method, of class Esbirro.
     *//*
    @Test
    public void testGetEsbirroDe() {
        System.out.println("getEsbirroDe");
        Esbirro instance = null;
        Esbirro expResult = null;
        Esbirro result = instance.getEsbirroDe();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEsbirroDe method, of class Esbirro.
     *//*
    @Test
    public void testSetEsbirroDe() {
        System.out.println("setEsbirroDe");
        Esbirro esbirro = null;
        Esbirro instance = null;
        instance.setEsbirroDe(esbirro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    public class EsbirroImpl extends Esbirro {

        public EsbirroImpl() {
            super("", 0);
        }

        @Override
        public Esbirro getEsbirroDe() {
            return null;
        }

        @Override
        public void setEsbirroDe(Esbirro esbirro) {
        }
    }
    
}
