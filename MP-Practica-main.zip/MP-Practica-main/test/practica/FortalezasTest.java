package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class FortalezasTest {
    
    public FortalezasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre_fortaleza method, of class Fortalezas.
     */
    @Test
    public void testGetNombre_fortaleza() {
        System.out.println("getNombre_fortaleza");
        Fortalezas instance = new Fortalezas("nomFor",1,true);
        String expResult = "nomFor";
        String result = instance.getNombre_fortaleza();
        assertEquals(expResult, result);
        if (expResult != result)
            fail("No se pudo conseguir el nombre de la fortaleza");
    }

    /**
     * Test of getEficiencia method, of class Fortalezas.
     */
    @Test
    public void testGetEficiencia() {
        System.out.println("getEficiencia_fortaleza");
        Fortalezas instance = new Fortalezas("nomFor",1,true);
        int expResult = 1;
        int result = instance.getEficiencia();
        assertEquals(expResult, result);
        if (expResult != result)
            fail("No se pudo conseguir el nombre de la fortaleza");
    }

    /**
     * Test of setNombre_fortaleza method, of class Fortalezas.
     */
    @Test
    public void testSetNombre_fortaleza() {
        System.out.println("setNombre_fortaleza");
        String result = "NuevoNombre";
        Fortalezas instance = new Fortalezas("NomFor",1,true);
        instance.setNombre_fortaleza(result);
        String expResult = instance.getNombre_fortaleza();
        assertEquals(expResult,result);
        if (expResult != result)
            fail("No se ha puesto correctamente el nuevo nombre de la fortaleza");
    }

    /**
     * Test of setEficiencia method, of class Fortalezas.
     */
    @Test
    public void testSetEficiencia() {
        System.out.println("setEficiencia_Fortalezas");
        int result = 2;
        Fortalezas instance = new Fortalezas("NomDeb",1,true);
        instance.setEficiencia(result);
        int expResult = instance.getEficiencia();
        assertEquals(expResult,result);
        if (expResult != result)
            fail("No se ha puesto correctamente la nueva eficiencia de la debilidad");
    }

    /**
     * Test of isActivo method, of class Fortalezas.
     */
    @Test
    public void testIsActivo() {
        System.out.println("isActivo");
        Fortalezas instance = new Fortalezas("NomDeb",1,true);
        boolean expResult = true;
        boolean result = instance.isActivo();
        assertEquals(expResult, result);
        if (expResult != result)
            fail("No se consigue correctamente si esta activa la fortaleza");
    }

    /**
     * Test of setActivo method, of class Fortalezas.
     */
    @Test
    public void testSetActivo() {
        System.out.println("setActivo");
        boolean expResult = false;
        Fortalezas instance = new Fortalezas("NomDeb",1,true);
        instance.setActivo(expResult);
        boolean result = instance.isActivo();
        if (expResult != result)
            fail("No se pone correctamente si esta activa la fortaleza");
    }
    
}