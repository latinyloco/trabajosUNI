/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zeroc
 */
public class GhoulTest {
    
    public GhoulTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDependencia method, of class Ghoul.
     */
    @Test
    public void testGetDependencia() {
        System.out.println("getDependencia");
        Ghoul instance = new Ghoul("Nombre",3,1);
        int expResult = 1;
        int result = instance.getDependencia();
        assertEquals(expResult, result);
        if (result != expResult)
            fail("The test case is a prototype.");
    }

    /**
     * Test of getEsbirroDe method, of class Ghoul.
     *//*
    @Test
    public void testGetEsbirroDe() {
        System.out.println("getEsbirroDe");
        Ghoul instance = new Ghoul("Nombre",3,1);
        Esbirro expResult = null;
        Esbirro result = instance.getEsbirroDe();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of setEsbirroDe method, of class Ghoul.
     *//*
    @Test
    public void testSetEsbirroDe() {
        System.out.println("setEsbirroDe");
        Esbirro esbirro = null;
        Ghoul instance = null;
        instance.setEsbirroDe(esbirro);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
