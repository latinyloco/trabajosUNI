/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zeroc
 */
public class HabilidadesTest {
    
    public HabilidadesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getNombre_habilidad method, of class Habilidades.
     */
    @Test
    public void testGetNombre_habilidad() {
        System.out.println("getNombre_habilidad");
        Habilidades instance = new Habilidades("nombreHabilidad",1,3);
        String expResult = "nombreHabilidad";
        String result = instance.getNombre_habilidad();
        assertEquals(expResult, result);
        if(!result.equals(expResult))
            fail("The test case is a prototype.");
    }

    /**
     * Test of getAtaque_habilidad method, of class Habilidades.
     */
    @Test
    public void testGetAtaque_habilidad() {
        System.out.println("getAtaque_habilidad");
        Habilidades instance = new Habilidades("nombreHabilidad",1,3);
        int expResult = 1;
        int result = instance.getAtaque_habilidad();
        assertEquals(expResult, result);
        if(result != expResult)
            fail("The test case is a prototype.");
    }

    /**
     * Test of getDefensa_habilidad method, of class Habilidades.
     */
    @Test
    public void testGetDefensa_habilidad() {
        System.out.println("getDefensa_habilidad");
        Habilidades instance = new Habilidades("nombreHabilidad",1,3);
        int expResult = 3;
        int result = instance.getDefensa_habilidad();
        assertEquals(expResult, result);
        if(result != expResult)
            fail("The test case is a prototype.");
    }
    
}
