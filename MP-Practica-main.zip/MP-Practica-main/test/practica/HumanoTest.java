package practica;

import org.junit.Test;
import static org.junit.Assert.*;

public class HumanoTest {
    
    public HumanoTest() {
    }
 
    @Test
    public void testGetLealtad() {
        System.out.println("getLealtad");
        Humano instance = new Humano("smevilock", 3, "altisima");
        String expResult = "altisima";
        String result = instance.getLealtad();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }
}
