package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class OperadorTest {
    
    public OperadorTest() {
    }

    @Test
    public void testGetNombreOp() {
        System.out.println("getNombreOp");
        Operador instance = new Operador("lolero", "nomemires", "contrasenia");
        String expResult = "lolero";
        String result = instance.getNombreOp();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testGetNickOp() {
        System.out.println("getNickOp");
        Operador instance = new Operador("lolero", "nomemires", "contrasenia");
        String expResult = "nomemires";
        String result = instance.getNickOp();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }

    @Test
    public void testGetPasswordOp() {
        System.out.println("getPasswordOp");
        Operador instance = new Operador("lolero", "nomemires", "contrasenia");
        String expResult = "contrasenia";
        String result = instance.getPasswordOp();
        assertEquals(expResult, result);
        if(expResult != result)
            fail("Fallo del programa.");
    }
}
