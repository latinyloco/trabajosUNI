/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package practica;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zeroc
 */
public class RecargarFicherosTest {
    
    public RecargarFicherosTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of RecuperarCrear method, of class RecargarFicheros.
     */
    @Test
    public void testRecuperarCrear() throws Exception {
        System.out.println("RecuperarCrear");
        RecargarFicheros instance = new RecargarFicheros();
        String[] expResult = new String[4];
        expResult[0] = "C:\\FicherosMP\\Jugadores.txt";
        expResult[1] = "C:\\FicherosMP\\Operadores.txt";
        expResult[2] = "C:\\FicherosMP\\Usuarios.txt";
        expResult[3] = "C:\\FicherosMP\\ZDesafio.txt";
        String[] result = instance.RecuperarCrear();
        assertArrayEquals(expResult, result);
        if(!result[0].equals(expResult[0]) && !result[1].equals(expResult[1]) && !result[2].equals(expResult[2]))
            fail("The test case is a prototype.");
    }

    /**
     * Test of guardarJugador method, of class RecargarFicheros.
     *//*
    @Test
    public void testGuardarJugador() throws Exception {
        System.out.println("guardarJugador");
        Jugador jugador = null;
        RecargarFicheros instance = new RecargarFicheros();
        instance.guardarJugador(jugador);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of muestraJugadores method, of class RecargarFicheros.
     */
    @Test
    public void testMuestraJugadores() throws Exception {
        System.out.println("muestraJugadores");
        String archivo = "C:\\FicherosMP\\Jugadores.txt";
        RecargarFicheros instance = new RecargarFicheros();
        instance.muestraJugadores(archivo);
    }

    /**
     * Test of GuardarDesafio method, of class RecargarFicheros.
     *//*
    @Test
    public void testGuardarDesafio() throws Exception {
        System.out.println("GuardarDesafio");
        InfoDesafio data = null;
        RecargarFicheros instance = new RecargarFicheros();
        instance.GuardarDesafio(data);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of eliminarInfoDesafio method, of class RecargarFicheros.
     */
    @Test
    public void testEliminarInfoDesafio() throws Exception {
        System.out.println("eliminarInfoDesafio");
        RecargarFicheros instance = new RecargarFicheros();
        InfoDesafio des = instance.RecuperarDesafio("jugador2");
        instance.eliminarInfoDesafio(des);
        if(des == null)
            fail("Error");
    }

    /**
     * Test of RecuperarDesafio method, of class RecargarFicheros.
     */
    @Test
    public void testRecuperarDesafio() throws Exception {
        System.out.println("RecuperarDesafio");
        String nick = "jugador1";
        RecargarFicheros instance = new RecargarFicheros();
        InfoDesafio result = instance.RecuperarDesafio(nick);
        if(result == null)
            fail("The test case is a prototype.");
    }

    /**
     * Test of saveDes method, of class RecargarFicheros.
     *//*
    @Test
    public void testSaveDes() throws Exception {
        System.out.println("saveDes");
        InfoDesafio info4 = null;
        RecargarFicheros instance = new RecargarFicheros();
        instance.saveDes(info4);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
