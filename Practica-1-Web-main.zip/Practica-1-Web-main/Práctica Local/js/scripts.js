//DESCRIPCIÓN ARRAY
let ArrayNotes = []

class Note {
    constructor(idNote, title, items) {
        this.idNote = idNote;
        this.title = title;
        this.items = items;
    }

    setidNote() {
        this.idNote = idNote; 
    }

    setTitle() {
        this.title = title;
    }

    setItem() {
        this.items = items;
    }

    getidNote() {
        return this.idNote;
    }

    getTitle() {
        return this.title;
    }

    getItem() {
        return this.items;
    }
}

let prueba = []
prueba[0] = "patatas"
prueba[1] = "huevo"
prueba[2] = "tomate"

let prueba2 = []
prueba2[0] = "Mates"
prueba2[1] = "POO"
prueba2[2] = "AIC"

ArrayNotes[0] = new Note(0,"Compra", prueba);
ArrayNotes[1] = new Note(1,"Pendiente", prueba2);

MostrarListadoNotas(ArrayNotes);

//MOSTRAR LISTA DE NOTAS
//Si el array esta vacio mostrará que no hay elementos, si tiene contenido mostrará las notas
function MostrarListadoNotas(arr){
    if (arr.length == 0){
        let cont = document.getElementById("NotesList");
        cont.innerHTML += `<div id="delete1">
        </div>`
        let cont2 = document.getElementById("delete1");
        cont2.innerHTML += `<p>No hay notas añadidas</p>`
    } else {
    let nest = document.getElementById("NotesList");
    nest.innerHTML += `<div id="delete1">
        </div>`
    let items = document.getElementById("delete1")
    for (let i = 0; i < arr.length; i++) {
        ArrayNotes[i].idNote=i;
        items.innerHTML +=
            `<div class="col mb-5">
            <div class="card h-100 clickable" id="card">
                <div class="text-center" id="` + i + `">
                    <h5 class="fw-bolder-25">` + arr[i].title + `</h5>
                </div>
            </div>
        </div>`;
    }
    ShowNote();
    }
}

//AÑADE LA FUNCION DE MOSTRAR LA NOTA Y MUESTRA LA NOTA CLICKADA
function ShowNote(){
let current_notes = document.querySelectorAll("#card");

for (let i = 0; i < current_notes.length; i++) {
        current_notes[i].onclick = function (){
            let abc = this.firstElementChild;
            let clean = document.getElementById("delete1");
            clean.remove();
            for (let j=0; j<ArrayNotes.length;j++){
                if (ArrayNotes[j].idNote == abc.id){
                 mostrar(ArrayNotes[j])   
                }
            }   
            ShowMoreInfo();
        }
}
}

//MUESTRA UNA NOTA CONCRETA 
//DA CUALIDADES A TODOS LOS BOTONES Y LA FUNCION QUE TIENEN
function mostrar(note) {

    let items = document.getElementById('NoteInfo');
    items.innerHTML +=
        `<div id="delete2">
        <div>
            <h1 class="titleNote">`+ note.title + `</h1>
            <aside><button id="back1"> Back </button></aside>
        </div>

        <hr>
        <div id="lItems">
        </div>
        </div>`;

    let item = document.getElementById('lItems');
    for (let i = 0; i < note.items.length; i++) {
        item.innerHTML +=
            `<p class="pStyle">` + note.items[i] + `</p>`;
    }

    document.getElementById("back1").onclick = function () {
        document.getElementById("MoreInfo").style.display = "none";
        document.getElementById("main").style.display = "block";
        let clean = document.getElementById("delete2");
        clean.remove();
        MostrarListadoNotas(ArrayNotes);
    }

    document.getElementById("editNote").onclick = function(){
        editarYnuevaNota(note);
        ShowMoreInfoEditable();
    }

    document.getElementById("deleteNote").onclick = function(){
            let text = "Estas seguro de querer eliminar este elemento?";
            if (confirm(text) == true) {
                document.getElementById("MoreInfo").style.display = "none";
                document.getElementById("main").style.display = "block";
                let clearedArray = ArrayNotes.filter(it => it !== note);
                ArrayNotes = clearedArray
                let clean = document.getElementById("delete2");
                clean.remove();
                MostrarListadoNotas(ArrayNotes);
            } else {
            }
    }
} 



//MUESTRA NOTA YA EDITABLE YA SEA NOTA NUEVA O EXISTENTE
function editarYnuevaNota(note) {
    if (note == null){
        let sample = new Note;
        sample.idNote = ArrayNotes.length;
        sample.title = "Set Title"
        sample.items = [];
        mostrarEditable(sample);
        document.getElementById("back2").onclick = function () {
            document.getElementById("MoreInfoEditable").style.display = "none";
            document.getElementById("main").style.display = "block";
            let clean = document.getElementById("delete3");
            clean.remove();
            MostrarListadoNotas(ArrayNotes);
        }
    } else {
    mostrarEditable(note);
    document.getElementById("back2").onclick = function () {
        document.getElementById("MoreInfoEditable").style.display = "none";
        document.getElementById("MoreInfo").style.display = "block";
        let clean = document.getElementById("delete3");
        clean.remove();
        mostrar(note);
    }
}
}

//PLANTILLA EDITABLE COMUN A EDITAR NOTA Y NUEVA NOTA
//DA FUNCION A TODOS LOS BOTONES
function mostrarEditable(note){

    let items = document.getElementById('NoteInfoEditable');
    items.innerHTML +=
        `<div id="delete3">
            <div>
                <h1 class="titleNote" id="titulo" contentEditable="true">`+ note.title + `</h1> 
                <aside><button id="back2"> Back </button></aside>
            </div>
        <hr>
        <div id="2Items"> 
        </div>
        <input id='item' type='text'>
        <button id='addItem'>Add</button>
        </div>`


    document.getElementById("addItem").onclick = function () {
        AddEditableItem(note);
    }

    let item = document.getElementById('2Items');
    for (let i = 0; i < note.items.length; i++) {
        item.innerHTML +=
            `<div>
                <span class="spanStyle" contentEditable="true">` + note.items[i] + `</span>
                <button id="boton">Delete</button>
            </div>`;
    }

    DeleteItem(note);

    document.getElementById("save").onclick = function () {
        if (note.idNote == ArrayNotes.length){
            ArrayNotes[note.idNote] = note;
        }
        note.title = document.getElementById("titulo").textContent;
        let divInfo = document.getElementById("2Items");
        for (var i = 0; i < divInfo.children.length; i++) {
            let divItem = divInfo.children[i];
            note.items[i] = divItem.children[0].innerHTML;
        }
        document.getElementById("main").style.display = "block";
        document.getElementById("MoreInfoEditable").style.display = "none";
        let clean = document.getElementById("delete3");
        clean.remove();
        MostrarListadoNotas(ArrayNotes);
    }
}

//DA LA FUNCION DE ELIMINAR A LOS BOTONES DE CADA ITEM Y ELIMINA EL ELEMENTO AL SER PULSADO
function DeleteItem(note){
let current_tasks = document.querySelectorAll("#boton");
    
        for (var i = 0; i < current_tasks.length; i++) {
    
            current_tasks[i].onclick = function () {
                    let text = "Estas seguro de querer eliminar este elemento?";
                    if (confirm(text) == true) {
                      //eliminarlo
                      this.parentNode.remove();
                    } else {
                    }
                }
        }
}

//AÑADE ITEMS YA ESTIDABLES A LA NOTA
function AddEditableItem(note) {
    let item = document.getElementById("item").value;

    let items = document.getElementById('2Items');
    items.innerHTML +=
        `<div>
            <span class="spanStyle" contentEditable=true>` + item + `</span>
            <button id="boton">Delete</button>
        </div>`;

    DeleteItem(note);
}

//DA FUNCION AL BOTON DE ADDNOTE
document.getElementById("addNote").onclick = function() {
    document.getElementById("main").style.display = "none";
    document.getElementById("MoreInfoEditable").style.display = "block";
    let clean = document.getElementById("delete1");
    clean.remove();
    editarYnuevaNota();
}

//ESCONDE NOTA NO EDITABLE Y MUESTRA NOTA YA EDITABLE
function ShowMoreInfoEditable() {
    document.getElementById("MoreInfo").style.display = "none";
    document.getElementById("MoreInfoEditable").style.display = "block";
    let clean = document.getElementById("delete2");
    clean.remove();
}

//ESCONDE EL MAIN Y MUESTRA NOTA NO EDITABLE
function ShowMoreInfo() {
    document.getElementById("main").style.display = "none";
    document.getElementById("MoreInfo").style.display = "block";
}

