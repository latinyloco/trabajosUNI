const NUM_RESULTS = 5;

let loadMoreRequests = 0;


async function loadMore(){
    const from = (loadMoreRequests+1) * NUM_RESULTS;
    const to = from + NUM_RESULTS;

    const response = await fetch(`/loadNotes?from=${from}&to=${to}`);

    const newSuperheroes = await response.text();
  
    const superheroesDiv = document.getElementById("NotesList");

    superheroesDiv.innerHTML += newSuperheroes;

    loadMoreRequests++;
}