//  usamos referencias de de módulos express y el que hemos creado para el manejo de información
//////////////////////////////////////////////////////////////////////////////////////////////////
///  Interés: https://codesandbox.io/s/component-tree-lsm4r?file=/src/components/ToDoItem.jsx  
///  https://www.geeksforgeeks.org/how-to-dynamically-add-html-content-when-documents-are-inserted-in-collection-using-node-js/
//////////////////////////////////////////////////////////////////////////////////////////////////
import express from 'express';
import * as boardService from './boardService.js';
import { JSDOM } from 'jsdom';
let items;
let postTitle;
let idtope;
let keys;

const router = express.Router();

//INICIO DE APP.JS Y BOTÓN BACK (newNote,editNote,viewNote) = PAGINA PRINCIPAL 
router.get('/', (req, res) => {
    items = new Map();
    idtope = 0;
    let idPlus = boardService.getNextId;

    //mostramos los cinco primeros solo
    res.render('index', {  
        posts: boardService.getPostFT(0, 5), idPlus
    });
});



//BOTÓN NEW NOTE (index) Y BOTÓN EDIT (viewNote) = MOSTRAR NOTA MODIFICABLE (nueva o ya creada)
router.get('/post/:id/editNote', (req, res) => {
    //new note
    if (req.params.id == (":" + boardService.getNextId())) {
        let id = boardService.getNextId();
        items.set("0",{name: "New Item", idItem: 0});
        items.idtope = "0";
        postTitle = "New Title";
        idtope;
        keys;
        res.render("newNote", { id });
    }

    //edit note
    else {
        let data = null;

        idtope = parseInt(boardService.getItemsId(req.params.id));
        items = boardService.getItemsKV(req.params.id);
        postTitle = boardService.getTitle(req.params.id);
        keys = boardService.getItemsKeys(items);

        let id = req.params.id;

        res.render("editNote", { postTitle, itemss: boardService.getItemss(items), id, keys, data });
    }


});



//BOTÓN ADD (editNote) = MOSTRAR NOTA MODIFICABLE CON ITEMS RECIÉN AÑADIDOS (nueva o ya creada)
router.post('/post/:id/editNote', (req, res) => {
    guardarAux(req.body);
    
    //añadimso item que se ha exportado desde el input que acompaña al botón add
    let numerito = idtope.toString();
    items.set(numerito, { name: req.body.item, idItem: idtope});
    idtope++;
    
    //actualizamos los componentes del post actual
    items.idtope = idtope;
    postTitle = req.body.title;
    keys = boardService.getItemsKeys(items);

    let id = req.params.id;

    res.render('editNote', { postTitle, itemss: boardService.getItemss(items), id, keys });

});



//CLICK EN UNA NOTA (index) = MOSTRAR NOTA
router.get('/post/:id', (req, res) => {
    let post = boardService.getPost(req.params.id);
    let itemss = boardService.getItems(req.params.id);
    res.render('viewNote', { post, itemss });
});



//BOTÓN SAVE (newNote) = GUARDAR NOTA
router.get('/post/:id/editNote/save', (req, res) => {
    //Ya se han guardado anterioemente los conceptos "New" en items

    boardService.addPost({title: postTitle, items: items})

    res.render('saved_post');
});


//BOTÓN SAVE (EditNote) = GUARDAR NOTA
router.post('/post/:id/editNote/save', (req, res) => {
    //guardar los cambios de items ya creados y title
    guardarAux(req.body);

    //new note (le damos un id nuevo)
    if(req.params.id==boardService.getNextId()){
        boardService.addPost({title: req.body.title, items: items});
    }

    //edit note (lo guardo en la nota a la que pertenece)
    else{
        let post = boardService.getPost(req.params.id);

        post.title = req.body.title;
        post.items = items;
        post.id = req.params.id;
    }

    res.render('saved_post');
    

});





//BOTÓN DELETE (editNote) = ELIMINAR ITEM DE NOTA       [en hola, la palabra que haya antes de delete es la que se debe eliminar]
router.post('/post/:id/editNote/deleteItem', (req, res) => {
    guardarAux(req.body);
    
    let hola = req.body["object Map Iterator"];     //lista de elementos que hay en antalla
    
    let fulminar = hola[hola.findIndex(ite => ite === "Delete")-1];     //obtener la palabra que hay que eliminar
    let idFulminar;

    for(let element of items.values()){
        if(element.name == fulminar){
            idFulminar = element.idItem.toString();
        }
    }

    items.delete(idFulminar);

    let id = req.params.id;
    keys = items.keys();

    res.render('editNote', { postTitle, itemss: boardService.getItemss(items), id, keys});
});




/*async function preguntar() {
    const { window } = new JSDOM();
  
    const respuesta = window.confirm('¿Desea continuar?');
  
    if (respuesta) {
      console.log('El usuario eligió continuar');
    } else {
      console.log('El usuario eligió cancelar');
    }
}

import {confirm} from 'node-popup';
const main = async ()=>{
    try{
        await confirm('Confirm or Deny?');
        console.log('Confirmed!');// OK button clicked
    }catch(error){
        console.log('Denied!');// cancel button clicked
    }
}*/

//BOTÓN DELETE (viewNote) = ELIMINAR NOTA
router.get('/post/:id/delete', (req, res) => {
    boardService.deletePost(req.params.id);

    
    //main();

    res.render('deleted_post');
});


//FUNCIÓN GUARDAR LOS ITEMS QUE HAN MODIFICADOS DESPUÉS DE HABERSE CREADO
function guardarAux(data){
    let numerito;
    let hola = data["object Map Iterator"];

    if (Array.isArray(hola)) {
        idtope = 0;
        items = new Map();
        data["object Map Iterator"].forEach(element => {
            if(element!="Delete"){
                numerito = idtope.toString();
                items.set(numerito, { name: element, idItem: idtope});
                idtope++;
            }
        });
    }

    return idtope;
}

/* AJAX */
router.get('/loadNotes', (req, res) => {
    const from = parseInt(req.query.from);
    const to = parseInt(req.query.to);

    const loadNotes = boardService.getPostFT(from,to);

    res.render('note', {
        posts: loadNotes
    });
});


export default router;