const posts = new Map();
let nextId = 0;

//post ya añadidos
addPost({ title: "Compra", items: new Map() });
addPost({ title: "Clase", items: new Map() });
addPost({ title: "Quehaceres", items: new Map() });
addPost({ title: "Aplicaciones", items: new Map() });
addPost({ title: "Ver Series", items: new Map() });
addPost({ title: "Ordena", items: new Map() });
addPost({ title: "Casa", items: new Map() });
addPost({ title: "Madrugar", items: new Map() });
addItem(getPost("0"),"Puerros");
addItem(getPost("0"),"Cebolla");
addItem(getPost("0"),"Pimientos");
addItem(getPost("1"),"FW");
addItem(getPost("1"),"DAS");
addItem(getPost("1"),"SO");
addItem(getPost("2"),"Limpiar");
addItem(getPost("2"),"Cocinar");
addItem(getPost("2"),"Recoger");
addItem(getPost("3"),"Instagram");
addItem(getPost("3"),"Calendario");
addItem(getPost("3"),"Contactos");
addItem(getPost("4"),"One Piece");
addItem(getPost("4"),"El cuento de la criada");
addItem(getPost("4"),"Orange is the new black");
addItem(getPost("5"),"Tarjeta SSD");
addItem(getPost("5"),"Tarjeta wi-fi");
addItem(getPost("5"),"Microchip");
addItem(getPost("6"),"Televisión");
addItem(getPost("6"),"Baño");
addItem(getPost("6"),"Cocina");
addItem(getPost("7"),"No duermes mucho");
addItem(getPost("7"),"Tienes sueño");
addItem(getPost("7"),"Aprovechas el día");



//funciones añadir
export function addPost(post) {
    let id = nextId++;
    post.id = id.toString();
    posts.set(post.id, post);
}

export function addItem(post,item){
    let idtope = post.items.size;
    idtope++;
    post.items.idtope = idtope.toString();
    let setItem = {name: item};
    setItem.idItem = idtope;
    post.items.set(post.items.idtope, setItem);
}

export function setItems(itemes,post){
    post.items = itemes
}

//funciones eleminar
export function deletePost(id){
    posts.delete(id);
}

export function deleteItem(index, items){
    items.delete(index);
}

//funciones obtener
export function getPosts(){
    return [...posts.values()];
}


export function getPost(id){
    return posts.get(id);
}

/* Para Ajax */
export function getPostFT(from, to) {
    let values = [...posts.values()];
    if (from !== undefined) {
        return values.slice(from, to);
    } else {
        return values;
    }
}

export function getItems(id){
    return [...posts.get(id).items.values()];
}

export function getItemsKeys(items){
    return items.keys();
}

export function getItemss(itemss){
    return [...itemss.values()];
}

export function getItemsKV(id){
    return posts.get(id).items;
}

export function getTitle(id){
    return posts.get(id).title;
}

export function getItemsId(id){
    return posts.get(id).items.idtope;
}

export function getNextId(){
    return nextId;
}