import { fileURLToPath } from 'url';
import { dirname } from 'path';

//obtenemos las rutas relativas de la carpeta de rsc gracias a estas dos funciones exportadas

export const __dirname = dirname(fileURLToPath(import.meta.url));