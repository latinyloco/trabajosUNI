#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int head(char*,int);

int main (int argc, char *argv[]){

	int aux;
	aux = atoi(argv[3]);
	head(argv[1],aux);


}

int head (char *nom, int ln){
	
	//declaración de variables
	FILE *fp;	//variable fichero
	int cont;	//variable contador
	const int buf = 256;	//constante tope del buffer del fichero
	char cad[buf];	//buffer del fichero	
	int acc;
	
	//comprobación de fichero
	fp = fopen(nom,"r");	//abrimos fichero

	if (fp == NULL){	//comprobamos que el fichero existe
		fprintf(stderr,"El fichero no existe\n");
		exit(1);
	}
	
	//escoger la primeras líneas del fichero
	cont = 1;	//inicializar contador
	while((cont<=ln)&&(fgets(cad,buf,fp)!=NULL)){	//mientras el fichero no se acabe o no hayamos escogido las líneas pedidas
		printf("Linea %d: %s\n", cont, cad);	//printear la cadena
		cont++;
	}
	fclose(fp);

}
