#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int head(char*,int);

int main (int argc, char *argv[]){

	int aux;
	aux = atoi(argv[3]);
	head(argv[1],aux);


}

int head (char *nom, int ln){

	FILE *fp;
	int cont;
	const int buf = 256;
	char cad[buf];
	int acc;
	fpos_t pos;
	
	printf("Directorio: %s\n",nom);
	printf("Lineas: %d\n",ln);
	
	acc = access(nom,R_OK);
	printf("Accesibilidad: %d\n", acc);
	

	fp = fopen(nom,"r");

	if (fp == NULL){
		fprintf(stderr,"El fichero no existe\n");
		exit(1);
	}
	cont = 1;
	printf("Variable cont: %d\n",cont);
	
	long des;
	des = 1028;
	
	fgetpos(fp,&pos);
	printf("%p\n",&pos);
	fseek(fp,des,SEEK_END);
	des = ftell(fp);
	fgetpos(fp,&pos);
	printf("Puntero: %p\n",&pos);
	printf("Ftell: %ld\n",des);
	

	
	while((cont<=ln)&&(fgets(cad,buf,fp)!=NULL)){
		printf("Linea %d: %s\n", cont, cad);
		cont++;
	}
	fclose(fp);

}
