#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int longline(char*,int);
char** algoritmo(char**, long*, char*, int);

int main (int argc, char *argv[]){
	
	int aux;
	aux = atoi(argv[3]);
	longline(argv[1],aux);
}


int longline (char *nom, int ln){
	
	//Variables
	FILE *fp;		//variable de fichero
	int cont;		//variable contador
	const int buf = 4036;	//constante tope del buffer del fichero
	char cad[buf];		//buffer del fichero	
	int i;			//variable para el for (recorrer el array)
	char **array;		//array de string para guardar la parte del fichero que queremos
	long *longArray;
	long largo;

	//Comprobación de fichero
	fp = fopen(nom,"r");	//abrimos fichero

	if (fp == NULL){	//comprobamos que el fichero existe
		fprintf(stderr,"El fichero no existe\n");
		exit(1);
	}
	
	//Proceso de escoger y ordenar líneas
	largo = 0;				//iniciaizamos largo
	cont = 0; 				//inicializamos contador
	array = (char**) malloc(ln*sizeof(char));	//le damos espacio dinámico al array
		
		//si el fichero está vacío
	if(fgets(cad,buf,fp) == NULL)
		printf("EL fichero está vacío.\n");
		
		//si el fichero no está vacío
	else{		
			//dar espacio dinámico al array de strings e inicializar el de largura
		longArray = (long*) calloc(ln,sizeof(long));	//incializar array de longitudes a 0 y darle espacio de memoria dinámico
		for(i=0; i<ln; i++){			
			array[i] = (char*) malloc(buf*sizeof(char));	//damos espacio dinámico al array de strings
		}
		
			//inicializar array de strings	
		largo = strlen(cad);			//obtenemso la largura de la cadena leida
		strcpy(array[0],cad);			//introducir la primera línea en el array
		longArray[0] = largo;			//guardamos el largo de esta en la casilla correspondiente
		cont++;
	
			//rellenar y ordenar el resto de los arrays
		while(fgets(cad,buf,fp)!=NULL){		//miestras que no acabemos de leer el fichero
			largo = strlen(cad);
			algoritmo(array,longArray,cad,ln);			//ordenamos ambos arrays
			cont++;
		}
	}
	
	
	//Mostrar líneas
	for(i=0; i<=(ln-1); i++)
		printf("Línea %d: %s\n",i+1,array[i]);
		
	free(array);
	free(longArray);
	fclose(fp);
	return 0;
	
}

char** algoritmo(char **des, long *num, char string[], int lin){

	//Variables
	int j, k;
	long longitud;
			
	//Algoritmo de ordenación
	longitud = strlen(string);
	for(j=0; j<lin; j++){
		if(longitud>num[j]){
			for(k=lin-1; k>j; k--){
				strcpy(des[k],des[k-1]);
				num[k] = num[k-1];
			}
			
			strcpy(des[j],string);
			num[j] = longitud;
			longitud = 0;
		}
	}
	
	return des;
}
