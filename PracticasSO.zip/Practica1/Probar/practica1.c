#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libreria.h"

int main(int argc, char *argv[]){

	int op; 
	int ter;

	//si no hay sufiente comentarios
	if(argc != 4){
		fprintf(stderr,"Formato: ./archivo opc numero_lineas.\n");
		printf("Opcs disponibles:\n");
		printf("  1. Head\n");
		printf("  2. Tail\n");
		printf("  3. LongLine\n");
		exit(1);
	}
	
	//si hay sufientes comentarios
	else{
		op = atoi(argv[2]);
		ter = atoi(argv[3]);
		
		if(op == 1){
			printf(" -- HEAD --\n");
			head(argv[1],ter);	
		}
		else if(op == 2){
			printf(" -- TAIL --\n");
			tail(argv[1],ter);
		}
		else if(op == 3){
			printf(" -- LONGLINE --\n");
			longlines(argv[1],ter);
		}
		else{
			fprintf(stderr,"Opción introducida incorrecta\n");
			exit(1);
		}    
	}
	
	return 0;

}
