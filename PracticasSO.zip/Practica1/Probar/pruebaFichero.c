#include <stdio.h>
#include <stdlib.h>

int main(){

	int const NUMGETS = 256;
	char *nombreArchivo;
	nombreArchivo = "/home/tinyloco/Escritorio/Scrip/Scrips/ejer1_T2.sh";
	char cadena[NUMGETS];
	FILE *fp;
	char *cadenaLeida;
	
	fp = fopen(nombreArchivo,"r");
	if(fp==NULL){
		printf("No existe\n");
		exit(1);
	}
	else
		printf("Existe\n");
	
	/*while(fgets(cadena,NUMGETS,fp) != NULL){
		printf("%s", cadena);
	}*/
	
	fgets(cadena,NUMGETS,fp);
	fgets(cadena,NUMGETS,fp);
	printf("%s", cadena);

	fclose(fp);

}
