#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int tail(char*,int);

int main (int argc, char *argv[]){

	int aux;
	aux = atoi(argv[3]);
	tail(argv[1],aux);


}

int tail (char *nom, int ln){
	
	//variables
	FILE *fp;	//variable de fichero
	int cont;	//variable contador
	const int buf = 256;	//constante tope del buffer del fichero
	char cad[buf];		//buffer del fichero	
	int i;			//variable para el for (recorrer el array)
	char **array;	//array de string para guardar la parte del fichero que queremos
	
	//comprobación de fichero
	fp = fopen(nom,"r");	//abrimos fichero
	

	if (fp == NULL){	//comprobamos que el fichero existe
		fprintf(stderr,"El fichero no existe\n");
		exit(1);
	}
	
	//le damos espacio dinámico al array
	array = (char**) malloc(ln*sizeof(char));	
	for(i=0; i<ln; i++){			
		array[i] = (char*) malloc(buf*sizeof(char));	//damos espacio dinámico al array de strings
		printf("Pos %d: %s\n",i,array[i]);
	}
	
	//escoger las últimas líneas
	cont = 0; 	//inicializamos contador
	while(fgets(cad,buf,fp)!=NULL){		//miestras que no acabemos de leer el fichero
		if(cont < ln){		//si el array no se ha rellenado por completo
			printf("Strcopy.\n");
			printf("Cont: %d\n",cont);
			strcpy(array[cont],cad);	//copiarlo en la última casilla vacía
			printf("Hola.\n");
		}
		else{	//si el array está completo
			for(i=0; i<ln-1; i++){	//recorrer el array para
				strcpy(array[i],array[i+1]);	//mover las casillas una posición haca arriba ignorando la primera posición, ya ue no nos interesa para la funcición que queremos realizar
			}
			strcpy(array[ln-1],cad);	//poner en al úlima casilla, la última línea leida del fichero
			printf("Hola2.\n");
		}
		cont++;
	}
	fclose(fp);	//cerrar fichero
	
	//Mostrar líneas
	printf("Hola3.\n");
	for(i=0; i<=(ln-1); i++)
		printf("Línea %d: %s\n",i+1,array[i]);

}


