#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char** algoritmo(char**, long*, char*, int);

int head (int ln){
	
	//Declaración de variables
	int cont;			//variable contador
	const int buf = 4036;		//constante tope del buffer del fichero
	char cad[buf];			//buffer del fichero	
	

	//Escoger la primeras líneas del fichero y salir si el fichero no exite
	cont = 1;						//inicializar contador
	while((cont<=ln)&&(fgets(cad,buf,stdin)!=NULL)){	//mientras el fichero no se acabe o no hayamos escogido las líneas pedidas
		printf("Linea %d: %s\n", cont, cad);		//printear la cadena
		cont++;
	}
	return 0;

}

int tail (int ln){
	
	//Variables
	int cont;		//variable contador
	const int buf = 4036;	//constante tope del buffer del fichero
	char cad[buf];		//buffer del fichero	
	int i;			//variable para el for (recorrer el array)
	char **array;		//array de string para guardar la parte del fichero que queremos
	
	
	//Le damos espacio dinámico al array
	array = (char**) malloc(ln*sizeof(cad));	
	for(i=0; i<ln; i++){			
			array[i] = (char*) malloc(buf*sizeof(char));	//damos espacio dinámico al array de strings
	}
	
	//Escoger las últimas líneas
	cont = 0; 					//inicializamos contador
	while(fgets(cad,buf,stdin)!=NULL){			//miestras que no acabemos de leer el fichero
		if(cont < ln){				//si el array no se ha rellenado por completo
			strcpy(array[cont],cad);	//copiarlo en la última casilla vacía
		}
		else if(cont >= (ln-1)){			//si el array está completo
			for(i=0; i<(ln-1); i++){		//recorrer el array para
				strcpy(array[i],array[i+1]);	//mover las casillas una posición haca arriba ignorando la primera posición, ya ue no nos interesa para la funcición que queremos realizar
			}
			strcpy(array[ln-1],cad);	//poner en al úlima casilla, la última línea leida del fichero
		}
		cont++;
	}
	
	//Mostrar líneas
	for(i=0; i<=(ln-1); i++)
		printf("Línea %d: %s\n",i+1,array[i]);
		
	free(array);
	return 0;

}

int longlines(int ln){
	
	//Variables
	int cont;		//variable contador
	const int buf = 4036;	//constante tope del buffer del fichero
	char cad[buf];		//buffer del fichero	
	int i;			//variable para el for (recorrer el array)
	char **array;		//array de string para guardar la parte del fichero que queremos
	long *longArray;
	long largo;
	
	//Proceso de escoger y ordenar líneas
	largo = 0;				//iniciaizamos largo
	cont = 0; 				//inicializamos contador
	array = (char**) malloc(ln*sizeof(cad));	//le damos espacio dinámico al array
		
			//dar espacio dinámico al array de strings e inicializar el de largura
	longArray = (long*) calloc(ln,sizeof(long));	//incializar array de longitudes a 0 y darle espacio de memoria dinámico
	for(i=0; i<ln; i++){			
		array[i] = (char*) malloc(buf*sizeof(char));	//damos espacio dinámico al array de strings
	}
		
		//inicializar array de strings	
	largo = strlen(cad);			//obtenemso la largura de la cadena leida
	strcpy(array[0],cad);			//introducir la primera línea en el array
	longArray[0] = largo;			//guardamos el largo de esta en la casilla correspondiente
	cont++;
	
		//rellenar y ordenar el resto de los arrays
	while(fgets(cad,buf,stdin)!=NULL){		//miestras que no acabemos de leer el fichero
		largo = strlen(cad);
		algoritmo(array,longArray,cad,ln);			//ordenamos ambos arrays
		cont++;
	}
	
	
	
	
	//Mostrar líneas
	for(i=0; i<=(ln-1); i++)
		printf("Línea %d: %s\n",i+1,array[i]);
		
	free(array);
	free(longArray);	
	return 0;
}

char** algoritmo(char **des, long *num, char string[], int lin){

	//Variables
	int j, k;
	long longitud;
			
	//Algoritmo de ordenación
	longitud = strlen(string);
	for(j=0; j<lin; j++){
		if(longitud>num[j]){
			for(k=lin-1; k>j; k--){
				strcpy(des[k],des[k-1]);
				num[k] = num[k-1];
			}
			
			strcpy(des[j],string);
			num[j] = longitud;
			longitud = 0;
		}
	}
	
	return des;
}

