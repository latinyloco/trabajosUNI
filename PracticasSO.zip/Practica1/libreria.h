#ifndef _LIBRERIA_H
#define _LIBRERIA_H
int head(int N);
int tail(int N);
int longlines(int N);
#include "libreria.c"
#endif
