#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <wait.h>
#include <fcntl.h>
#include "parser.h"
#include <string.h>

typedef struct job {//creamos una estrura que tiene un pids y un string procedente de line. Para Jobs.
    int id; //número de instruccion introducida
    pid_t *pids; //array de todos los procesos que tiene cada instruccion
    int npid; //numero de mandatos de cada instruccion (ls|wc) --->npid=2
    char line[1024];//reservamos memoria para 1024 caracteres disponibles para cada instruccion completa (con varios comandos tambien)(igual que buf)
} job;

job *jobs;
int maximo;
int ntrabajos;//numero trabajos actuales
int totalt;//numero trabajos desde el inicio de la ejecucion


int main(void) {
    char buf[1024];
    tline *line;
    int i, j;

    ntrabajos = 0;
    maximo = 5;
    totalt = 1;
    jobs = malloc(sizeof(job) *
                  maximo); //reservamos memoria para todos los trabajos (cada linea de instruccion es un trabajo)


    printf("msh> ");
    while (fgets(buf, 1024, stdin)) {

        for (int i = ntrabajos - 1; i >=0; i--) {   //se recorre cada trabajo (linea completa de comandos) para liberar la memoria de los trabajos que ya han finalizado
            int terminado = 1;
            for (int j = 0; j <jobs[i].npid; j++) {//se recorre cada proceso de cada trabajo (cada mandato) para comprobar si ha terminado o no
                if (jobs[i].pids[j] == -1) {  //si ya se ha marcado como "terminado" se procede al siguiente proceso
                    continue;
                }
                
                int res;
                res = waitpid(jobs[i].pids[j], NULL, WNOHANG); //se guarda en res el estado del proceso
                if (res == 0) {//aun no ha terminado
                    terminado = 0;
                    break;
                } else {//ha terminado
                    jobs[i].pids[j] = -1; //se marca este proceso como "terminado"
                }
            }
            if (terminado == 1) { //todos los procesos marcados
                printf("El trabajo %d (%s) ha terminado\n", jobs[i].id, jobs[i].line);
                free(jobs[i].pids);//borramos o liberamos la memoria del proceso que ya ha terminado
                for (int j = i; j < ntrabajos - 1; j++) {
                    jobs[j] = jobs[j + 1]; //movemos  todos los trabajos un puesto abajo
                }
                ntrabajos--;
            }

        }

        line = tokenize(buf);
        if (line == NULL) {
            continue;
        }
        int *procesos;
        if (line->background) {
            procesos = malloc(sizeof(int) * line->ncommands);//reservamos memoria en dinámico para un array de pids para jobs
        }

        if (line->ncommands == 1) { //Si solo tiene un comando
            pid_t pid = fork();
            if (pid == 0) {
                //redirecciones
                if (line->redirect_input != NULL) {
                    int fichero = open(line->redirect_input, O_RDONLY, 777);
                    if (fichero == -1) {
                        printf(stderr, "No se ha creado el fichero correctamente");
                    } else {
                        dup2(fichero, 0);
                    }
                }
                if (line->redirect_output != NULL) {
                    int fichero = open(line->redirect_output, O_WRONLY | O_CREAT | O_TRUNC, 777);
                    dup2(fichero, 1);


                }
                if (line->redirect_error != NULL) {
                    int fichero = open(line->redirect_error, O_WRONLY | O_CREAT | O_TRUNC, 777);
                    dup2(fichero, 2);

                }

                execv(line->commands[0].filename, line->commands[0].argv);
                exit(0);

            } else {//padre
                if (line->background) {//si está en segundo plano guardamos el pid del proceso en el array que volcaremos a jobs
                    procesos[0] = pid;
                } else if (strcmp(line->commands[0].argv[0], "jobs") == 0) {//comprobamos que el comando sea o no jobs
                    if (line->commands[0].argv[1] > 0) {
                        printf(stderr, "Error, has introducido algun argumento a jobs");
                    } else {
                        for (i = 0; i < ntrabajos; i++) {//recorre todos los trabajos en ejecución
                            printf("[%d]   Running   %s \n", jobs[i].id, jobs[i].line);
                        }
                    }
                } else if (strcmp(line->commands[0].argv[0], "fg") == 0) {//comprobamos que el comando sea o no fg
                    int index = -1;
                    if (line->commands[0].argc > 2) {
                        printf(stderr, "Error, numero de argumentos incorrecto");
                    } else {
                        if (line->commands[0].argc ==
                            1) {//si no se introduce indice, index será el último trabajo existente en background
                            index = ntrabajos - 1;
                        } else {
                            long jn = strtol(line->commands[0].argv[1], NULL,
                                             0); //guardamos en jn el numero del proceso a cambiar

                            for (int current = 0; current <
                                                  ntrabajos; current++) {//recorremos los trabajos hasta encontrar el trabajo con el id introducido
                                if (jobs[current].id == jn) {
                                    index = current;//asignamos a index el identificador del proceso
                                    break;
                                }
                            }
                        }
                        if (index == -1) {
                            printf("No se ha encontrado el trabajo a cambiar");
                        } else {
                            printf("El trabajo especificado se pasa a foreground.\n");
                            for (i = 0; i < jobs[index].npid; i++) {//recorremos los procesos del trabajo en cuestion
                                if (jobs[index].pids[i] != -1) {
                                    waitpid(jobs[index].pids[i], 0,
                                            0);//Forzamos a esperar al proceso que estaba en background
                                }
                            }
                        }
                    }
                } else if (strcmp(line->commands[0].argv[0], "cd") == 0) {//comprobamos que el comando sea o no un cd
                    char *direccion;
                    char buffercd[1024];

                    if (line->commands[0].argc == 1) { //si no se ha escrito directorio destino, direccion es home
                        direccion = getenv("HOME");
                    } else {
                        direccion = line->commands[0].argv[1]; //si se ha escrito directorio destino, se le asigna direccion
                    }
                    if (chdir(direccion) !=
                        0) {//se realiza el cambio de directorio pero si devuelve distinto de 0 es por que da un error
                        printf("Ese directorio no existe.\n");
                    } else {
                        printf("El directorio actual es: %s\n", getcwd(buffercd, -1));
                    }

                } else {//el padre espera a que el hijo termine para volver a mostrar el prompt
                    waitpid(pid, 0, 0);
                }
            }
        } else {//Si tiene mas de un comando


            int p[line->ncommands - 1][2]; //creamos todos los pipes
            for (i = 0; i < line->ncommands - 1; i++) {
                pipe(p[i]);
            }
            for (i = 0; i < line->ncommands; i++) {
                pid_t pid = fork();
                if (pid < 0) {
                    printf("ERROR, no se ha creado correctamente el hijo.");
                } else if (pid == 0) {//HIJOS
                    if (i == 0) {//Primer comando

                        dup2(p[i][1], 1); //cambia salida estandar por escritura pipe
                        close(p[i][1]);
                        close(p[i][0]);
                        for (j = i + 1; j < line->ncommands - 1; j++) {//Cerramos el resto de pipes
                            close(p[j][0]);
                            close(p[j][1]);
                        }
                        if (line->redirect_input != NULL) {
                            //primer mandato
                            int fichero = open(line->redirect_input, O_RDONLY, 777);
                            if (fichero == -1) {
                                printf(stderr, "No se ha creado el fichero correctamente");
                            } else {
                                dup2(fichero, 0);
                            }
                        }
                    }
                    if (i == line->ncommands - 1) {//ultimo comando
                        dup2(p[i - 1][0], 0);//cambia la entrada estandar por la lectura del ultimo pipe
                        close(p[i - 1][0]);
                        if (line->redirect_output != NULL) {
                            int fichero = open(line->redirect_output, O_WRONLY | O_CREAT | O_TRUNC, 777);
                            dup2(fichero, 1);
                        }
                        if (line->redirect_error != NULL) {
                            int fichero = open(line->redirect_error, O_WRONLY | O_CREAT | O_TRUNC, 777);
                            dup2(fichero, 2);
                        }
                    } else {//Comandos intermedios
                        dup2(p[i - 1][0], 0);//cambia entrada estandar por lectura del pipe anterior
                        dup2(p[i][1], 1);//cambia salida estandar por escritura del pipe actual
                        close(p[i - 1][0]);
                        close(p[i][1]);
                        for (j = i + 1; j < line->ncommands - 1; j++) {//Cerramos el resto de pipes
                            close(p[j][0]);
                            close(p[j][1]);
                        }//cerramos resto de pipes
                    }
                    execv(line->commands[i].filename, line->commands[i].argv);
                } else {//PADRE, se encarga de cerrar los pipes ya utilizados por sus hijos y de esperarlos
                    if (i == 0) {//primer comando
                        close(p[i][1]);
                    }
                    if (i == line->ncommands - 1) {//Ultimo comando
                        close(p[i][0]);

                    } else {//Intermedios
                        close(p[i - 1][0]);
                        close(p[i][1]);
                    }
                }
                if (!line->background) {//Si esta en primer plano
                    waitpid(pid, 0, 0);
                } else {//Si esta en segundo plano
                    procesos[i] = pid;//guardamos en el array el pid del proceso actual para luego meterlo a job
                }

            }


        }
        if (line->background) {
            if (ntrabajos == maximo) { //si hemos llenado la memoria de jobs (5 mandatos) y queremos meter más
                maximo = maximo * 2;
                jobs = realloc(jobs, sizeof(job) * maximo);//cambia la memoria que teniamos reservada (la aumenta)
            }

            jobs[ntrabajos].id = totalt; //contador/identificador del trabajo en cuestion.
            jobs[ntrabajos].pids = procesos; //llenamos el array de pids de jobs con el array completo de pids por instruccion
            jobs[ntrabajos].npid = line->ncommands;//asignamos a npid el numero de comandos por instruccion
            strcpy(jobs[ntrabajos].line, buf);//asignamos a line la linea de instruccion en cuestrion
            printf("El trabajo %d está siendo ejecutado\n", jobs[ntrabajos].id);
            ntrabajos++;
            totalt++;
        }

        printf("msh> ");
    }
    free(jobs);//liberamos la memoria al acabar la shell

}
