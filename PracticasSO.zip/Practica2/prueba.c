#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <wait.h>
#include <fcntl.h>
#include "parser.h"
#include <string.h>

#define BUF 1024

typedef struct{
	char *promp;
	int *ids;
}tBG;



// MAIN
int main(void){

	char buf[BUF];		//buffer line
	char buffer[BUF];	//buffer backgraund
	char *ruta;		//string para getenv
	char cwd[1024];		//string para getcwd
	tline *line;
	int i, j, l, fdin, fderr, fdout, nump, estado;	//contadores, variabels para for, uso de numeracion variada
	
	tBG *backgraund;
	
	int *backgarundPID;
	char **backgarundPROMP;
	
	
	
	/* DB BACKGRAUND */
	//cremos un array para guardar el pid o los pids de los procesos que están en backgraund
	//se creara nuevo cada vez que se inicie la minishell, memoria incial = 4 procesos
	printf("Hola\n");
	backgraund = malloc(4*sizeof(backgraund));	//cremos un array dinámico que en un principio tendrá espacio para 4 procesos en segundo plano
	backgraund[0].promp = "Funciona perra";
	printf("estado =  %s",backgraund[0].promp);
	printf("Hola2\n");
	backgarundPID = (int*) malloc(4*sizeof(buffer));	//damos espacio dinámico a nuestro array y lo inicializamos a 0ç
			
	backgarundPROMP = (char**) malloc(4*sizeof(buffer));	//lo mismo pero para lo que ncontramos en el promp 
	for(i=0; i<4; i++){			
		backgarundPROMP[i] = (char*) malloc(BUF*sizeof(char));	//damos espacio dinámico al array de string
	}
			
	nump = 0;	//inicializar numero de procesos actuales en bg
	

	/* PROGRAMA */
	printf("msh> "); 
	while (fgets(buf, BUF, stdin)){
		
		line = tokenize(buf);
		
		/*** BACKGRAUND ***/
		//Comprobamos que queden hijos (procesos) activos o no
		for(i=nump-1; i>=0; i--){		
			estado = waitpid(backgarundPID[i], NULL, WNOHANG);	//comprobamos si su estado se ha actualzado
			if(estado == -1){					//en el caso de que su estado sea -1, significa que han acabado
				printf("El trabajo %s& ha acabado.\n",backgarundPROMP[i]);
				waitpid(backgarundPID[i], 0, 0);	
				for (j = i; j < nump - 1; j++) {			//recolocamos el array una posición cada casilla hacia arriba para ordenarlo
                    			strcpy(backgarundPROMP[j],backgarundPROMP[j + 1]);		
                    			backgarundPID[j] = backgarundPID[j + 1];		
                		}
                		nump--;
			}
		}
		
		
		/*** NO VÁLIDO ***/
		if(line == NULL || strcmp(buf,"\n") == 0){
			continue;
		}
		
		
		
		/*** COMANDOS CREADOS ***/
		//SIGINT (CTRL+C)
		
		//JOBS
		else if(strcmp(line->commands[0].argv[0],"jobs") == 0){
		
			if(nump == 0){
				printf("No hay procesos en backgraund ejecutandose.\n");
			} 
			else{
				for(i=0; i<nump; i++){				//recorremos las casillas del array en función de los hijos que se hayan creado en backgraund
					printf("[%d]+ Running    %s \n",i+1,backgarundPROMP[i]);
				}
			}
		}
		
		//FG
		else if(strcmp(line->commands[0].argv[0],"fg") == 0){
			//si el comando fg no tiene argumentos (numero)
			if(line->commands[0].argv[1] == NULL){
				//si no hay procesos en el backgraund
				if(nump == 0){	
					printf("No hay procesos en backgraund ejecutandose.\n");
				}
				//si hay procesos en el backgraund
				else{
					printf("El trabajo %s& esta en foregraund.\n",backgarundPROMP[nump]);
					waitpid(backgarundPID[nump], 0, 0);					//esperamos a que el hijo termine
                			nump--;
				}
			}
			//si el comando fg tiene argumentos (numero)
			else{
				int pb = atoi(line->commands[0].argv[1]);	//obtenemso el número del proceso que queremos pasar a foregraund
				
				//si hay demasiado comandos con el fg
				if(line->commands[0].argc>2){
					printf("Demasiados argumentos para el fg.\n");
				}
				
				//si no hay procesos en el backgraund
				else if(nump == 0){
					printf("No hay procesos en backgraund ejecutandose.\n");
				}
				
				//si hay procesos en el backgraund y el numero es uno de los procesos
				else if(pb > 0 || pb < nump+2){
					printf("El trabajo %s& esta en foregraund.\n",backgarundPROMP[pb-1]);
					waitpid(backgarundPID[pb-1], 0, 0);			//esperamos a que el hijo termine en foregraund
                			
                			for (j = pb-1; j < nump - 1; j++) {			//recolocamos el array una posición cada casilla hacia arriba para ordenarlo
                				strcpy(backgarundPROMP[j],backgarundPROMP[j + 1]);			
		            			backgarundPID[j] = backgarundPID[j + 1]; 			
		        		}
		        		nump--;
				
				}
				
				//si el numero no está en los procesos 
				else{
					printf("Argumendo del fg mal introducido: %s.\n",line->commands[0].argv[1]);
				}
			}
		}
		
			
		//EXIT
		else if(strcmp(line->commands[0].argv[0],"exit") == 0){
			for(i=0; i<nump; i++){
				waitpid(backgarundPID[i], 0, 0);			//esperamos a que el hijo termine en foregraund
			}
			
			exit(0);
		}
		
		//CD
		else if(strcmp(line->commands[0].argv[0],"cd") == 0){
			//solo comando cd
			if(line->commands[0].argc == 1){
				ruta = "HOME";		   //obtener path del HOME
				//la ruta existe
				if(chdir(getenv(ruta)) == 0){
					printf("Ruta actual: %s\n",getcwd(cwd,sizeof(cwd)));	//mostramos la ubicación actual
				}
				//la ruta no existe
				else{
					printf("Ruta inexistente.\n");
				}
				
			}
			//comando cd con ruta
			else if(line->commands[0].argc == 2){
				ruta = line->commands[0].argv[1];
				//la ruta existe
				if(chdir(ruta) == 0){							//cambiamos de ruta, en caso de que no de error
					printf("Ruta actual: %s\n",getcwd(cwd,sizeof(cwd)));		//mostramos la ruta actual a la que se ha cambiado
				}
				//la ruta no existe
				else{									//sino se muestra error por pantalla
					printf("Ruta inexistente.\n");
				}
									
			}
			//comando cd con errores en la ruta
			else{
				printf("Ruta indicada erronea.\n");
			}
		}
		



		/*** FOREGRAUND Y BACKGRAUND***/
		else{	
			int p[line->ncommands - 1][2];
			pid_t pid;

			////** UN COMANDO FOREGRAUND Y BACKGRAUND **////
			if (line->ncommands == 1){

				// si el mandato no exite
				if (line->commands[0].filename == NULL){
					printf("mandato %s incorrecto: No se encuentra el mandato\n",line->commands[0].argv[0]);
				}
				// si el mandato exite
				else{
				
				
				
				
				//** UN COMANDO BACKGRAUND **//
				if(line->background){
				
					pid = fork();
					
					//error hijo
					if (pid < 0){	
						printf("Error con la creación del hijo\n");
					}
					
					//hijo
					if (pid == 0){	
					
						// sacamos la solución por un fichero
						if (line->redirect_input != NULL){
							fdin = open(line->redirect_input, O_RDONLY, 777);

							// en el caso de que el fichero exista
							if (fdin > 0){
								dup2(fdin, 0);
							}
							// en el caso de que el fichero no exista
							else{
								fprintf(stderr, "%s error: el fichero no existe.\n", line->redirect_input);
							}
						}
						// sacamos la solución por un fichero
						if (line->redirect_output != NULL){
							fdout = open(line->redirect_output, O_CREAT | O_WRONLY, 777);
							dup2(fdout, 1);
						}

						// sacamos la solución por un fichero error
						else if (line->redirect_error != NULL){
							fderr = open(line->redirect_error, O_CREAT | O_WRONLY, 777);
							dup2(fderr, 2);
						}
						
						execv(line->commands[0].filename, line->commands[0].argv);
					
					}
					
					//padre
					else{	
						strcpy(buffer,line->commands[0].argv[0]);
						strcat(buffer," ");
						for(i=1; i<line->commands[0].argc; i++){
							strcat(buffer,line->commands[0].argv[i]);
							strcat(buffer," ");
						}
						
						backgarundPID[nump] = pid;		//metemos al array el pid del hijo
						strcpy(backgarundPROMP[nump],buffer);	//metemos al array lo que hay en buffer
						memset(buffer,0,BUF);			//lipiar el array para el proximo foregraund
						nump++;
					}
				}
				
				
				//** UN COMANDO FOREGRAUND **//
				else{
					pid = fork();
					
					/* proceso hijo */
					if (pid < 0){	//error hijo
						printf("Error con la creación del hijo\n");
					}
					else if (pid == 0){

						// sacamos la solución por un fichero
						if (line->redirect_input != NULL){
							printf("redirección de entrada: %s\n", line->redirect_input);
							fdin = open(line->redirect_input, O_RDONLY, 777);

							// en el caso de que el fichero exista
							if (fdin > 0){
								dup2(fdin, 0);
							}
							// en el caso de que el fichero no exista
							else{
								fprintf(stderr, "%s error: el fichero no existe.\n", line->redirect_input);
							}
						}
						// sacamos la solución por un fichero
						if (line->redirect_output != NULL){
							printf("redirección de salida: %s\n", line->redirect_output);
							fdout = open(line->redirect_output, O_CREAT | O_WRONLY, 777);
							dup2(fdout, 1);
						}

						// sacamos la solución por un fichero error
						else if (line->redirect_error != NULL){
							printf("redirección de salida error: %s\n", line->redirect_error);
							fderr = open(line->redirect_error, O_CREAT | O_WRONLY, 777);
							dup2(fderr, 2);
						}

						execv(line->commands[0].filename, line->commands[0].argv);
						exit(0);
					}//fin hijo

					/* proceso padre */
					else{
						waitpid(pid, 0, 0);
					}
					
				}}//fin si el mandato exite
			}//fin un comando



			////** MAS UN COMANDO **////
			else if (line->ncommands > 1){
				// Inicializar pipes
				for (l = 0; l < line->ncommands - 1; l++){
					pipe(p[l]);
				}

				// Creacion de los hijos y utilizacion de pipes
				for (i = 0; i < line->ncommands; i++){

					// si el mandato no exite
					if (line->commands[i].filename == NULL){
						printf("mandato %s incorrecto: No se encuentra el mandato\n",line->commands[i].argv[0]);
					}
					// si el mandato exite
					else{

						pid = fork(); // creamos un hijo por cada comando

						/* error al crear al hijo */
						if (pid < 0){
							printf("Error con la creación del hijo\n");
						}

						/* proceso hijo */
						else if (pid == 0){

							// Primer elemento commands
							if (i == 0){
								dup2(p[i][1], 1); // enviamos por el pipe 1

								// sacamos la solución del pipe por un fichero
								if (line->redirect_input != NULL){ 
									printf("redirección de entrada: %s\n", line->redirect_input);
									fdin = open(line->redirect_input, O_RDONLY, 777);

									// en el caso de que el fichero exista
									if (fdin > 0){									
										dup2(fdin, 0);
									}
									// en el caso de que el fichero no exista
									else{
										fprintf(stderr, "%s error: el fichero no existe.\n", line->redirect_input);
									}
								}
							}

							// Ultimo elemento commands
							if (i == line->ncommands - 1){
								dup2(p[i - 1][0], 0); // recibimos por la entrada in la salida del pipe

								// sacamos la solución del pipe por un fichero
								if (line->redirect_output != NULL){
									printf("redirección de salida: %s\n", line->redirect_output);
									fdout = open(line->redirect_output, O_CREAT | O_WRONLY, 777);
									dup2(fdout, 1);
								}

								// sacamos la solución del pipe por un fichero error
								else if (line->redirect_error != NULL){
									printf("redirección de salida error: %s\n", line->redirect_error);
									fderr = open(line->redirect_error, O_CREAT | O_WRONLY, 777);
									dup2(fderr, 2);
								}
							}

							// Elemento intermedio commands
							else{
								dup2(p[i - 1][0], 0);
								dup2(p[i][1], 1);
							}

							// crerramos todos los pipes del hijo que va a hacer el exec
							for (j = 0; j < line->ncommands - 1; j++){
								close(p[j][0]);
								close(p[j][1]);
							}

							execv(line->commands[i].filename, line->commands[i].argv);
						} // fin hijos

						/* proceso padre */
						else{
							// cerramos primer hijo
							if (i == 0){
								close(p[i][1]);
							}
							// cerramos ultimo hijo
							else if (i == line->ncommands - 1){
								close(p[i][0]);
							}
							// cerramos intermedio hijo
							else{
								close(p[i - 1][0]);
								close(p[i][1]);
							}
						}

						// esperamos para que los hijos no se queden zombis
						waitpid(pid, 0, 0);
					}
				} // fin for hijos y padre
			}	  // fin mas de un comando
		}		  // fin solo comandos
		printf("msh> ");
		
	}
	
	free(backgarundPID);
	free(backgarundPROMP);
	return 0;
}
