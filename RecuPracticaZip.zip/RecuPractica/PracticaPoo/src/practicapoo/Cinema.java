package practicapoo;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Cinema{
   
    
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        
        //Empieza el programa y creamos Multiplex
        Multiplex multiplex = new Multiplex();  //crear el obtjeto multiplex para realizar el programa
        multiplex.start();                      //empezar el programa
        
    }
}
