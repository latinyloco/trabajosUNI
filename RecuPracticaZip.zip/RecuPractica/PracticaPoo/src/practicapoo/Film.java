package practicapoo;

import java.io.Serializable;

public class Film implements Serializable{
    
    private String name;
    private String poster;
    private int duration;
    private String description;
    
    //Constructor
    public Film(String name, String poster, String description) {   
        this.name = name;
        this.poster = poster;
        this.description = description;
    }
    
    //Métodos
    public String getName(){
        return name;
    }
    
    public String getPoster(){
        return poster;
    }
            
    public int getDuration(){
        return duration;
    }
    
    public String getDescription(){
        return description;
    }    
}