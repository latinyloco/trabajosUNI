package practicapoo;

import sienens.CinemaTicketDispenser;

public class IdiomSelection extends Operation{

    //Constructor
    public IdiomSelection(CinemaTicketDispenser ctd, Multiplex multiplex){
        super(ctd,multiplex);
    }
    
    //Métodos
    public void doOperation() {
        this.getTitle();
        ctd.setMenuMode();   
        ctd.setTitle(this.getTitle());
        ctd.setOption(0, "English");
        ctd.setOption(1, "Castellano");
        ctd.setOption(2, "Catalán");
        ctd.setOption(3, "Euskera");
        ctd.setOption(4, "");
        ctd.setOption(5, "Out");
        
        char a = ctd.waitEvent(30);
        switch (a) {
            case 'A':
                this.getMultiplex().setIdiom("English");
                break;
            case 'B':
                this.getMultiplex().setIdiom("Castellano");
                break;
            case 'C':
                this.getMultiplex().setIdiom("Catalan");
                break;
            case 'E':
                this.getMultiplex().setIdiom("Euskera");
                break;
            case 'F':
                break;
        }
    }

    @Override
    public String getTitle() {
        return "IDIOM SELECTION";
    }
}
