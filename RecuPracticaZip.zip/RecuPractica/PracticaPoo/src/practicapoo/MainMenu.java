package practicapoo;

import java.io.IOException;
import sienens.CinemaTicketDispenser;

public class MainMenu extends Operation{

    MultiplexState ms;          //obtien en el constructor la lista de teatros que se han cargado
    IdiomSelection idioma = new IdiomSelection(ctd,multiplex);
    MovieTicketSale mts = new MovieTicketSale(ctd,multiplex,ms);
    
    //Constructor
    public MainMenu(CinemaTicketDispenser ctd, Multiplex multiplex, MultiplexState ms){
        super(ctd,multiplex);
        this.ms = ms;
    }
    
    //Métodos
    public void doOperation(){
        
        this.presentMenu();     //presenta las opcioines del menú
        char a = 'A';           //inicializa a para que no de errores
        
        while(a!='F'){              //hasta que a no sea F (salir) no sale del bucle
            this.presentMenu();             //presenta el menú
            
            a = ctd.waitEvent(30);    //espera una respuesta
            
            switch (a) {                    //en el caso de 
                case 'A':                       //A: ir a cambiar el idioma
                    idioma.doOperation();
                break;
                
                case 'B':                                                                                            
                    try {
                        mts.doOperation(ms);        //B: ir al proceso de vender tickets
                    } catch (IOException ex) {
                        System.out.println("Ha ocurrido un error.");
                        System.exit(1);
                    }       
                break;

                case 'C':                       //C: expulsar tarjeta en el caso de que esté adentro
                    ctd.expelCreditCard(5);
                break;
                
                case 'F':
                    System.exit(0);
                    
            }
        }
    }

    @Override
    public String getTitle(){
        return "MENÚ";
    }
    
    public void presentMenu(){

        ctd.setTitle(this.getTitle());
        ctd.setOption(0, "Select idiom");
        ctd.setOption(1, "Select film");
        ctd.setOption(2, "Get Tarjet");
        ctd.setOption(3, "");
        ctd.setOption(4, "");
        ctd.setOption(5, "Out");
        ctd.setDescription(" ");
        ctd.setMenuMode(); 
        ctd.setImage("");

    }

}