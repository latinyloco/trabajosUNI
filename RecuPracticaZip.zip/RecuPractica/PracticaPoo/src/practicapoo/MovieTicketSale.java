package practicapoo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import sienens.CinemaTicketDispenser;

public class MovieTicketSale extends Operation{

    private int myInt;              //teatro(peli) elegido
    private int myint;              //sesion elegida
        
    ArrayList<Seat> seleccionSeat = new ArrayList();     //array de los sitios que se han ocupado al final
    protected int numSeats;                           //numero de sitios que se han ocupado al final
    MultiplexState ms;                                  
    
    PerformPayment pp = new PerformPayment(ctd,multiplex,multiplex.getBank(),this,ms);
    protected Theater theater;
    protected Session session;
    protected ArrayList <Seat> seat;
    
    //CONSTRUCTOR
    public MovieTicketSale(CinemaTicketDispenser ctd, Multiplex multiplex, MultiplexState ms){
        super(ctd,multiplex);
        this.ms = ms;
    }

    
    //ABSTRACCIONES
    public void doOperation(MultiplexState ms) throws IOException {
        
        theater = selectTheater(ms);            //seleccionar teatro
        if (theater==null)
            return;
        
        session = selectSession(ms,theater);       //seleccionar session
        if (session==null)
            return;
        
        seat = selectSeat(ms,theater,session);     //selecccionar sitio/s
        if (seat==null)
            return;
        
        performPayment(ms,theater,session,seat);   //proceder al pago según lo que se ha elegido
        
    }

    @Override
    public String getTitle() {
        return "Select Film";
    }
    
    //PRECIO
    private void performPayment(MultiplexState ms, Theater theater, Session session, List<Seat> seat) throws IOException{
        int supuestoPrecio = computePrice(theater,false);
        int finalPrice =  pp.dooOperation();                   //hacer el proceso de validación de tarjeta y tal
        if(finalPrice==0)
            return;
        
        ctd.setMessageMode();       
        if(supuestoPrecio != finalPrice)
            ctd.setDescription("Successful buy with 30% discount");
        else
            ctd.setDescription("Successful buy");
            
        ctd.setTitle("Press acept for print tickets") ;
        ctd.setOption(0, "");
        ctd.setOption(1, "Acept");
        char o = ctd.waitEvent(30);
              
        ctd.expelCreditCard(0);                //devolver la tarjeta
        List <String> ticket = new ArrayList<>();    //crear el ticket
        ticket.add(" ---- Ticket ----");
        ticket.add("Theater: "+theater.getNumber());
        if(supuestoPrecio != finalPrice)
            ticket.add("Member dicount price: "+finalPrice);
        else
            ticket.add("Price: "+supuestoPrecio);
            
        ticket.add("Film: "+theater.getFilm().getName());
        ticket.add("Session: "+session.getHour());
        int i=1;
        for (Seat s: seat){
            ticket.add("Seat "+(i));
            ticket.add("  Row: "+s.getRow());
            ticket.add("  Col: "+s.getCol());
            ticket.add(" ");
            i++;
        }
        ticket.add("");
        ticket.add("  Now all in one ticket");
        ticket.add("  Save the trees!!!!!!");
        
        
        ctd.print(ticket);          //imprimir el ticket
        ctd.expelCreditCard(5);   //volver a decolver la tarjeta por si no le ha dado tiempo y es inutil
        ms.saveTheaterList();       //guardamos los sitios marcados una vez realizada la compra
    }
    
    public int computePrice(Theater theater, boolean a){
        int finalPrice = theater.getPrice() * numSeats;     //obtener el precio total por asiento
        if(a == true)
            finalPrice = (int) (finalPrice*0.7);
        return finalPrice;
    }
    
    
    //SELECCIONADORES
    public Theater selectTheater(MultiplexState ms){    //elegir nombre de película, el cual va con el número de teatro
        ctd.setTitle(getTitle());
        int i=0;    
        
        List <Theater> theaterList = ms.getTheaterList();   //traemos la lista que tenemos guardada en theater
        String filmName[] = new String[4];                  //creamos un array de string para meter el título de las películas
        
        for (Theater t : theaterList){                      //metemos el nombre de las películas en el array
            filmName[i] = t.getFilm().getName();
            i++;
        }
        
        ctd.setOption(0, filmName[0]);              //mostramos las opciones
        ctd.setOption(1, filmName[1]);
        ctd.setOption(2, filmName[2]);
        ctd.setOption(3, filmName[3]);
        ctd.setOption(4, "");
        ctd.setOption(5, "Out");
        
        
        char a = ctd.waitEvent(30);                     //se optiene en a la eleccion que se ha hecho por pantalla
            switch(a){
                case 'A': 
                    myInt = 0;
                break;
                case 'B': 
                    myInt = 1;
                break;
                case 'C': 
                    myInt = 2;
                break;
                case 'D': 
                    myInt = 3;
                break;
                case 'F':
                    return null;         
        }
  
        Theater selectiveTheater;                           //se crea una variable que sea el teatro elegido
        selectiveTheater = theaterList.get(myInt);     //se guarda el teatro                         
  
        return selectiveTheater;        //se devuelve el teatro seleccionado
    }

    public Session selectSession(MultiplexState ms, Theater theater) throws IOException{   //elegir la session de la película
        ctd.setTitle("Select Session");                             
        ctd.setImage(theater.getFilm().getPoster());            //de ese teatro mostrar el poster de la peli
        ctd.setDescription(theater.getFilm().getDescription());     //mostrar la descripción de esa peli
        
        int i=0;
        ArrayList <Session> sessionList = (ArrayList <Session>) theater.getSessionList();   //obtener la lista de las cuatro sesiones de esa peli
        String horario[] = new String[4];                                                   //crear un string con las horas de las sesiones
        
        for (Session s : sessionList){
            LinkedHashMap <Integer,String> hourSesion = (LinkedHashMap <Integer,String>) s.getHour(); //meter las horas de las sesiones en una variable
            String time = hourSesion.values().toString();  //obtener las sesiones

            horario[i] = time;                      //guardarlo en el array
            i++;
        }
       
        ctd.setOption(0, horario[0]);   //mostrar las opciones
        ctd.setOption(1, horario[1]);
        ctd.setOption(2, horario[2]);
        ctd.setOption(3, horario[3]);
        ctd.setOption(4, "");
        ctd.setOption(5, "Out");
        
        char a = ctd.waitEvent(30);     //obtener en a lo que se pide por pantalla
        int myint = 0;
          
        switch(a){
            case 'A': 
                myint = 0;
            break;
            case 'B': 
                myint = 1;
            break;
            case 'C': 
                myint = 2;
            break;
            case 'D': 
                myint = 3;
            break;
            case 'F': 
                return null;
        }
        
        Session selectiveSession = sessionList.get(myint);      //crear una variable para decir cual es la session seleccionada
        
        return selectiveSession;                                    //devolver dicha sesión
    }
    
    private ArrayList<Seat> selectSeat(MultiplexState ms, Theater theater, Session session){      //elegir los sitios
        ctd.setTitle("Select Seat");
        ArrayList selectSeats = this.presentSeats(ms,theater,session);      //se presentas la tabla de sitios para elegir y se elige
        
        ctd.setOption(0, "Cancel");
        ctd.setOption(1, "Pay");
        
        char select = ctd.waitEvent(30);                        
        if(select=='A')
            return null;
        
        return selectSeats;
    }

    private ArrayList presentSeats(MultiplexState ms, Theater theater, Session session){
        ctd.setTheaterMode(theater.getMaxRows(),theater.getMaxCols());  //mostrar la disposición de los sitios
        for(Seat i: session.getOccupiedSeat()){
            if(i.getState()==1)
                ctd.markSeat(i.getRow(), i.getCol(), 1);
        }

        ctd.setOption(0, "Cancel");
        ctd.setOption(1, "Continue");
        
        //Obtener arbol de sitios       
        numSeats=0;
        char select = ctd.waitEvent(30);
       
        //Bucle para elegir los sitios
        //boolean co = (select!= 'B' && numSeats>0);       //si no hay 4 sitios elegido y la selección es diferente de B no te salgas
        //while (numSeats!=4 || co ){                      //mientras que el número no sea cuatro o no se seleccione continuar siendo el número de asientos mayor a 0
        while(select!='A'){ 
            
            //Comprar o salir
            if (select=='B'){                            //si se seleciona contiuar dentro del bucle, devuelve el numero de asientos elegidos
                this.saveTheaterList(ms,seleccionSeat);     //guardamos los asientos elegidos, pero no los guardamos en el fichero
                return seleccionSeat; 
            }
            else if(select == 'A')                  //sino, se sale del programa si se pulsa cancel
                return null;
            
            
            
            //Si se a marcado sitio
            int c = getRowCol('r',select);            //obtiene la columna del sitio selecionado
            int r = getRowCol('c',select);            //obtiene la fila de la columna seleccionada

            //Se comprueba si está ya ocupado o no
            boolean a = session.isOccupied(r,c);       //dice si ese asiento está ocupado o no
            boolean b = comparator(c,r,seleccionSeat);      //comprueba si se ha elegido uno que ya estaba elegido para eliminarlo
            
            //si se ha elegido un sitio ocupado  
            if(a==true){
                ctd.setTitle("Sitio ocupado");
            }
            
            //si no ha se ha elegido un sitio ocupado
            else{
                //se indica aun no ha llenado el cupo de los asientos 
                if(numSeats!=4){
                    //Se decide qué hacer con l sitio dependiendo de su situación
                    if (b==false){                           //si ese sitio no está ocupado
                        ctd.markSeat(r, c, 3);                 //marca el sitio por pantalla
                        seleccionSeat.add(new Seat(r,c,1));    //añade a la lista de asisentos seleccionados el indicado
                        numSeats++;                            //aumento una unidad los asientos seleccionados
                        ctd.setTitle("Elimina un sitio pulsandole");
                    }       
                }
                //cuando se llena el cupo de asientos y ha elegido un asiento nuevo
                else if(numSeats==4){
                    ctd.setTitle("Cupo de asientos lleno");
                }
            
                //si se quiere eliminar un sitio ya marcado
                if(b==true){
                    ctd.markSeat(r, c, 2);  //lo desmarcamos
                    numSeats--;             //minimizamos el numero de sitios
                    Seat deletear = null;
                    for(Seat s: seleccionSeat){     //buscamos el sitio que hemos guardado y queremos eliminar para eliminarlo
                        if(s.getCol()==c && s.getRow()==r)
                            deletear = s;   
                    }
                    seleccionSeat.remove(deletear);     //eliminar sitio de la lista de sitios
                }
            }
            
            select = ctd.waitEvent(30);   
        }
        
        this.saveTheaterList(ms,seleccionSeat);
        return seleccionSeat;                   //devuelve los sitios seleccionados
    }   
    
    public void saveTheaterList(MultiplexState ms, ArrayList<Seat> seleccionSeat){
        Theater teatrero = (Theater) ms.getTheaterList().get(myInt);
        Session sesioneo = (Session) teatrero.getSessionList().get(myint);
        ArrayList<Seat> listilla = sesioneo.getOccupiedSeat();
        
        for(Seat so: seleccionSeat){    //recorremos nuevos ocupados
            for(Seat li: listilla){     //recorremos ya ocupados
                if(so.getRow()==li.getRow() && so.getCol()==li.getCol())    //si coinciden
                    li.setState(1);                                    //se pone como ocupado
            }
        }
        
        ArrayList<Session> NewSesionList = (ArrayList<Session>) teatrero.getSessionList();  //cogemos lista actual de sesiones
        ArrayList<Theater> NewTheaterList = (ArrayList<Theater>) ms.getTheaterList(); //cogemos lista actual de teatros
        
        sesioneo.setOccupiedSeat(listilla);     //añadimos sesion con sitios bien hechos
        NewSesionList.add(myint, sesioneo);     //guardamos en la lista la sesion actualizada
        NewSesionList.remove(myint+1);          //eliminamos la sesion anigua
        
        teatrero.setSessionList(NewSesionList); //añadimos la nuevalista de sisiones de ese teatro
        NewTheaterList.add(myInt, teatrero);    //añadimos ese tetaro a alista de teatros
        NewTheaterList.remove(myInt+1);         //eliminamos el que sobra
        
        ms.setTheaterList(NewTheaterList);      //añadimos la lista nuevo de teatros al MultiplexState

    }
      
    public boolean comparator(int c, int r, ArrayList<Seat> list){
        
        for (Seat s : list) {
            if (s.getRow()==r && s.getCol()==c)
               return true; 
        }
       
        return false;
    }
    
    
    //GETERS
    public int getRowCol(char z, char select){      //obtiene la columna y la fila seleccionados en pantalla
        
        //Obtener el cod ASCII
        int cod = (int) select;                         //de char a int (obtenemos cod ASCII)
       
        //Pasar a binario el cod ASCII
        String binario = Integer.toBinaryString(cod);   //de int (cod ascii) a string (conseguimos el número en binario además)
        int a = binario.length();                         //obtener largura del string
        String row = binario.substring(a-4,a);     //obtener la parte del binario para coger la codificación de los row
        
        
        while (a!=12){                                  //añadir 0 que faltan en el caso de que falten
            binario = "0"+binario;
            a = binario.length();
        }
        
        String col = binario.substring(0,4);            //obtener la parte del binario para coger la codificación obtener los col

        //Pasar de binario a decimal
        int numRow = Integer.parseInt(row, 2);          //de binario a decimal para tener el número real de los row
        int numCol = Integer.parseInt(col, 2);          //de binario a decimal para tener el número real de los col
        
        switch (z) {                //en el caso de que se haya pedido un row o un col se dará uno u otro
            case 'r':
                return numRow;
            case 'c':
                return numCol;
            default:
                return 0;
        }
    } 
}
