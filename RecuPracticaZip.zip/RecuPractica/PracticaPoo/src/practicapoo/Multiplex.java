package practicapoo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;

public class Multiplex{
    
    private String idiom;
    
    CinemaTicketDispenser ctd = new CinemaTicketDispenser();    //objeto controlador del dispensador
    UrjcBankServer ubs = new UrjcBankServer();                  //objeto para los pagos
    MultiplexState ms = new MultiplexState();                   //objeto para obtener o guardar los datos de los ficheros
    Multiplex mx = this;
    ArrayList <String> socios = new ArrayList();
    
    //Inicio
    public void start() throws IOException, FileNotFoundException, ClassNotFoundException{  //inicio de todo
       
        ////  INICIALIZACIÓN  ////
        LocalDate h = LocalDate.now();        //escogemos al fecha de hoy
        String hoy = h.toString();
        File dir = new File("C:\\Users\\amand\\Escritorio\\Uni\\Estudios\\Segundo\\POO\\RecuPractica\\dia.txt");
        FileReader lector = new FileReader(dir);
        int a = lector.read();      //leemos la primera línea del fichero
        ArrayList <Theater> list = new ArrayList(); //inicializamos array para guardar info
        

        //Si está vacio
        if(a==-1){      
            FileWriter escritor = new FileWriter(dir);
            BufferedWriter buffe = new BufferedWriter(escritor);
            buffe.write(hoy);                   //escrbimos el día de hoy
            ms.loadMoviesAndSessions();       //cargamos películas
            
            ObjectInputStream  file22 = new ObjectInputStream (new FileInputStream("theaterList"));  //objeto serializable para sacar info de fichero
            list = (ArrayList<Theater>) file22.readObject();                                        //meter en una lista esa info serializable de los teatros 
            file22.close();
            
            buffe.close();
            escritor.close();
        }
        
        //Si no está vacio
        else {
            BufferedReader buffer = new BufferedReader(lector);
            String diaHoy = "2"+buffer.readLine();                      //leemos el día
            if(diaHoy.equals(hoy)){                                        //si es el mismo día que hoy recargamso ficheros del serializable
                ObjectInputStream  file2 = new ObjectInputStream (new FileInputStream("theaterList"));  //objeto serializable para sacar info de fichero
                list = (ArrayList<Theater>) file2.readObject();                                        //meter en una lista esa info serializable de los teatros 
                file2.close();
            }
            else{
                ms.loadMoviesAndSessions();
            }
            
            buffer.close();
        }
        
        lector.close();
        ms.setTheaterList(list);
                     
        IdiomSelection idiomador = new IdiomSelection(ctd,mx);
        idiomador.doOperation();
        
        this.chargeVip();
                
        ////  PRESENTAR MENÚ  ////
        MainMenu main = new MainMenu(ctd,mx,ms);        //creamos el objeto menú
        main.doOperation();                               //empezamos con la juerga 
    }
    
    private void chargeVip() throws FileNotFoundException, IOException{
        FileReader lecto = new FileReader(new File("C:\\Users\\amand\\Escritorio\\Uni\\Estudios\\Segundo\\POO\\RecuPractica\\Socios.txt"));
        BufferedReader buf = new BufferedReader(lecto);
        String leyendo = buf.readLine();
        while(leyendo != null){
            socios.add(leyendo);
            
            leyendo = buf.readLine();
        }
        
    }
    
    
    //Métodos
    public String getIdiom(){
        return idiom;
    }
    
    public void setIdiom(String a){
        idiom = a;
    }
    
    public UrjcBankServer getBank(){
        return ubs;
    }
}