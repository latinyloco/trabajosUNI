package practicapoo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;



public class MultiplexState implements Serializable {
    
    private ArrayList <Theater> theaterList= new ArrayList<>();
    private Film film;
    private Theater theater;
    

    //CARGAR INFO DESDE FICHEROS Y GUARDARLO
    public void loadMoviesAndSessions()throws FileNotFoundException, IOException, ClassNotFoundException {
        
      /* AÑADIR FICHEROS */

        //Almacenar en array los archivos de la carpeta
        File ruta = new File("C:\\Users\\amand\\Escritorio\\Uni\\Estudios\\Segundo\\POO\\RecuPractica\\Ficheros");   //pillar la direccion de la carpeta
        String[] nombresArchivos = ruta.list();             //obtener el nombre de cada archivo de la carpeta
        
        String[] nombresRutas = new String[12];             //string para meter la dirección completa de cada archivo
        for (int i=0; i<nombresArchivos.length; i++){
            File rutas = new File(ruta.getAbsolutePath(),nombresArchivos[i]); //crear un fichero de texto por cada archivo de la carpeta
            nombresRutas[i] = rutas.getAbsolutePath();                              //obtener la ruta de cada uno
                                                                                    //ruta.getAbsolutePath() sirve para obtener la ruta hasta ese archivo
        }
        


        FileReader lector = null;
        BufferedReader br = null;
        
        //Añadir teatro
        for (int i=0; i<4; i++){
            
            lector = new FileReader (nombresRutas[i+4]);             //creamos el lector de un fichero "MovieX"
            br = new BufferedReader(lector);                  //creamos el bufer para que vaya línea por línea
            Theater tea = new Theater(nombresRutas[i+8], nombresRutas[i]);      //creamos un teatro con el nombre de las rutas de esa película y su foto
            String title = null;
            String descript = null;
            
            //Sacar la info
            String linea;
            while((linea=br.readLine())!=null){     //mientras que no acabes de leer el fichero de texto línea por línea
                
                if (linea.contains("Theatre"))      //si en esa línea pone theater añade el número del teatro
                    tea.setNumber(Character.getNumericValue(linea.charAt(linea.indexOf(":")+2)));   //buscar el índice de los puntos, sumarle dos unidades a ese valor. De esta froma obtenemos el número teatro y depués lo pasamos de string a int
                else if (linea.contains("Price"))
                    tea.setPrice(Character.getNumericValue(linea.charAt(linea.indexOf(":")+2)));    //lo mismo con el precio
                else if (linea.contains("Sessions")){           //si encuentra la palabra session mete la lñinea entera a addSesion, que son las cuatro sesiones
                    tea.addSession(linea);
                }
                else if (linea.contains("Title")){      //si está el título copia lo que ponga desde el inicio de los dos puntitos más dos unidades hasta el final de la línea
                    title = linea.substring(linea.indexOf(":")+2);
                }
                else if (linea.contains("Descripción")){        //si está la descripción, haz lo mismo que antes
                    descript = linea.substring(linea.indexOf(":")+2);
                }
                else if (linea.contains("Poster")){
                    String poster = linea.substring(linea.indexOf(":")+2);  //si estar poster, lo mismo pero hay que añadirle el direcctorio donde está guardado por delante
                    tea.addFilm(title, ("C:\\Users\\amand\\Escritorio\\Uni\\Estudios\\Segundo\\POO\\RecuPractica\\Ficheros\\"+poster), descript);
                }
            }
            
            theaterList.add(tea);       //añadir teatro a la lista
        }
        
            ObjectOutputStream file1 = new ObjectOutputStream (new FileOutputStream("theaterList"));        //crear un fichero serializable
            file1.writeObject(theaterList);                                                                  //guardarlo en un fichero de ese palo
            br.close();
            lector.close();
            file1.close();

    }
    
    public void saveTheaterList() throws FileNotFoundException, IOException{
        ObjectOutputStream escritor = new ObjectOutputStream (new FileOutputStream("theaterList"));        //crear un fichero serializable
        escritor.reset();
        escritor.writeObject(theaterList);
        escritor.close();
    }
        
        
    //GETERS Y SETERS
    public Theater getTheater(){
        return theater;
    }
    
    public Film getTheaterToList(){
        return film;
    }

    public int getNumberOfTheaters(){
        return theaterList.size();
    }
    
    public List getTheaterList(){
        return theaterList;
    }  
    
    public void setTheaterList(ArrayList <Theater> theaterList){
        this.theaterList = theaterList;
    }
}
