package practicapoo;

import sienens.CinemaTicketDispenser;

public abstract class Operation{
    
    public CinemaTicketDispenser ctd;
    public Multiplex multiplex;
    
    //Costructor
    public Operation(CinemaTicketDispenser ctd, Multiplex multiplex){
        this.ctd = ctd;
        this.multiplex = multiplex;
    }
    
    //Métodos abstractos
    public abstract String getTitle();
    
    
    //Demás métodos
    public CinemaTicketDispenser getDispenser(){
        return ctd;
    }
    
    public Multiplex getMultiplex(){
        return multiplex;
    }
}
