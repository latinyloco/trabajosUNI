package practicapoo;

import javax.naming.CommunicationException;
import sienens.CinemaTicketDispenser;
import urjc.UrjcBankServer;

public class PerformPayment extends Operation{
    
    private UrjcBankServer ubs;
    private MovieTicketSale mts;
    private MultiplexState ms;
    
    public PerformPayment(CinemaTicketDispenser ctd, Multiplex multiplex, UrjcBankServer ubs, MovieTicketSale mts, MultiplexState ms){
        super(ctd,multiplex);
        this.ubs = ubs;
        this.mts = mts;
        this.ms = ms;
        
    }

    public int dooOperation() {         //para contactar con el banco y esas vainas
        ctd.setMessageMode();
        ctd.setTitle(this.getTitle()) ;
        
        int finalPrice = mts.computePrice(mts.theater,false);
        String description =  mts.numSeats+" tickets for "+finalPrice+" €" ; //mostramos el número de sitios y su precio total
        ctd.setDescription(description);
        
        ctd.setOption(0, "Cancel");
        ctd.setOption(1, "Acept");
        
        char o = ctd.waitEvent(30);
        if(o=='A')
            return 0;
        
        ctd.setMessageMode();
        ctd.setTitle("Now, insert credit card") ;
        ctd.setDescription("Total: "+finalPrice+" €");
        ctd.setOption(0, "Cancel");
        ctd.setOption(1, "");
        
        while(o!='1'){                          //mientras que la opción no sea que ha detectado la tarjeta
            o = ctd.waitEvent(30);              //si se ha elegido salir se sale
            
            
            if(o=='A')                      //si se ha elegido salir se sale
                return 0;
            
            if (o=='1'){                        //si la opción es que se ha metido la tarjeta
            
                boolean b = ubs.comunicationAvaiable();     //mirar si la comunicación es buena con el banco
                if (b = true){                              //si es buena
                    
                    try {
                        int pricee = mts.computePrice(mts.theater,coprueba());
                        b = ubs.doOperation(ctd.getCardNumber(),pricee); //comprobar que la tarjeta es ok
                        ctd.expelCreditCard(10);
                        return pricee;
                        
                    } catch (CommunicationException ex) {
                        ctd.setMessageMode();                    //si no está ok
                        ctd.setDescription("Restart program") ; //se vuelve a la página principal
                        ctd.setTitle("Non operative card");
                        ctd.expelCreditCard(10);
                        return 0;
                    }
                    
                }
                
                else{                           //sino, se la otra oportunidad con otra tarjeta
                    ctd.setMessageMode();
                    ctd.setDescription("Select other card") ;
                    ctd.setTitle("Non operative card");
                    return 0;
                }  
            }
        }  
        return 0;
    }

    
    public boolean coprueba(){
        for(String i: this.multiplex.socios){
            Long num = Long.valueOf(i);
            if(num==ctd.getCardNumber())
                return true;          
        }

        return false;
    }


    @Override
    public String getTitle() {
        return "Payment";
    }
   
}
