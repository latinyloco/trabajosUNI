package practicapoo;

import java.io.*;

public class Seat implements Serializable{
    
    private int row;
    private int col;
    private int state;
    
    public Seat(int row, int col, int state){
        this.row = row;
        this.col = col;
        this.state = state;     //0 = no exite      1 = ocupado     2 = inocupado
    }
    
    public int getRow(){
        return row;
    }
    
    public int getCol(){
        return col;
    }
    
    public int getState(){
        return state;
    }
    
    public Seat getSeat(){
        return this;
    }
    
    public void setState(int state){
        this.state = state;
    }

}
