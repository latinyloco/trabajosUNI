package practicapoo;

import java.io.*;
import java.util.*;

public class Session implements Serializable{
    
    private LinkedHashMap <Integer,String> hour = new LinkedHashMap();       //Mapa de dos unidades para las horas
    private ArrayList <Seat> occupiedSeat;       //Tabla para los sitios
    private Seat seat;
    
    //public static Pair <String,Integer> getMaximum(ArrayList < Pair <String,Integer> > l)
    
    //Constructor
    public Session(int h, int m, int count){
        Integer hora = (Integer) h;
        Integer min = (Integer) m;
        String horaa = Integer.toString(hora);
        String minn = Integer.toString(min);
        String sesioneo = horaa+":"+minn;
        
        hour.put(count,sesioneo);
    }
    
        
    //Métodos
    public void addSeats(){         //añadir sitios a sesion vacia
        occupiedSeat = new ArrayList<>();
        for (int i=0; i<8; i++){
            for (int j=0; j<15; j++){
                Seat seta = new Seat(i,j,2);
                occupiedSeat.add(seta);
            }
        }
    }
    
    public boolean isOccupied(int row, int col){     //está ocupado?
        for(Seat i:  occupiedSeat){
            if(i.getCol()==col && i.getRow()==row)
                if(i.getState()==1)
                    return true;
        }
        return false;
    }
    
    public void occupySeat(int row, int col){       //ocupar
        for(Seat i:  occupiedSeat){ 
            if(i.getCol()==col && i.getRow()==row)
                i.setState(1);
        }
    }
    
    public void unocupySeat(int row, int col){      //desocupar
        for(Seat i:  occupiedSeat){
            if(i.getCol()==col && i.getRow()==row)
                i.setState(2);
        }
    }
    
    public HashMap getHour(){
        return hour;
    }
    
    public ArrayList<Seat> getOccupiedSeat(){
        return occupiedSeat;
    }
    
    public void setOccupiedSeat(ArrayList<Seat> seatss){
        occupiedSeat = seatss;
    }
}
