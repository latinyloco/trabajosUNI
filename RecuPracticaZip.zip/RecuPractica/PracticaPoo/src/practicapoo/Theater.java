package practicapoo;

import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Theater implements Serializable{
    private int number;
    private int price;
    private Film film;
    private ArrayList <Session> sessionList;
    
    private String fileTheater;
    private String fileMovie;

    public Theater(String fileTheater, String fileMovie){
        this.fileTheater = fileTheater;
        this.fileMovie = fileMovie;
    }
    
    //ADDS AND LOADS
    public void addSession(String linea){       //añadir session
        sessionList = new ArrayList<>();
                
        String text = linea.substring(linea.indexOf(":")+2);    //obtenemos todas las horas en el mismo string separadas por espacios
        String h[] = text.split(" ");                          //obtenemos las horas por separados gracias a ese método al decirle que cuando haya un espacio coga ota casilla del array

        int count = 1;
        for (String h1 : h) {                   //recorremos el array de horas
            int midle = h1.indexOf(':');     //obtenemso el valor de la posición de :
            int hour = (int) Integer.valueOf(h1.substring(0, midle));   //cogemos el valor en número de lo que hay delante de :
            int minus = (int) Integer.valueOf(h1.substring(midle+1));                   //cogemos el valor en número de lo que hay detrás de :
            
            Session ses;                            //creamos una variable con el objeto sesion
            ses = new Session(hour,minus,count);      //metemos el horario obtenido en esa sesión
            
            ses.addSeats();                         //creamos un taba de asientos para esa sesion
            sessionList.add(ses);                 //añadimos esa sesión a la lista de seiones de ese teatro 
            count++;
        }
    }
    
    public void addFilm(String i, String j, String z) throws FileNotFoundException{ //añadimos una nueva peli con su nombre, titulo del poster y descipción
        film = new Film(i,j,z);
    }
    
       
    //GETERS
    public List getSessionList(){
        return sessionList;
    }

    public int getMaxRows(){
        return 8;
    }
    
    public int getMaxCols(){
        return 15;
    }

    public Film getFilm(){
        return film;
    }
    
    public int getNumber(){
        return number;
    }
            
    public int getPrice(){
        return price;
    }   
    
    //SETERS
    public void setNumber(int number){
        this.number = number;
    }
    
    public void setPrice(int price){
        this.price = price;
    }
    
    public void setSessionList(ArrayList<Session> sessionList){
        this.sessionList = sessionList;
    }
}
